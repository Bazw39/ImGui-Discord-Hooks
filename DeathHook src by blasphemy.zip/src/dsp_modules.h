#pragma once
#include <vector>
#include <cmath>
#include <cstring>

struct DSPModules {
    double sr = 48000.0;
    std::vector<float> delay_buf; size_t delay_idx = 0;
    std::vector<float> chorus_buf; size_t chorus_idx = 0;
    std::vector<float> flanger_buf; size_t flanger_idx = 0;
    std::vector<float> reverse_buf; size_t reverse_idx = 0;
    float lpf_z1 = 0.0f, hpf_z1 = 0.0f; float comp_env = 0.0f; float phaser_z1 = 0.0f; double lfo_phase = 0.0;
    void init(double sampleRate) { sr = sampleRate; delay_buf.assign((size_t)(sr*5.0)*2,0.0f); chorus_buf.assign((size_t)(sr*2.0)*2,0.0f); flanger_buf.assign((size_t)(sr*1.0)*2,0.0f); reverse_buf.assign((size_t)(sr*10.0)*2,0.0f); delay_idx = chorus_idx = flanger_idx = reverse_idx = 0; lpf_z1=hpf_z1=phaser_z1=comp_env=0.0f; lfo_phase=0.0; }
    inline float dbToGain(float db) { return powf(10.0f, db/20.0f); }
    inline void softClip(float &x, float level) { x = tanhf(x * level); }
    inline void hardClip(float &x, float level) { if(x>level) x=level; if(x<-level) x=-level; }
    inline void limiter(float &x, float thresh) { if(x>thresh) x=thresh; if(x<-thresh) x=-thresh; }
    inline void compressor(float &x, float threshold_db, float ratio, float attack_ms, float release_ms) { float env = fabsf(x); float thr = dbToGain(threshold_db); float coeffA = expf(-1.0f/(attack_ms*0.001f*sr)); float coeffR = expf(-1.0f/(release_ms*0.001f*sr)); comp_env = env > comp_env ? coeffA*comp_env + (1.0f-coeffA)*env : coeffR*comp_env + (1.0f-coeffR)*env; if (comp_env > thr) { float over = comp_env / thr; float gain = powf(over, -(ratio-1.0f)); x *= gain; } }
    inline void bitcrush(float &x, float bits) { if(bits < 1.0f) return; float levels = powf(2.0f, bits); x = floorf((x+1.0f)/2.0f * levels)/levels*2.0f - 1.0f; }
    inline void waveshape(float &x, float amount) { x = (1.0f + amount) * x / (1.0f + amount * fabsf(x)); }
    inline void lpf(float &x, float cutoff) { float rc = 1.0f/(2.0f*3.14159265f*cutoff); float dt = 1.0f/sr; float alpha = dt/(rc+dt); lpf_z1 = lpf_z1 + alpha*(x - lpf_z1); x = lpf_z1; }
    inline float delayProcess(float in, float delay_ms, float feedback, float mix) { size_t len = delay_buf.size()/2; size_t delay_samples = (size_t)(delay_ms * 0.001f * sr); size_t read_idx = (delay_idx + len - (delay_samples%len)) % len; float out = delay_buf[read_idx*2]*0.5f + delay_buf[read_idx*2+1]*0.5f; delay_buf[delay_idx*2]=in; delay_buf[delay_idx*2+1]=in; delay_idx=(delay_idx+1)%len; return out*mix + in*(1.0f-mix); }
    inline float ringMod(float in, float freq, double &phase) { float mod = sinf(2.0f*3.14159265f * (float)phase); phase += freq / sr; if (phase > 1.0) phase -= 1.0; return in * mod; }
};
