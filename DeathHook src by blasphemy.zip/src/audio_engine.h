#pragma once
#include <atomic>
#include <vector>
#include <string>
#include <mutex>
#include <portaudio.h>
#include "dsp_modules.h"

struct FXState {
    bool enable_master = true; float master_gain_db = 0.0f;
    bool enable_preamp = false; float preamp_db = 0.0f;
    bool enable_softclip = false; float softclip_level = 1.0f;
    bool enable_hardclip = false; float hardclip_level = 1.0f;
    bool enable_limiter = false; float limiter_threshold_db = -1.0f;
    bool enable_compressor = false; float comp_threshold_db = -6.0f; float comp_ratio = 3.0f; float comp_attack_ms=10.0f; float comp_release_ms=100.0f;
    bool enable_overdrive=false; float od_drive=6.0f;
    bool enable_tube=false; float tube_drive=6.0f;
    bool enable_bitcrush=false; float bit_depth = 8.0f; float sample_reduction = 8000.0f;
    bool enable_samplerate_reducer=false; float sr_reducer = 22050.0f;
    bool enable_fuzz=false; float fuzz_amount=0.5f;
    bool enable_waveshaper=false; float waveshape_amount=0.5f;
    bool enable_lpf=false; float lpf_cut=12000.0f;
    bool enable_hpf=false; float hpf_cut=20.0f;
    bool enable_bpf=false; float bpf_center=1000.0f; float bpf_q=1.0f;
    bool enable_eq3=false; float eq_low=0.0f; float eq_mid=0.0f; float eq_high=0.0f;
    bool enable_treble=false; float treble_gain=0.0f;
    bool enable_notch=false; float notch_freq=50.0f;
    bool enable_smallroom=false; float smallroom_mix=0.2f;
    bool enable_largehall=false; float largehall_mix=0.3f;
    bool enable_plate=false; float plate_mix=0.2f;
    bool enable_haas=false; float haas_ms=10.0f;
    bool enable_echo=false; float echo_time_ms=300.0f; float echo_mix=0.25f;
    bool enable_chorus=false; float chorus_rate=1.0f; float chorus_depth=0.01f;
    bool enable_flanger=false; float flanger_rate=0.5f; float flanger_depth=0.003f;
    bool enable_phaser=false; float phaser_rate=0.3f; float phaser_depth=0.5f;
    bool enable_vibrato=false; float vibrato_rate=5.0f; float vibrato_depth=0.002f;
    bool enable_tremolo=false; float tremolo_rate=5.0f; float tremolo_depth=0.5f;
    bool enable_ringmod=false; float ring_freq=30.0f; float ring_mix=0.5f;
    bool enable_pitchshift=false; float pitch_semitones = 2.0f;
    bool enable_reverse=false; bool enable_noisegate=false; float gate_thresh= -40.0f;
};

class AudioEngine {
public:
    AudioEngine(); ~AudioEngine(); bool init(); void shutdown(); std::vector<std::string> listInputs(); std::vector<std::string> listOutputs(); bool start(int inputIndex,int outputIndex,int framesPerBuffer); void stop(); void setFXState(const FXState& s); FXState getFXState(); double sampleRate() const { return sample_rate_; } int channels() const { return 2; } void getPeak(float& inL,float& inR,float& outL,float& outR);
    void* recorderA = nullptr; void* recorderB = nullptr;
private:
    static int paCallback(const void* input, void* output, unsigned long frameCount, const PaStreamCallbackTimeInfo* timeInfo, PaStreamCallbackFlags statusFlags, void* userData);
    int process(const float* in, float* out, unsigned long n);
    PaStream* stream_ = nullptr; double sample_rate_ = 48000.0; int frames_per_buffer_ = 256;
    std::mutex stateMutex_; FXState state_; DSPModules dsp_;
    std::atomic<float> inPeakL_{0}, inPeakR_{0}, outPeakL_{0}, outPeakR_{0};
};
