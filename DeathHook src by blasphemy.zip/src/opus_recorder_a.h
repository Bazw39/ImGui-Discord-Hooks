#pragma once
#include <string>
#include <atomic>
class OpusRecorderA{public: bool start(const std::string& path,int sampleRate,int channels,int bitrateKbps); void stop(); void push(const float* interleaved,int frames,int channels); bool isRecording() const {return recording_;} std::string path() const {return path_;}
private: void* enc_=nullptr; std::atomic<bool> recording_{false}; std::string path_; };
