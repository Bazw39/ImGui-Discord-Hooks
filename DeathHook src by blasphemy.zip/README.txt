DeathHook - 15MB package

Build:
- Install vcpkg, run `vcpkg integrate install`.
- Open DeathHook.vcxproj in Visual Studio 2022 (x64) and build.

Contents:
- src/: C++ source (Audio engine, DSP modules, UI)
- Assets/: Textures (png), Docs (pdf), Samples (wav)
- Presets/: Example preset JSON

Notes:
- Two Opus recorders (pre-FX and post-FX) are included.
- All 30 DSP features (gain, distortion, filters, reverb, modulation, special FX) run in real-time in a demo-friendly implementation.
