// Lum1n0u$ - constellation background + official logo renderer.
// by blasphemyw. Subtle animated starfield with connecting lines and a
// cursor-reactive drift; plus the procedural constellation-triangle mark.
// Everything is time-based (frame-rate independent) and cheap by design.
#pragma once

#include "ImGui/imgui/imgui.h"
#include "LumUI/LumTheme.h"
#include <cmath>

namespace lum {

// Deterministic pseudo-random in [0,1) from an integer seed (no RNG state).
inline float Hash01(int n) {
    unsigned int x = (unsigned int)(n * 2654435761u);
    x ^= x >> 13; x *= 1274126177u; x ^= x >> 16;
    return (x & 0x00ffffff) / (float)0x01000000;
}

// Extremely subtle animated constellation field, clipped to the given rect.
// drawnWanted nodes drift slowly; lines fade with distance; the cursor
// gently pushes nearby nodes away (parallax feel, never distracting).
inline void ConstellationBackground(ImDrawList* dl, ImVec2 pos, ImVec2 size,
                                    float time, ImVec2 mouse,
                                    int density, float glow, float alphaScale = 1.0f) {
    if (density <= 0 || size.x <= 0 || size.y <= 0) return;
    if (density > 140) density = 140;
    dl->PushClipRect(pos, ImVec2(pos.x + size.x, pos.y + size.y), true);

    float px[140], py[140];
    for (int i = 0; i < density; ++i) {
        const float bx = Hash01(i * 2 + 1), by = Hash01(i * 2 + 2);
        const float sp = 0.5f + Hash01(i + 999);
        const float ph = Hash01(i * 7 + 3) * 6.2831853f;
        // slow Lissajous drift (time-based, ~tens of seconds per cycle)
        float x = bx + 0.035f * sp * sinf(time * 0.11f * sp + ph);
        float y = by + 0.035f * sp * cosf(time * 0.09f * sp + ph * 1.7f);
        float ax = pos.x + x * size.x, ay = pos.y + y * size.y;
        // gentle cursor repulsion
        const float dx = ax - mouse.x, dy = ay - mouse.y;
        const float d2 = dx * dx + dy * dy;
        if (d2 < 130.0f * 130.0f && d2 > 1.0f) {
            const float d = sqrtf(d2);
            const float push = (1.0f - d / 130.0f) * 14.0f;
            ax += dx / d * push; ay += dy / d * push;
        }
        px[i] = ax; py[i] = ay;
    }
    // links first (under nodes), restrained count via grid-ish stride
    const float linkDist = 110.0f * g_theme.uiScale;
    const float linkDist2 = linkDist * linkDist;
    for (int i = 0; i < density; ++i) {
        for (int j = i + 1; j < density; ++j) {
            const float dx = px[j] - px[i], dy = py[j] - py[i];
            const float d2 = dx * dx + dy * dy;
            if (d2 < linkDist2) {
                const float a = (1.0f - d2 / linkDist2) * 0.10f * alphaScale
                              * (0.4f + 0.6f * glow);
                dl->AddLine(ImVec2(px[i], py[i]), ImVec2(px[j], py[j]),
                    ImGui::ColorConvertFloat4ToU32(
                        ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, a)),
                    1.0f);
            }
        }
    }
    // nodes + occasional twinkle
    for (int i = 0; i < density; ++i) {
        const float tw = 0.55f + 0.45f * sinf(time * (0.6f + Hash01(i + 55)) + Hash01(i) * 6.28f);
        const float r = (1.0f + Hash01(i + 77) * 1.6f) * g_theme.particleSize * tw;
        const float a = (0.10f + 0.16f * tw) * alphaScale * (0.5f + 0.5f * glow);
        const bool accentNode = (i % 9 == 0);
        ImVec4 c = accentNode ? g_theme.accent2 : g_theme.text;
        dl->AddCircleFilled(ImVec2(px[i], py[i]), r,
            ImGui::ColorConvertFloat4ToU32(ImVec4(c.x, c.y, c.z, a)));
        if (accentNode && glow > 0.4f)
            dl->AddCircleFilled(ImVec2(px[i], py[i]), r * 3.0f,
                ImGui::ColorConvertFloat4ToU32(ImVec4(c.x, c.y, c.z, a * 0.25f)));
    }
    dl->PopClipRect();
}

// Official Lum1n0u$ mark: sharp geometric triangle from luminous
// constellation points - 3 primary vertices, edge nodes, orbit arcs,
// dark metallic center. Recognizable from 16px up.
inline void DrawLuminosLogo(ImDrawList* dl, ImVec2 center, float radius,
                            float time, float glowBoost = 1.0f) {
    const float glow = g_theme.glow * glowBoost;
    ImVec4 A = g_theme.accent, B = g_theme.accent2;
    ImVec4 W(0.92f, 0.96f, 1.0f, 1.0f);

    ImVec2 v[3];
    for (int i = 0; i < 3; ++i) {
        const float ang = -1.5707963f + i * 2.0943951f;
        v[i] = ImVec2(center.x + cosf(ang) * radius, center.y + sinf(ang) * radius);
    }
    // dark metallic center
    dl->AddTriangleFilled(v[0], v[1], v[2],
        ImGui::ColorConvertFloat4ToU32(ImVec4(0.03f, 0.045f, 0.09f, 0.92f)));
    // orbit arcs (subtle, slowly rotating)
    const float pulse = 0.75f + 0.25f * sinf(time * 1.4f);

    for (int e = 0; e < 2; ++e) {
        const float rx = radius * (1.18f + e * 0.22f), ry = rx * 0.42f;
        const int seg = 48;
        ImVec2 prev(0, 0);
        for (int i = 0; i <= seg; ++i) {
            const float a = i / (float)seg * 6.2831853f + time * 0.05f * (e ? -1 : 1);
            ImVec2 p(center.x + cosf(a) * rx, center.y + sinf(a) * ry * 0.9f);
            if (i > 0)
                dl->AddLine(prev, p,
                    ImGui::ColorConvertFloat4ToU32(ImVec4(A.x, A.y, A.z, 0.16f * pulse)),
                    1.0f);
            prev = p;
        }
    }
    // luminous edges (layered: wide faint + thin bright)
    for (int i = 0; i < 3; ++i) {
        ImVec2 a = v[i], b = v[(i + 1) % 3];
        dl->AddLine(a, b, ImGui::ColorConvertFloat4ToU32(ImVec4(A.x, A.y, A.z, 0.16f * glow + 0.06f)),
            3.0f + 3.0f * glow);
        dl->AddLine(a, b, ImGui::ColorConvertFloat4ToU32(ImVec4(0.78f, 0.87f, 1.0f, 0.9f)), 1.4f);
    }
    // edge constellation nodes + inner web
    ImVec2 mids[3];
    for (int i = 0; i < 3; ++i) {
        ImVec2 a = v[i], b = v[(i + 1) % 3];
        ImVec2 mid((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f);
        ImVec2 inner(center.x + (mid.x - center.x) * 0.45f,
                     center.y + (mid.y - center.y) * 0.45f);
        mids[i] = inner;
        dl->AddLine(center, inner,
            ImGui::ColorConvertFloat4ToU32(ImVec4(A.x, A.y, A.z, 0.35f)), 1.0f);
        dl->AddCircleFilled(ImVec2((a.x + mid.x) * 0.5f, (a.y + mid.y) * 0.5f),
            radius * 0.035f,
            ImGui::ColorConvertFloat4ToU32(ImVec4(B.x, B.y, B.z, 0.9f)));
        dl->AddCircleFilled(ImVec2((b.x + mid.x) * 0.5f, (b.y + mid.y) * 0.5f),
            radius * 0.035f,
            ImGui::ColorConvertFloat4ToU32(ImVec4(B.x, B.y, B.z, 0.9f)));
    }
    for (int i = 0; i < 3; ++i)
        dl->AddLine(mids[i], mids[(i + 1) % 3],
            ImGui::ColorConvertFloat4ToU32(ImVec4(B.x, B.y, B.z, 0.4f)), 1.0f);
    // 3 primary glowing vertices
    ImVec4 vc[3] = { A, ImVec4(0.45f, 0.6f, 1.0f, 1.0f), B };
    for (int i = 0; i < 3; ++i) {
        const float vr = radius * (0.10f + 0.02f * pulse);
        dl->AddCircleFilled(v[i], vr * 2.6f,
            ImGui::ColorConvertFloat4ToU32(ImVec4(vc[i].x, vc[i].y, vc[i].z, 0.14f * glow + 0.05f)));
        dl->AddCircleFilled(v[i], vr,
            ImGui::ColorConvertFloat4ToU32(ImVec4(vc[i].x, vc[i].y, vc[i].z, 1.0f)));
        dl->AddCircleFilled(v[i], vr * 0.42f,
            ImGui::ColorConvertFloat4ToU32(ImVec4(W.x, W.y, W.z, 1.0f)));
    }
}

} // namespace lum
