// Lum1n0u$ - versioned configuration persistence. by blasphemyw.
// Simple key=value store under %APPDATA%\Lum1n0u$\lumino.conf.
// Unknown keys are ignored, missing keys keep code defaults, and a
// config_version field gates future migrations - old configs never
// break new builds.
#pragma once

#include "LumUI/LumState.h"
#include "LumUI/LumTheme.h"
#include <cstdio>
#include <cstring>
#include <string>
#include <cstdlib>
#include <direct.h>

namespace lum {

inline void ConfigPath(char* out, size_t cap) {
    const char* appdata = getenv("APPDATA");
    if (!appdata || !appdata[0]) appdata = ".";
    snprintf(out, cap, "%s\\Lum1n0u$\\lumino.conf", appdata);
}

inline void EnsureConfigDir() {
    char dir[512];
    const char* appdata = getenv("APPDATA");
    if (!appdata || !appdata[0]) return;
    snprintf(dir, sizeof(dir), "%s\\Lum1n0u$", appdata);
    _mkdir(dir);
}

inline void SaveConfig() {
    EnsureConfigDir();
    char path[512];
    ConfigPath(path, sizeof(path));
    FILE* f = nullptr;
    fopen_s(&f, path, "w");
    if (!f) return;
    fprintf(f, "# Lum1n0u$ configuration (by blasphemyw) - edit carefully\n");
    fprintf(f, "config_version=%d\n", LUMINOUS_CONFIG_VERSION);
    fprintf(f, "theme_index=%d\n", g_themeIndex);
    fprintf(f, "theme_glow=%.3f\ntheme_opacity=%.3f\ntheme_radius=%.2f\n",
        (double)g_theme.glow, (double)g_theme.panelOpacity, (double)g_theme.cornerRadius);
    fprintf(f, "theme_animspeed=%.2f\ntheme_density=%d\ntheme_psize=%.2f\n",
        (double)g_theme.animSpeed, g_theme.density, (double)g_theme.particleSize);
    fprintf(f, "theme_sidebar=%.1f\ntheme_hue=%.3f\n",
        (double)g_theme.sidebarWidth, (double)g_accentHueShift);
    fprintf(f, "ui_scale=%.2f\nactive_tab=%d\nsidebar_collapsed=%d\n",
        (double)g_theme.uiScale, g_activeTab, g_sidebarCollapsed ? 1 : 0);
    fprintf(f, "win_x=%d\nwin_y=%d\nwin_w=%d\nwin_h=%d\nwin_max=%d\n",
        g_winX, g_winY, g_winW, g_winH, g_winMaximized ? 1 : 0);
    // encoder
    fprintf(f, "gain=%.2f\nexpgain=%.2f\nbitrate=%.0f\n",
        (double)Gain, (double)ExpGain, (double)Bitrate);
    fprintf(f, "enc_codec=%d\nenc_sr=%d\nenc_ch=%d\nenc_frame=%d\n",
        g_encCodec, g_encSampleRateIdx, g_encChannels, g_encFrameSize);
    fprintf(f, "opus_cx=%d\nopus_vbr=%d\nopus_cvbr=%d\nopus_fec=%d\nopus_dtx=%d\n",
        g_opusComplexity, g_opusVBR ? 1 : 0, g_opusConstrainedVBR ? 1 : 0,
        g_opusFEC ? 1 : 0, g_opusDTX ? 1 : 0);
    fprintf(f, "opus_loss=%.1f\nopus_bw=%d\nopus_app=%d\nopus_sig=%d\n",
        (double)g_opusPacketLoss, g_opusBandwidthIdx, g_opusAppModeIdx, g_opusSignalIdx);
    // reverb / clarity / eq
    fprintf(f, "rev_on=%d\nrev_size=%.3f\nrev_damp=%.3f\nrev_width=%.3f\n",
        g_revEnabled ? 1 : 0, (double)reverbSize, (double)reverbDamping, (double)reverbWidth);
    fprintf(f, "rev_pred=%.4f\nrev_makeup=%.3f\nrev_amt=%.3f\nrev_decay=%.3f\n",
        (double)reverbPredelay, (double)reverbMakeupGain, (double)ReverbAmount, (double)ReverbDecay);
    fprintf(f, "rev_diff=%.3f\nrev_wet=%.3f\nrev_dry=%.3f\nrev_early=%.3f\nrev_late=%.3f\n",
        (double)g_revDiffusion, (double)g_revWet, (double)g_revDry,
        (double)g_revEarly, (double)g_revLate);
    fprintf(f, "rev_locut=%.0f\nrev_hicut=%.0f\nrev_preset=%d\n",
        (double)g_revLowCut, (double)g_revHighCut, g_revPreset);
    fprintf(f, "clar_on=%d\nclar_q=%.2f\nclar_f=%.0f\nclar_g=%.2f\nclar_m=%.2f\nexpander=%d\n",
        apply_clarity_enhancer ? 1 : 0, (double)clarity_q, (double)clarity_freq,
        (double)clarity_gain, (double)clarity_mix, apply_expander ? 1 : 0);
    fprintf(f, "eq_on=%d\neq_lo=%.2f\neq_mid=%.2f\neq_hi=%.2f\neq10_bypass=%d\n",
        apply_eq ? 1 : 0, (double)eq_low_gain, (double)eq_mid_gain,
        (double)eq_high_gain, g_eq10Bypass ? 1 : 0);
    for (int i = 0; i < 10; ++i)
        fprintf(f, "eq10_%d=%.2f,%.2f,%.0f,%d,%d\n", i, (double)g_eq10Gain[i],
            (double)g_eq10Q[i], (double)g_eq10Freq[i], g_eq10Type[i],
            g_eq10BypassBand[i] ? 1 : 0);
    fprintf(f, "lp_on=%d\nlp_f=%.0f\nhp_on=%d\nhp_f=%.0f\n",
        apply_lowpass ? 1 : 0, (double)lowpass_freq,
        apply_highpass ? 1 : 0, (double)highpass_freq);
    // fx
    fprintf(f, "sat_on=%d\nsat_drive=%.2f\nbc_on=%d\nbc_bits=%d\nbc_rate=%.3f\n",
        apply_saturation ? 1 : 0, (double)saturation_drive,
        apply_bitcrusher ? 1 : 0, bitcrusher_bits, (double)bitcrusher_rate);
    fprintf(f, "gate_on=%d\ngate_th=%.3f\ngate_at=%.4f\ngate_rel=%.3f\n",
        apply_gate ? 1 : 0, (double)gate_threshold, (double)gate_attack, (double)gate_release);
    fprintf(f, "comp_on=%d\ncomp_th=%.1f\ncomp_ratio=%.1f\nlim_on=%d\nlim_cei=%.1f\n",
        apply_compressor ? 1 : 0, (double)comp_threshold, (double)comp_ratio,
        apply_limiter ? 1 : 0, (double)lim_ceiling);
    fprintf(f, "cho_on=%d\ncho_r=%.2f\ncho_d=%.2f\nfla_on=%d\nfla_r=%.2f\nfla_d=%.2f\n",
        apply_chorus ? 1 : 0, (double)chorus_rate, (double)chorus_depth,
        apply_flanger ? 1 : 0, (double)flanger_rate, (double)flanger_depth);
    fprintf(f, "tre_on=%d\ntre_r=%.2f\ntre_d=%.2f\npitch_on=%d\npitch_st=%.1f\n",
        apply_tremolo ? 1 : 0, (double)tremolo_rate, (double)tremolo_depth,
        apply_pitch_shift ? 1 : 0, (double)pitch_semitones);
    fprintf(f, "st_on=%d\nst_w=%.2f\nst_pan=%.2f\nhaas_on=%d\nhaas_ms=%.1f\n",
        apply_stereo_enhancer ? 1 : 0, (double)stereoWidth, (double)pan,
        apply_haas ? 1 : 0, (double)haas_delay_ms);
    fprintf(f, "dly_on=%d\ndly_t=%.2f\ndly_fb=%.2f\ninv_phase=%d\nsoft_on=%d\nsoft_c=%.2f\n",
        apply_delay ? 1 : 0, (double)delay_time, (double)delay_feedback,
        invert_phase ? 1 : 0, apply_softclip ? 1 : 0, (double)softclip_curve);
    fprintf(f, "auto_on=%d\nauto_t=%.2f\nout_gain=%.3f\nout_mute=%d\ndrywet=%.2f\nbypass=%d\n",
        apply_auto_gain ? 1 : 0, (double)auto_gain_target, (double)outputGain,
        muteOutput ? 1 : 0, (double)dryWetMix, bypassAll ? 1 : 0);
    fprintf(f, "fx_mix=%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f\n",
        (double)g_fxMix[0], (double)g_fxMix[1], (double)g_fxMix[2],
        (double)g_fxMix[3], (double)g_fxMix[4], (double)g_fxMix[5],
        (double)g_fxMix[6], (double)g_fxMix[7], (double)g_fxMix[8],
        (double)g_fxMix[9], (double)g_fxMix[10], (double)g_fxMix[11]);
    fprintf(f, "vst_custom=%s\n", g_vstCustomPath);
    fprintf(f, "vst_dir_count=%d\n", (int)g_vstFolders.size());
    for (size_t i = 0; i < g_vstFolders.size() && i < 32; ++i)
        fprintf(f, "vst_dir_%d=%s\n", (int)i, g_vstFolders[i].c_str());
    // distortion
    fprintf(f, "dist_on=%d\ndist_mode=%d\ndist_drive=%.2f\ndist_in=%.2f\ndist_out=%.2f\n",
        g_distEnabled ? 1 : 0, g_distMode, (double)g_distDrive,
        (double)g_distInGain, (double)g_distOutGain);
    fprintf(f, "dist_mix=%.2f\ndist_tone=%.2f\ndist_clip=%.2f\ndist_soft=%d\ndist_hard=%d\n",
        (double)g_distMix, (double)g_distTone, (double)g_distClipThresh,
        g_distSoftClip ? 1 : 0, g_distHardClip ? 1 : 0);
    fprintf(f, "dist_shape=%d\ndist_os=%d\ndist_pre=%.2f\ndist_post=%.2f\ndist_link=%d\n",
        g_distWaveshaper, g_distOversample, (double)g_distPreEmph,
        (double)g_distPostEmph, g_distStereoLink ? 1 : 0);
    // mixer
    for (int i = 0; i < 8; ++i)
        fprintf(f, "mix_%d=%.3f,%.2f,%d,%d,%s\n", i, (double)g_mixer[i].gain,
            (double)g_mixer[i].pan, g_mixer[i].mute ? 1 : 0,
            g_mixer[i].solo ? 1 : 0, g_mixer[i].name);
    fprintf(f, "mix_master=%.3f\nmix_mute=%d\nmix_lim=%d\nmix_ceil=%.1f\n",
        (double)g_mixerMaster, g_mixerMasterMute ? 1 : 0,
        g_mixerLimiter ? 1 : 0, (double)g_mixerLimiterCeil);
    // visualizer / vst / misc
    fprintf(f, "vis_mode=%d\nvis_scale=%.2f\nvis_freeze=%d\n",
        g_visMode, (double)g_visScale, g_visFreeze ? 1 : 0);
    fprintf(f, "vst_fav_count=%d\n", (int)g_vstFavorites.size());
    for (size_t i = 0; i < g_vstFavorites.size() && i < 64; ++i)
        fprintf(f, "vst_fav_%d=%s\n", (int)i, g_vstFavorites[i].c_str());
    // settings
    fprintf(f, "set_quality=%d\nset_visfps=%d\nset_bgeff=%d\nset_threads=%d\n",
        g_settings.renderQuality, g_settings.visFPS,
        g_settings.bgEffects ? 1 : 0, g_settings.workerThreads);
    fprintf(f, "set_sr=%d\nset_ch=%d\nset_buf=%d\nset_mode=%d\n",
        g_settings.sampleRateIdx, g_settings.channelMode,
        g_settings.bufferSize, g_settings.processingMode);
    fprintf(f, "set_startup=%d\nset_rempos=%d\nset_remtheme=%d\nset_autosave=%d\n",
        g_settings.startupTab, g_settings.rememberPos ? 1 : 0,
        g_settings.rememberTheme ? 1 : 0, g_settings.autosave ? 1 : 0);
    fprintf(f, "set_debug=%d\nset_diag=%d\nset_stats=%d\n",
        g_settings.debugLog ? 1 : 0, g_settings.diagMode ? 1 : 0,
        g_settings.internalStats ? 1 : 0);
    fprintf(f, "master_gain=%.3f\nmaster_mute=%d\npreset=%s\n",
        (double)g_masterGain, g_masterMuted ? 1 : 0, g_currentPreset);
    fclose(f);
}

inline int CfgInt(const char* v, int fallback) {
    return (v && v[0]) ? atoi(v) : fallback;
}
inline float CfgFloat(const char* v, float fallback) {
    return (v && v[0]) ? (float)atof(v) : fallback;
}

// Load tolerantly: every key is optional; unknown keys are skipped so
// older/newer files never break the app (migration-safe by design).
inline void LoadConfig() {
    char path[512];
    ConfigPath(path, sizeof(path));
    FILE* f = nullptr;
    fopen_s(&f, path, "r");
    if (!f) return;
    char line[1024];
    int fileVersion = 1;
    while (fgets(line, sizeof(line), f)) {
        if (line[0] == '#' || line[0] == '\n' || line[0] == '\r') continue;
        char* eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        char* k = line; char* v = eq + 1;
        size_t n = strlen(v);
        while (n && (v[n-1] == '\n' || v[n-1] == '\r')) v[--n] = 0;
        const bool b = (v[0] == '1');
        if (!strcmp(k, "config_version")) fileVersion = CfgInt(v, 1);
        if (!strcmp(k, "theme_index")) LumSelectTheme(CfgInt(v, 0));
        if (!strcmp(k, "theme_glow")) g_theme.glow = CfgFloat(v, g_theme.glow);
        if (!strcmp(k, "theme_opacity")) g_theme.panelOpacity = CfgFloat(v, g_theme.panelOpacity);
        if (!strcmp(k, "theme_radius")) g_theme.cornerRadius = CfgFloat(v, g_theme.cornerRadius);
        if (!strcmp(k, "theme_animspeed")) g_theme.animSpeed = CfgFloat(v, g_theme.animSpeed);
        if (!strcmp(k, "theme_density")) g_theme.density = CfgInt(v, g_theme.density);
        if (!strcmp(k, "theme_psize")) g_theme.particleSize = CfgFloat(v, g_theme.particleSize);
        if (!strcmp(k, "theme_sidebar")) g_theme.sidebarWidth = CfgFloat(v, g_theme.sidebarWidth);
        if (!strcmp(k, "theme_hue")) { g_accentHueShift = CfgFloat(v, 0); LumApplyHueShift(g_accentHueShift); }
        if (!strcmp(k, "ui_scale")) g_theme.uiScale = CfgFloat(v, 1.0f);
        if (!strcmp(k, "active_tab")) g_activeTab = CfgInt(v, 0);
        if (!strcmp(k, "sidebar_collapsed")) g_sidebarCollapsed = b;
        if (!strcmp(k, "win_x")) g_winX = CfgInt(v, g_winX);
        if (!strcmp(k, "win_y")) g_winY = CfgInt(v, g_winY);
        if (!strcmp(k, "win_w")) g_winW = CfgInt(v, g_winW);
        if (!strcmp(k, "win_h")) g_winH = CfgInt(v, g_winH);
        if (!strcmp(k, "win_max")) g_winMaximized = b;
        if (!strcmp(k, "gain")) Gain = CfgFloat(v, Gain);
        if (!strcmp(k, "expgain")) ExpGain = CfgFloat(v, ExpGain);
        if (!strcmp(k, "bitrate")) Bitrate = CfgFloat(v, Bitrate);
        if (!strcmp(k, "enc_codec")) g_encCodec = CfgInt(v, 0);
        if (!strcmp(k, "enc_sr")) g_encSampleRateIdx = CfgInt(v, 2);
        if (!strcmp(k, "enc_ch")) g_encChannels = CfgInt(v, 2);
        if (!strcmp(k, "enc_frame")) g_encFrameSize = CfgInt(v, 960);
        if (!strcmp(k, "opus_cx")) g_opusComplexity = CfgInt(v, 10);
        if (!strcmp(k, "opus_vbr")) g_opusVBR = b;
        if (!strcmp(k, "opus_cvbr")) g_opusConstrainedVBR = b;
        if (!strcmp(k, "opus_fec")) g_opusFEC = b;
        if (!strcmp(k, "opus_dtx")) g_opusDTX = b;
        if (!strcmp(k, "opus_loss")) g_opusPacketLoss = CfgFloat(v, 0);
        if (!strcmp(k, "opus_bw")) g_opusBandwidthIdx = CfgInt(v, 4);
        if (!strcmp(k, "opus_app")) g_opusAppModeIdx = CfgInt(v, 0);
        if (!strcmp(k, "opus_sig")) g_opusSignalIdx = CfgInt(v, 0);
        if (!strcmp(k, "rev_on")) g_revEnabled = b;
        if (!strcmp(k, "rev_size")) reverbSize = CfgFloat(v, reverbSize);
        if (!strcmp(k, "rev_damp")) reverbDamping = CfgFloat(v, reverbDamping);
        if (!strcmp(k, "rev_width")) reverbWidth = CfgFloat(v, reverbWidth);
        if (!strcmp(k, "rev_pred")) reverbPredelay = CfgFloat(v, reverbPredelay);
        if (!strcmp(k, "rev_makeup")) reverbMakeupGain = CfgFloat(v, reverbMakeupGain);
        if (!strcmp(k, "rev_amt")) ReverbAmount = CfgFloat(v, ReverbAmount);
        if (!strcmp(k, "rev_decay")) ReverbDecay = CfgFloat(v, ReverbDecay);
        if (!strcmp(k, "rev_diff")) g_revDiffusion = CfgFloat(v, g_revDiffusion);
        if (!strcmp(k, "rev_wet")) g_revWet = CfgFloat(v, g_revWet);
        if (!strcmp(k, "rev_dry")) g_revDry = CfgFloat(v, g_revDry);
        if (!strcmp(k, "rev_early")) g_revEarly = CfgFloat(v, g_revEarly);
        if (!strcmp(k, "rev_late")) g_revLate = CfgFloat(v, g_revLate);
        if (!strcmp(k, "rev_locut")) g_revLowCut = CfgFloat(v, g_revLowCut);
        if (!strcmp(k, "rev_hicut")) g_revHighCut = CfgFloat(v, g_revHighCut);
        if (!strcmp(k, "rev_preset")) g_revPreset = CfgInt(v, 2);
        if (!strcmp(k, "clar_on")) apply_clarity_enhancer = b;
        if (!strcmp(k, "clar_q")) clarity_q = CfgFloat(v, clarity_q);
        if (!strcmp(k, "clar_f")) clarity_freq = CfgFloat(v, clarity_freq);
        if (!strcmp(k, "clar_g")) clarity_gain = CfgFloat(v, clarity_gain);
        if (!strcmp(k, "clar_m")) clarity_mix = CfgFloat(v, clarity_mix);
        if (!strcmp(k, "expander")) apply_expander = b;
        if (!strcmp(k, "eq_on")) apply_eq = b;
        if (!strcmp(k, "eq_lo")) eq_low_gain = CfgFloat(v, eq_low_gain);
        if (!strcmp(k, "eq_mid")) eq_mid_gain = CfgFloat(v, eq_mid_gain);
        if (!strcmp(k, "eq_hi")) eq_high_gain = CfgFloat(v, eq_high_gain);
        if (!strcmp(k, "eq10_bypass")) g_eq10Bypass = b;
        if (!strncmp(k, "eq10_", 5)) {
            int i = atoi(k + 5);
            if (i >= 0 && i < 10) {
                float g, q, fr; int ty, bp;
                if (sscanf_s(v, "%f,%f,%f,%d,%d", &g, &q, &fr, &ty, &bp) == 5) {
                    g_eq10Gain[i] = g; g_eq10Q[i] = q; g_eq10Freq[i] = fr;
                    g_eq10Type[i] = ty; g_eq10BypassBand[i] = (bp != 0);
                }
            }
        }
        if (!strcmp(k, "lp_on")) apply_lowpass = b;
        if (!strcmp(k, "lp_f")) lowpass_freq = CfgFloat(v, lowpass_freq);
        if (!strcmp(k, "hp_on")) apply_highpass = b;
        if (!strcmp(k, "hp_f")) highpass_freq = CfgFloat(v, highpass_freq);
        if (!strcmp(k, "sat_on")) apply_saturation = b;
        if (!strcmp(k, "sat_drive")) saturation_drive = CfgFloat(v, saturation_drive);
        if (!strcmp(k, "bc_on")) apply_bitcrusher = b;
        if (!strcmp(k, "bc_bits")) bitcrusher_bits = CfgInt(v, bitcrusher_bits);
        if (!strcmp(k, "bc_rate")) bitcrusher_rate = CfgFloat(v, bitcrusher_rate);
        if (!strcmp(k, "gate_on")) apply_gate = b;
        if (!strcmp(k, "gate_th")) gate_threshold = CfgFloat(v, gate_threshold);
        if (!strcmp(k, "gate_at")) gate_attack = CfgFloat(v, gate_attack);
        if (!strcmp(k, "gate_rel")) gate_release = CfgFloat(v, gate_release);
        if (!strcmp(k, "comp_on")) apply_compressor = b;
        if (!strcmp(k, "comp_th")) comp_threshold = CfgFloat(v, comp_threshold);
        if (!strcmp(k, "comp_ratio")) comp_ratio = CfgFloat(v, comp_ratio);
        if (!strcmp(k, "lim_on")) apply_limiter = b;
        if (!strcmp(k, "lim_cei")) lim_ceiling = CfgFloat(v, lim_ceiling);
        if (!strcmp(k, "cho_on")) apply_chorus = b;
        if (!strcmp(k, "cho_r")) chorus_rate = CfgFloat(v, chorus_rate);
        if (!strcmp(k, "cho_d")) chorus_depth = CfgFloat(v, chorus_depth);
        if (!strcmp(k, "fla_on")) apply_flanger = b;
        if (!strcmp(k, "fla_r")) flanger_rate = CfgFloat(v, flanger_rate);
        if (!strcmp(k, "fla_d")) flanger_depth = CfgFloat(v, flanger_depth);
        if (!strcmp(k, "tre_on")) apply_tremolo = b;
        if (!strcmp(k, "tre_r")) tremolo_rate = CfgFloat(v, tremolo_rate);
        if (!strcmp(k, "tre_d")) tremolo_depth = CfgFloat(v, tremolo_depth);
        if (!strcmp(k, "pitch_on")) apply_pitch_shift = b;
        if (!strcmp(k, "pitch_st")) pitch_semitones = CfgFloat(v, pitch_semitones);
        if (!strcmp(k, "st_on")) apply_stereo_enhancer = b;
        if (!strcmp(k, "st_w")) stereoWidth = CfgFloat(v, stereoWidth);
        if (!strcmp(k, "st_pan")) pan = CfgFloat(v, pan);
        if (!strcmp(k, "haas_on")) apply_haas = b;
        if (!strcmp(k, "haas_ms")) haas_delay_ms = CfgFloat(v, haas_delay_ms);
        if (!strcmp(k, "dly_on")) apply_delay = b;
        if (!strcmp(k, "dly_t")) delay_time = CfgFloat(v, delay_time);
        if (!strcmp(k, "dly_fb")) delay_feedback = CfgFloat(v, delay_feedback);
        if (!strcmp(k, "inv_phase")) invert_phase = b;
        if (!strcmp(k, "soft_on")) apply_softclip = b;
        if (!strcmp(k, "soft_c")) softclip_curve = CfgFloat(v, softclip_curve);
        if (!strcmp(k, "auto_on")) apply_auto_gain = b;
        if (!strcmp(k, "auto_t")) auto_gain_target = CfgFloat(v, auto_gain_target);
        if (!strcmp(k, "out_gain")) outputGain = CfgFloat(v, outputGain);
        if (!strcmp(k, "out_mute")) muteOutput = b;
        if (!strcmp(k, "drywet")) dryWetMix = CfgFloat(v, dryWetMix);
        if (!strcmp(k, "bypass")) bypassAll = b;
        if (!strcmp(k, "fx_mix")) {
            float m[12];
            if (sscanf_s(v, "%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f",
                    &m[0], &m[1], &m[2], &m[3], &m[4], &m[5],
                    &m[6], &m[7], &m[8], &m[9], &m[10], &m[11]) == 12)
                for (int i = 0; i < 12; ++i) g_fxMix[i] = m[i];
        }
        if (!strcmp(k, "vst_custom")) {
            strncpy_s(g_vstCustomPath, v, sizeof(g_vstCustomPath) - 1);
        }
        if (!strncmp(k, "vst_dir_", 8)) {
            if (v[0] && strcmp(k, "vst_dir_count") != 0) g_vstFolders.push_back(v);
        }
        if (!strcmp(k, "dist_on")) g_distEnabled = b;
        if (!strcmp(k, "dist_mode")) g_distMode = CfgInt(v, 0);
        if (!strcmp(k, "dist_drive")) g_distDrive = CfgFloat(v, g_distDrive);
        if (!strcmp(k, "dist_in")) g_distInGain = CfgFloat(v, g_distInGain);
        if (!strcmp(k, "dist_out")) g_distOutGain = CfgFloat(v, g_distOutGain);
        if (!strcmp(k, "dist_mix")) g_distMix = CfgFloat(v, g_distMix);
        if (!strcmp(k, "dist_tone")) g_distTone = CfgFloat(v, g_distTone);
        if (!strcmp(k, "dist_clip")) g_distClipThresh = CfgFloat(v, g_distClipThresh);
        if (!strcmp(k, "dist_soft")) g_distSoftClip = b;
        if (!strcmp(k, "dist_hard")) g_distHardClip = b;
        if (!strcmp(k, "dist_shape")) g_distWaveshaper = CfgInt(v, 0);
        if (!strcmp(k, "dist_os")) g_distOversample = CfgInt(v, 1);
        if (!strcmp(k, "dist_pre")) g_distPreEmph = CfgFloat(v, g_distPreEmph);
        if (!strcmp(k, "dist_post")) g_distPostEmph = CfgFloat(v, g_distPostEmph);
        if (!strcmp(k, "dist_link")) g_distStereoLink = b;
        if (!strncmp(k, "mix_", 4) && k[4] >= '0' && k[4] <= '7' && k[5] == 0) {
            int i = k[4] - '0';
            float g, p; int mu, so; char nm[32];
            if (sscanf_s(v, "%f,%f,%d,%d,%31s", &g, &p, &mu, &so, nm, (unsigned)sizeof(nm)) >= 4) {
                g_mixer[i].gain = g; g_mixer[i].pan = p;
                g_mixer[i].mute = (mu != 0); g_mixer[i].solo = (so != 0);
                if (nm[0]) { strncpy_s(g_mixer[i].name, nm, sizeof(g_mixer[i].name) - 1); }
            }
        }
        if (!strcmp(k, "mix_master")) g_mixerMaster = CfgFloat(v, g_mixerMaster);
        if (!strcmp(k, "mix_mute")) g_mixerMasterMute = b;
        if (!strcmp(k, "mix_lim")) g_mixerLimiter = b;
        if (!strcmp(k, "mix_ceil")) g_mixerLimiterCeil = CfgFloat(v, g_mixerLimiterCeil);
        if (!strcmp(k, "vis_mode")) g_visMode = CfgInt(v, 0);
        if (!strcmp(k, "vis_scale")) g_visScale = CfgFloat(v, 1.0f);
        if (!strcmp(k, "vis_freeze")) g_visFreeze = b;
        if (!strncmp(k, "vst_fav_", 8)) {
            if (v[0] && strcmp(k, "vst_fav_count") != 0) g_vstFavorites.push_back(v);
        }
        if (!strcmp(k, "set_quality")) g_settings.renderQuality = CfgInt(v, 1);
        if (!strcmp(k, "set_visfps")) g_settings.visFPS = CfgInt(v, 60);
        if (!strcmp(k, "set_bgeff")) g_settings.bgEffects = b;
        if (!strcmp(k, "set_threads")) g_settings.workerThreads = CfgInt(v, 2);
        if (!strcmp(k, "set_sr")) g_settings.sampleRateIdx = CfgInt(v, 2);
        if (!strcmp(k, "set_ch")) g_settings.channelMode = CfgInt(v, 1);
        if (!strcmp(k, "set_buf")) g_settings.bufferSize = CfgInt(v, 512);
        if (!strcmp(k, "set_mode")) g_settings.processingMode = CfgInt(v, 0);
        if (!strcmp(k, "set_startup")) g_settings.startupTab = CfgInt(v, 0);
        if (!strcmp(k, "set_rempos")) g_settings.rememberPos = b;
        if (!strcmp(k, "set_remtheme")) g_settings.rememberTheme = b;
        if (!strcmp(k, "set_autosave")) g_settings.autosave = b;
        if (!strcmp(k, "set_debug")) g_settings.debugLog = b;
        if (!strcmp(k, "set_diag")) g_settings.diagMode = b;
        if (!strcmp(k, "set_stats")) g_settings.internalStats = b;
        if (!strcmp(k, "master_gain")) g_masterGain = CfgFloat(v, 1.0f);
        if (!strcmp(k, "master_mute")) g_masterMuted = b;
        if (!strcmp(k, "preset")) {
            strncpy_s(g_currentPreset, v, sizeof(g_currentPreset) - 1);
        }
        // (unknown keys intentionally ignored -> forward compatible)
    }
    fclose(f);
    if (fileVersion < 1) fileVersion = 1;
    (void)fileVersion;
    // clamp everything that came from disk
    if (g_activeTab < 0 || g_activeTab >= LumTab_Count) g_activeTab = 0;
    if (g_theme.uiScale < 0.7f) g_theme.uiScale = 0.7f;
    if (g_theme.uiScale > 2.0f) g_theme.uiScale = 2.0f;
    if (g_winW < 800) g_winW = 800;
    if (g_winH < 500) g_winH = 500;
    g_windowPosLoaded = true;
}

} // namespace lum
