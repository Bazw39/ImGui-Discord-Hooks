// Lum1n0u$ - constellation theme engine. by blasphemyw.
// Centralizes every color / glow / layout parameter so no palette
// values are hardcoded across the UI.
#pragma once

#include "ImGui/imgui/imgui.h"

// ---------------------------------------------------------------- brand ---
#define LUMINOUS_APP_NAME   "Lum1n0u$"
#define LUMINOUS_DEVELOPER  "blasphemyw"
#define LUMINOUS_VERSION    "2.0.0"
#define LUMINOUS_BUILD      "V2 constellation"
#define LUMINOUS_CONFIG_VERSION 2

struct LumTheme {
    const char* name;
    ImVec4 bg;          // application background
    ImVec4 panel;       // card / child background (alpha applied separately)
    ImVec4 accent;      // primary glow accent
    ImVec4 accent2;     // secondary glow accent
    ImVec4 text;        // primary text
    ImVec4 textDim;     // secondary text
    // tunable parameters
    float glow;         // 0..1 glow strength
    float panelOpacity; // 0..1 card opacity
    float cornerRadius; // px rounding
    float animSpeed;    // animation multiplier
    int   density;      // constellation node count
    float particleSize; // node radius multiplier
    float sidebarWidth; // px
    float uiScale;      // global scale
};

// Built-in constellation themes.
static const LumTheme kLumThemes[] = {
    { "Cosmic Blue",  ImVec4(0.014f,0.020f,0.045f,1.0f), ImVec4(0.030f,0.048f,0.100f,1.0f),
      ImVec4(0.36f,0.55f,1.00f,1.0f), ImVec4(0.13f,0.83f,0.93f,1.0f),
      ImVec4(0.88f,0.92f,1.00f,1.0f), ImVec4(0.45f,0.52f,0.66f,1.0f),
      0.70f, 0.92f, 6.0f, 1.0f, 70, 1.6f, 208.0f, 1.0f },
    { "Nebula Violet", ImVec4(0.045f,0.020f,0.075f,1.0f), ImVec4(0.075f,0.040f,0.130f,1.0f),
      ImVec4(0.62f,0.36f,0.98f,1.0f), ImVec4(0.95f,0.35f,0.75f,1.0f),
      ImVec4(0.93f,0.89f,1.00f,1.0f), ImVec4(0.55f,0.47f,0.68f,1.0f),
      0.70f, 0.92f, 6.0f, 1.0f, 80, 1.6f, 208.0f, 1.0f },
    { "Aurora Cyan",  ImVec4(0.004f,0.030f,0.038f,1.0f), ImVec4(0.010f,0.070f,0.090f,1.0f),
      ImVec4(0.10f,0.90f,0.85f,1.0f), ImVec4(0.20f,0.65f,1.00f,1.0f),
      ImVec4(0.87f,0.97f,0.96f,1.0f), ImVec4(0.42f,0.58f,0.60f,1.0f),
      0.65f, 0.92f, 6.0f, 1.0f, 65, 1.5f, 208.0f, 1.0f },
    { "Eclipse",      ImVec4(0.020f,0.020f,0.024f,1.0f), ImVec4(0.055f,0.058f,0.070f,1.0f),
      ImVec4(0.75f,0.78f,0.86f,1.0f), ImVec4(0.55f,0.42f,0.95f,1.0f),
      ImVec4(0.90f,0.90f,0.93f,1.0f), ImVec4(0.48f,0.48f,0.55f,1.0f),
      0.45f, 0.94f, 5.0f, 1.0f, 55, 1.4f, 208.0f, 1.0f },
    { "Deep Space",   ImVec4(0.002f,0.004f,0.010f,1.0f), ImVec4(0.012f,0.022f,0.050f,1.0f),
      ImVec4(0.30f,0.45f,0.80f,1.0f), ImVec4(0.20f,0.35f,0.70f,1.0f),
      ImVec4(0.82f,0.87f,0.95f,1.0f), ImVec4(0.38f,0.44f,0.58f,1.0f),
      0.50f, 0.90f, 6.0f, 0.8f, 95, 1.3f, 208.0f, 1.0f },
    { "Solar Flare",  ImVec4(0.045f,0.032f,0.018f,1.0f), ImVec4(0.090f,0.065f,0.035f,1.0f),
      ImVec4(1.00f,0.72f,0.25f,1.0f), ImVec4(1.00f,0.42f,0.20f,1.0f),
      ImVec4(1.00f,0.94f,0.87f,1.0f), ImVec4(0.62f,0.52f,0.42f,1.0f),
      0.65f, 0.92f, 6.0f, 1.0f, 60, 1.6f, 208.0f, 1.0f },
};
static const int kLumThemeCount = (int)(sizeof(kLumThemes) / sizeof(kLumThemes[0]));

// Active theme (mutable copy of the selected preset).
inline LumTheme g_theme = kLumThemes[0];
inline int      g_themeIndex = 0;
inline float    g_accentHueShift = 0.0f; // -0.5..0.5, applied on top of preset accent

// Shift the active accent colors by a hue delta (keeps the preset intact).
inline void LumApplyHueShift(float hueDelta) {
    if (g_themeIndex < 0 || g_themeIndex >= kLumThemeCount) return;
    g_theme.accent  = kLumThemes[g_themeIndex].accent;
    g_theme.accent2 = kLumThemes[g_themeIndex].accent2;
    if (hueDelta == 0.0f) return;
    for (int k = 0; k < 2; ++k) {
        ImVec4& c = (k == 0) ? g_theme.accent : g_theme.accent2;
        float h, s, v;
        ImGui::ColorConvertRGBtoHSV(c.x, c.y, c.z, h, s, v);
        h += hueDelta;
        if (h < 0.0f) h += 1.0f;
        if (h > 1.0f) h -= 1.0f;
        ImGui::ColorConvertHSVtoRGB(h, s, v, c.x, c.y, c.z);
    }
}

// Select a built-in preset (resets tunable params to the preset defaults).
inline void LumSelectTheme(int index) {
    if (index < 0 || index >= kLumThemeCount) return;
    g_themeIndex = index;
    g_theme = kLumThemes[index];
    g_accentHueShift = 0.0f;
}

// Push the active theme into Dear ImGui style. Call once per frame
// (cheap) so live theme edits apply instantly.
inline void LumApplyThemeToStyle() {
    ImGuiStyle& st = ImGui::GetStyle();
    const float r = g_theme.cornerRadius;
    st.WindowRounding = r; st.ChildRounding = r;
    st.FrameRounding = r * 0.8f; st.PopupRounding = r;
    st.ScrollbarRounding = r; st.TabRounding = r * 0.7f;
    st.GrabRounding = r * 0.6f;
    st.ButtonTextAlign = ImVec2(0.5f, 0.5f);
    st.WindowTitleAlign = ImVec2(0.5f, 0.5f);
    st.FramePadding = ImVec2(6.0f, 4.0f);
    st.WindowPadding = ImVec2(8.0f, 8.0f);
    st.ItemSpacing = ImVec2(8.0f, 5.0f);
    st.ItemInnerSpacing = ImVec2(5.0f, 5.0f);
    st.WindowBorderSize = 1.0f; st.FrameBorderSize = 1.0f;
    st.PopupBorderSize = 1.0f; st.ScrollbarSize = 7.0f;
    st.GrabMinSize = 8.0f;

    const float po = g_theme.panelOpacity;
    ImVec4 panel = g_theme.panel; panel.w = po;
    ImVec4 panelSolid = g_theme.panel; panelSolid.w = 1.0f;
    ImVec4 hover = g_theme.accent; hover.w = 0.16f;
    ImVec4 active = g_theme.accent; active.w = 0.30f;
    ImVec4 border = g_theme.accent; border.w = 0.22f;
    ImVec4 grab = g_theme.accent; grab.w = 0.85f;

    st.Colors[ImGuiCol_Text] = g_theme.text;
    st.Colors[ImGuiCol_TextDisabled] = g_theme.textDim;
    st.Colors[ImGuiCol_WindowBg] = g_theme.bg;
    st.Colors[ImGuiCol_ChildBg] = panel;
    st.Colors[ImGuiCol_PopupBg] = panelSolid;
    st.Colors[ImGuiCol_Border] = border;
    st.Colors[ImGuiCol_BorderShadow] = ImVec4(0, 0, 0, 0);
    st.Colors[ImGuiCol_FrameBg] = panel;
    st.Colors[ImGuiCol_FrameBgHovered] = hover;
    st.Colors[ImGuiCol_FrameBgActive] = active;
    st.Colors[ImGuiCol_TitleBg] = g_theme.bg;
    st.Colors[ImGuiCol_TitleBgActive] = panelSolid;
    st.Colors[ImGuiCol_TitleBgCollapsed] = g_theme.bg;
    st.Colors[ImGuiCol_MenuBarBg] = g_theme.bg;
    st.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0, 0, 0, 0);
    st.Colors[ImGuiCol_ScrollbarGrab] = border;
    st.Colors[ImGuiCol_ScrollbarGrabHovered] = hover;
    st.Colors[ImGuiCol_ScrollbarGrabActive] = active;
    st.Colors[ImGuiCol_CheckMark] = g_theme.accent;
    st.Colors[ImGuiCol_SliderGrab] = grab;
    st.Colors[ImGuiCol_SliderGrabActive] = g_theme.accent;
    st.Colors[ImGuiCol_Button] = panel;
    st.Colors[ImGuiCol_ButtonHovered] = hover;
    st.Colors[ImGuiCol_ButtonActive] = active;
    st.Colors[ImGuiCol_Header] = panel;
    st.Colors[ImGuiCol_HeaderHovered] = hover;
    st.Colors[ImGuiCol_HeaderActive] = active;
    st.Colors[ImGuiCol_Separator] = border;
    st.Colors[ImGuiCol_SeparatorHovered] = hover;
    st.Colors[ImGuiCol_SeparatorActive] = active;
    st.Colors[ImGuiCol_ResizeGrip] = ImVec4(0, 0, 0, 0);
    st.Colors[ImGuiCol_ResizeGripHovered] = hover;
    st.Colors[ImGuiCol_ResizeGripActive] = active;
    st.Colors[ImGuiCol_Tab] = panel;
    st.Colors[ImGuiCol_TabHovered] = hover;
    st.Colors[ImGuiCol_TabActive] = active;
    st.Colors[ImGuiCol_TabUnfocused] = panel;
    st.Colors[ImGuiCol_TabUnfocusedActive] = hover;
    st.Colors[ImGuiCol_PlotLines] = g_theme.accent;
    st.Colors[ImGuiCol_PlotLinesHovered] = g_theme.accent2;
    st.Colors[ImGuiCol_PlotHistogram] = g_theme.accent;
    st.Colors[ImGuiCol_PlotHistogramHovered] = g_theme.accent2;
    st.Colors[ImGuiCol_TextSelectedBg] = active;
    st.Colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0, 0, 0, 0.6f);
    st.Colors[ImGuiCol_DragDropTarget] = hover;
    st.Colors[ImGuiCol_NavHighlight] = hover;
}
