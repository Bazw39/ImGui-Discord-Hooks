// Lum1n0u$ - reusable custom component library. by blasphemyw.
// GlowSlider, GlowButton, GlowTab (nav item), Card, Meter, Toggle,
// SectionHeader, StatusPill. No default-ImGui look: everything is drawn
// with luminous constellation styling driven by the active theme.
#pragma once

#include "ImGui/imgui/imgui.h"
#include "LumUI/LumTheme.h"
#include <unordered_map>
#include <cstdio>
#include <cmath>

namespace lum {

// Per-widget animation memory (glow pulse phase, slider fill smoothing,
// toggle knob position). Keyed by ImGuiID so repeated widgets animate
// independently without extra state plumbing.
inline std::unordered_map<ImGuiID, float>& AnimMap() {
    static std::unordered_map<ImGuiID, float> m;
    return m;
}
inline float AnimValue(ImGuiID id, float init = 0.0f) {
    auto& m = AnimMap();
    auto it = m.find(id);
    if (it == m.end()) { m[id] = init; return init; }
    return it->second;
}
inline void AnimSet(ImGuiID id, float v) { AnimMap()[id] = v; }

inline ImU32 Alpha(ImVec4 c, float a) { c.w *= a; return ImGui::ColorConvertFloat4ToU32(c); }

// Small helper: tooltip only when requested and the previous item is hovered.
inline void HelpTip(const char* tip) {
    if (tip && tip[0] && ImGui::IsItemHovered(ImGuiHoveredFlags_DelayNormal))
        ImGui::SetTooltip("%s", tip);
}

// ---------------------------------------------------------- SectionHeader --
inline void SectionHeader(const char* title, const char* tip = nullptr) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetCursorScreenPos();
    const float s = g_theme.uiScale;
    const float barW = 3.0f * s, barH = ImGui::GetTextLineHeight();
    const ImU32 glow = Alpha(g_theme.accent, 0.25f * g_theme.glow + 0.10f);
    dl->AddRectFilled(ImVec2(p.x - 3 * s, p.y + barH + 5 * s),
        ImVec2(p.x + ImGui::GetContentRegionAvail().x, p.y + barH + 6 * s), glow);
    dl->AddRectFilled(ImVec2(p.x, p.y + 1 * s), ImVec2(p.x + barW, p.y + barH - 1 * s),
        ImGui::ColorConvertFloat4ToU32(g_theme.accent));
    ImGui::SetCursorScreenPos(ImVec2(p.x + 9 * s, p.y));
    ImGui::TextUnformatted(title);
    HelpTip(tip);
    ImGui::Spacing();
}

// --------------------------------------------------------------- StatusPill -
inline void StatusPill(const char* text, ImVec4 color) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetCursorScreenPos();
    const float s = g_theme.uiScale;
    ImVec2 ts = ImGui::CalcTextSize(text);
    ImVec2 sz(ts.x + 18 * s, ts.y + 8 * s);
    const float r = sz.y * 0.5f;
    dl->AddRectFilled(p, ImVec2(p.x + sz.x, p.y + sz.y), Alpha(color, 0.16f), r);
    dl->AddRect(p, ImVec2(p.x + sz.x, p.y + sz.y), Alpha(color, 0.55f), r, 0, 1.2f);
    const float pulse = 0.6f + 0.4f * sinf((float)ImGui::GetTime() * 2.2f);
    dl->AddCircleFilled(ImVec2(p.x + 9 * s, p.y + sz.y * 0.5f), 3.0f * s,
        Alpha(color, 0.55f + 0.35f * pulse));
    ImGui::SetCursorScreenPos(ImVec2(p.x + 16 * s, p.y + 4 * s));
    ImGui::TextUnformatted(text);
    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + sz.y + 2 * s));
}

// ------------------------------------------------------------------ Card ---
inline bool BeginCard(const char* id, const char* title, ImVec2 size,
                      const char* tip = nullptr) {
    ImGui::PushID(id);
    const float s = g_theme.uiScale;
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, g_theme.cornerRadius);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10 * s, 8 * s));
    bool open = ImGui::BeginChild(id, size, true,
        ImGuiWindowFlags_AlwaysUseWindowPadding);
    if (open && title && title[0]) {
        SectionHeader(title, tip);
    }
    return open;
}
inline void EndCard() {
    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    ImGui::PopID();
}

// ------------------------------------------------------------ GlowSlider ---
// Full-width custom slider: rounded track, luminous fill, glowing thumb,
// hover/active glow, value + units readout, optional tooltip.
inline bool GlowSlider(const char* label, float* v, float vmin, float vmax,
                       const char* fmt = "%.2f", const char* units = "",
                       const char* tip = nullptr, float labelW = 118.0f) {
    const float s = g_theme.uiScale;
    ImGui::PushID(label);
    const float h = 24.0f * s;
    ImVec2 cur = ImGui::GetCursorScreenPos();
    const float avail = ImGui::GetContentRegionAvail().x;
    const float lw = labelW * s;
    const float vw = units && units[0] ? 86.0f * s : 64.0f * s;
    const float sw = (avail - lw - vw > 60 * s) ? (avail - lw - vw) : avail;

    // label (clipped, never overlapping)
    ImGui::SetCursorScreenPos(cur);
    ImGui::PushStyleColor(ImGuiCol_Text, g_theme.textDim);
    ImGui::TextUnformatted(label);
    ImGui::PopStyleColor();

    ImVec2 sp(cur.x + lw, cur.y + h * 0.5f);
    ImVec2 ep(cur.x + lw + sw, cur.y + h * 0.5f);
    const float dt = ImGui::GetIO().DeltaTime;
    const float anim = g_theme.animSpeed;

    // interaction
    ImGui::SetCursorScreenPos(ImVec2(sp.x, cur.y + 2 * s));
    ImGui::InvisibleButton("##slider", ImVec2(sw, h - 4 * s));
    const bool hovered = ImGui::IsItemHovered();
    const bool active = ImGui::IsItemActive();
    bool changed = false;
    if (active) {
        const float t = (ImGui::GetIO().MousePos.x - sp.x) / (sw > 0 ? sw : 1);
        float nv = vmin + t * (vmax - vmin);
        if (nv < vmin) nv = vmin;
        if (nv > vmax) nv = vmax;
        if (nv != *v) { *v = nv; changed = true; }
    }
    HelpTip(tip);

    // smooth displayed fill (time-based, frame-rate independent)
    ImGuiID id = ImGui::GetID("##slider");
    float shown = AnimValue(id, *v);
    const float k = 1.0f - expf(-dt * 14.0f * anim);
    shown += (*v - shown) * k;
    AnimSet(id, shown);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float trackH = 5.0f * s;
    const float ty = cur.y + h * 0.5f;
    const ImU32 trackCol = Alpha(g_theme.accent, 0.14f);
    dl->AddRectFilled(ImVec2(sp.x, ty - trackH * 0.5f),
        ImVec2(ep.x, ty + trackH * 0.5f), trackCol, trackH * 0.5f);

    const float tnorm = (shown - vmin) / ((vmax - vmin) > 0 ? (vmax - vmin) : 1);
    const float fx = sp.x + tnorm * sw;
    const float glowStr = g_theme.glow * (active ? 1.0f : (hovered ? 0.75f : 0.45f));
    // layered luminous fill (cheap: 2 passes, no fullscreen blur)
    dl->AddLine(sp, ImVec2(fx, ty), Alpha(g_theme.accent, 0.18f * glowStr + 0.05f),
        trackH + 5.0f * s * glowStr);
    dl->AddLine(sp, ImVec2(fx, ty), Alpha(g_theme.accent, 0.55f + 0.35f * glowStr),
        trackH);
    dl->AddLine(ImVec2(fx, ty), ImVec2(fx, ty), Alpha(g_theme.accent2, 0.9f), 2.0f);

    // thumb
    const float tr = (active ? 7.0f : 6.0f) * s;
    dl->AddCircleFilled(ImVec2(fx, ty), tr + 5.0f * s * glowStr,
        Alpha(g_theme.accent, 0.16f * glowStr));
    dl->AddCircleFilled(ImVec2(fx, ty), tr, Alpha(g_theme.text, 0.95f));
    dl->AddCircle(ImVec2(fx, ty), tr, Alpha(g_theme.accent, 0.9f), 0, 1.6f);

    // value readout
    char buf[64];
    snprintf(buf, sizeof(buf), fmt, (double)*v);
    ImGui::SetCursorScreenPos(ImVec2(ep.x + 8 * s, cur.y + (h - ImGui::GetTextLineHeight()) * 0.5f));
    ImGui::PushStyleColor(ImGuiCol_Text, g_theme.text);
    if (units && units[0]) ImGui::Text("%s %s", buf, units);
    else ImGui::TextUnformatted(buf);
    ImGui::PopStyleColor();

    ImGui::SetCursorScreenPos(ImVec2(cur.x, cur.y + h + 1 * s));
    ImGui::PopID();
    return changed;
}

inline bool GlowSliderInt(const char* label, int* v, int vmin, int vmax,
                          const char* units = "", const char* tip = nullptr) {
    float f = (float)*v;
    bool c = GlowSlider(label, &f, (float)vmin, (float)vmax, "%.0f", units, tip);
    if (c) *v = (int)(f + 0.5f);
    return c;
}

// ---------------------------------------------------------------- Toggle ---
inline bool Toggle(const char* label, bool* v, const char* tip = nullptr) {
    const float s = g_theme.uiScale;
    ImGui::PushID(label);
    const float h = 20.0f * s, w = 38.0f * s;
    ImVec2 cur = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##tgl", ImVec2(w, h));
    if (ImGui::IsItemClicked()) *v = !*v;
    HelpTip(tip);
    const bool hov = ImGui::IsItemHovered();

    ImGuiID id = ImGui::GetID("##tgl");
    float t = AnimValue(id, *v ? 1.0f : 0.0f);
    const float k = 1.0f - expf(-ImGui::GetIO().DeltaTime * 12.0f * g_theme.animSpeed);
    t += ((*v ? 1.0f : 0.0f) - t) * k;
    AnimSet(id, t);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec4 track = *v ? g_theme.accent : g_theme.textDim;
    dl->AddRectFilled(cur, ImVec2(cur.x + w, cur.y + h),
        Alpha(track, (*v ? (0.35f + 0.25f * g_theme.glow) : 0.25f) + (hov ? 0.10f : 0.0f)),
        h * 0.5f);
    if (*v)
        dl->AddRect(cur, ImVec2(cur.x + w, cur.y + h),
            Alpha(g_theme.accent, 0.5f + 0.3f * g_theme.glow), h * 0.5f, 0, 1.2f);
    const float kx = cur.x + h * 0.5f + t * (w - h);
    dl->AddCircleFilled(ImVec2(kx, cur.y + h * 0.5f), h * 0.36f,
        Alpha(g_theme.text, 0.95f));
    ImGui::SameLine(0, 6 * s);
    ImGui::TextUnformatted(label);
    ImGui::PopID();
    return *v;
}

// -------------------------------------------------------------- GlowButton --
inline bool GlowButton(const char* label, ImVec2 size = ImVec2(0, 0),
                       const char* tip = nullptr) {
    const float s = g_theme.uiScale;
    if (size.x == 0) size.x = 110 * s;
    if (size.y == 0) size.y = 28 * s;
    ImVec2 cur = ImGui::GetCursorScreenPos();
    bool pressed = ImGui::InvisibleButton(label, size);
    const bool hov = ImGui::IsItemHovered();
    const bool act = ImGui::IsItemActive();
    HelpTip(tip);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float pressK = act ? 0.94f : 1.0f; // quick compression feel
    ImVec2 c((cur.x + cur.x + size.x) * 0.5f, (cur.y + cur.y + size.y) * 0.5f);
    ImVec2 p0(cur.x + (size.x - size.x * pressK) * 0.5f,
              cur.y + (size.y - size.y * pressK) * 0.5f);
    ImVec2 p1(p0.x + size.x * pressK, p0.y + size.y * pressK);
    const float r = g_theme.cornerRadius * 0.8f;
    dl->AddRectFilled(p0, p1, Alpha(g_theme.accent, act ? 0.35f : 0.14f), r);
    if (hov || act)
        dl->AddRect(p0, p1, Alpha(g_theme.accent, (hov ? 0.55f : 0.3f) + 0.35f * g_theme.glow),
            r, 0, 1.4f);
    else
        dl->AddRect(p0, p1, Alpha(g_theme.textDim, 0.45f), r, 0, 1.0f);
    ImVec2 ts = ImGui::CalcTextSize(label);
    dl->AddText(ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f),
        ImGui::ColorConvertFloat4ToU32(act ? g_theme.text : (hov ? g_theme.text : g_theme.textDim)),
        label);
    ImGui::SetCursorScreenPos(ImVec2(cur.x, cur.y + size.y + 2 * s));
    return pressed;
}

// ---------------------------------------------------------------- NavItem ---
// Sidebar navigation item: icon + label, hover fade, selected luminous
// edge + constellation particle accent, press compression.
inline bool NavItem(const char* icon, const char* label, bool selected,
                    bool collapsed, float width) {
    const float s = g_theme.uiScale;
    const float h = 38.0f * s;
    ImVec2 cur = ImGui::GetCursorScreenPos();
    ImGui::PushID(label);
    ImGui::InvisibleButton("##nav", ImVec2(width, h));
    const bool hov = ImGui::IsItemHovered();
    const bool act = ImGui::IsItemActive();
    bool clicked = ImGui::IsItemClicked();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    ImGuiID id = ImGui::GetID("##nav");
    float t = AnimValue(id, selected ? 1.0f : 0.0f);
    const float k = 1.0f - expf(-ImGui::GetIO().DeltaTime * 10.0f * g_theme.animSpeed);
    t += ((selected ? 1.0f : 0.0f) - t) * k;
    AnimSet(id, t);

    if (t > 0.01f) {
        dl->AddRectFilled(cur, ImVec2(cur.x + width, cur.y + h),
            Alpha(g_theme.accent, 0.14f * t + (hov ? 0.05f : 0.0f)),
            g_theme.cornerRadius * 0.7f);
        // luminous selection edge
        const float ey0 = cur.y + 6 * s, ey1 = cur.y + h - 6 * s;
        dl->AddLine(ImVec2(cur.x + 1 * s, ey0), ImVec2(cur.x + 1 * s, ey1),
            Alpha(g_theme.accent, 0.25f * g_theme.glow * t), 5.0f * s);
        dl->AddLine(ImVec2(cur.x + 1 * s, ey0), ImVec2(cur.x + 1 * s, ey1),
            Alpha(g_theme.accent, 0.95f * t), 2.0f * s);
        // constellation particle accent
        const float pulse = 0.6f + 0.4f * sinf((float)ImGui::GetTime() * 3.0f);
        dl->AddCircleFilled(ImVec2(cur.x + 10 * s, cur.y + h * 0.5f),
            2.2f * s * pulse + 1.2f * s, Alpha(g_theme.accent2, 0.9f * t));
    } else if (hov) {
        dl->AddRectFilled(cur, ImVec2(cur.x + width, cur.y + h),
            Alpha(g_theme.text, 0.06f), g_theme.cornerRadius * 0.7f);
    }

    const float pressDy = act ? 1.0f * s : 0.0f;
    ImU32 txtCol = ImGui::ColorConvertFloat4ToU32(
        selected ? g_theme.text : (hov ? g_theme.text : g_theme.textDim));
    const float ix = cur.x + (collapsed ? (width - ImGui::CalcTextSize(icon).x) * 0.5f : 16 * s);
    dl->AddText(ImVec2(ix, cur.y + (h - ImGui::GetTextLineHeight()) * 0.5f + pressDy), txtCol, icon);
    if (!collapsed) {
        dl->AddText(ImVec2(cur.x + 38 * s, cur.y + (h - ImGui::GetTextLineHeight()) * 0.5f + pressDy),
            txtCol, label);
    }
    ImGui::SetCursorScreenPos(ImVec2(cur.x, cur.y + h + 2 * s));
    ImGui::PopID();
    return clicked;
}

// ------------------------------------------------------------------- Meter --
inline void Meter(float level, float peak, ImVec2 size, bool horizontal = true) {
    if (level < 0) level = 0; if (level > 1) level = 1;
    if (peak < 0) peak = 0; if (peak > 1) peak = 1;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetCursorScreenPos();
    dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y),
        Alpha(g_theme.textDim, 0.18f), size.y * 0.25f);
    const float glow = 0.35f + 0.45f * g_theme.glow;
    if (horizontal) {
        const float fw = size.x * level;
        if (fw > 0) {
            dl->AddRectFilled(p, ImVec2(p.x + fw, p.y + size.y),
                Alpha(g_theme.accent, 0.20f * glow), size.y * 0.25f);
            dl->AddRectFilled(p, ImVec2(p.x + fw, p.y + size.y),
                Alpha(g_theme.accent, 0.55f * glow + 0.2f), size.y * 0.25f);
        }
        const float px = p.x + size.x * peak;
        dl->AddLine(ImVec2(px, p.y), ImVec2(px, p.y + size.y),
            Alpha(g_theme.accent2, 0.95f), 2.0f);
    } else {
        const float fh = size.y * level;
        if (fh > 0) {
            dl->AddRectFilled(ImVec2(p.x, p.y + size.y - fh),
                ImVec2(p.x + size.x, p.y + size.y),
                Alpha(g_theme.accent, 0.55f * glow + 0.2f), size.x * 0.25f);
        }
        const float py = p.y + size.y - size.y * peak;
        dl->AddLine(ImVec2(p.x, py), ImVec2(p.x + size.x, py),
            Alpha(g_theme.accent2, 0.95f), 2.0f);
    }
    ImGui::Dummy(size);
}

} // namespace lum
