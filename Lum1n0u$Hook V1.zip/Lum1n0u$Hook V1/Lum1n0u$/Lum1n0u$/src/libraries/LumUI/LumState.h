// Lum1n0u$ - centralized application state. by blasphemyw.
// Single source of truth for every DSP parameter, module setting,
// navigation selection, meter value and notification. Previously these
// were scattered (and partly undefined) across translation units.
#pragma once

#include <array>
#include <string>
#include <vector>

// ------------------------------------------------------------------ tabs ---
enum LumTab {
    LumTab_Dashboard = 0,
    LumTab_Encoder,
    LumTab_EQ,
    LumTab_Effects,
    LumTab_Distortion,
    LumTab_Reverb,
    LumTab_VST,
    LumTab_Theme,
    LumTab_Visualizer,
    LumTab_Mixer,
    LumTab_Advanced,
    LumTab_Settings,
    LumTab_About,
    LumTab_Count
};
inline const char* LumTabTitle(int t) {
    static const char* k[] = { "Dashboard", "Encoder", "Equalizer", "Effects",
        "Distortion", "Reverb", "VST Hosting", "Theme", "Visualizer",
        "Mixer", "Advanced", "Settings", "About" };
    return (t >= 0 && t < LumTab_Count) ? k[t] : "Lum1n0u$";
}
inline const char* LumTabIcon(int t) {
    // Geometric glyphs (covered by Segoe UI): distinct from the main logo.
    static const char* k[] = { "\xE2\x97\x88", "\xE2\x97\x86", "\xE2\x89\x8B",
        "\xE2\x9C\xA6", "\xE2\x97\x8F", "\xE2\x97\x8C", "\xE2\xAC\xA2",
        "\xE2\x9C\xA6", "\xE2\x97\x94", "\xE2\x97\x8D", "\xE2\x9A\xAD",
        "\xE2\x9A\x99", "\xE2\x97\x87" };
    return (t >= 0 && t < LumTab_Count) ? k[t] : "?";
}

inline int  g_activeTab = LumTab_Dashboard;
inline bool g_sidebarCollapsed = false;

// ------------------------------------------------------------------ window -
inline int   g_winW = 1280, g_winH = 800;
inline int   g_winX = 100, g_winY = 100;
inline bool  g_winMaximized = false;
inline bool  g_windowPosLoaded = false;

// ------------------------------------------------------------------ status -
inline float g_inputLevel = 0.0f, g_outputLevel = 0.0f;
inline float g_peakHold = 0.0f, g_peakHoldTimer = 0.0f;
inline float g_cpuUsage = 0.0f;
inline bool  g_processingEnabled = true;
inline bool  g_masterMuted = false;
inline float g_masterGain = 1.0f;
inline char  g_currentPreset[64] = "Default";
inline bool  g_hookConnected = false; // set once discord_voice hooks install

// ------------------------------------------------- legacy encoder / gain ---
// (Names preserved so the existing hook + Lua bindings keep working;
//  values are now properly defined exactly once, here.)
inline float Gain = 10.0f, ExpGain = 10.0f, Bitrate = 96000.0f;

// ------------------------------------------------------------ encoder ------
inline int   g_encCodec = 0;            // 0 = Opus
inline int   g_encSampleRateIdx = 2;    // 8k,16k,48k -> default 48k
inline int   g_encChannels = 2;
inline int   g_encFrameSize = 960;
inline int   g_opusComplexity = 10;
inline bool  g_opusVBR = true;
inline bool  g_opusConstrainedVBR = true;
inline bool  g_opusFEC = false;
inline bool  g_opusDTX = false;
inline float g_opusPacketLoss = 0.0f;   // percent
inline int   g_opusBandwidthIdx = 4;    // NB,MB,WB,SWB,FB
inline int   g_opusAppModeIdx = 0;      // Audio, VoIP, LowDelay
inline int   g_opusSignalIdx = 0;       // Auto, Voice, Music

// ------------------------------------------------------------- reverb ------
inline bool  g_revEnabled = false;
inline float reverbSize = 0.5f, reverbDamping = 0.5f, reverbWidth = 1.0f;
inline float reverbPredelay = 0.02f, reverbMakeupGain = 1.0f;
inline float ReverbAmount = 0.35f, ReverbDecay = 0.5f;
// extended reverb module
inline float g_revDiffusion = 0.7f, g_revWet = 0.35f, g_revDry = 0.8f;
inline float g_revEarly = 0.6f, g_revLate = 0.7f;
inline float g_revLowCut = 120.0f, g_revHighCut = 9000.0f;
inline int   g_revPreset = 2; // Hall

// ------------------------------------------------------------ clarity ------
inline bool  apply_clarity_enhancer = false;
inline float clarity_q = 1.0f, clarity_freq = 2500.0f;
inline float clarity_gain = 6.0f, clarity_mix = 0.5f;
inline bool  apply_expander = false;

// ----------------------------------------------------------- eq / filter ---
inline bool  apply_eq = false;
inline float eq_low_gain = 0.0f, eq_mid_gain = 0.0f, eq_high_gain = 0.0f;
inline bool  apply_lowpass = false, apply_highpass = false;
inline float lowpass_freq = 8000.0f, highpass_freq = 80.0f;

// 10-band professional EQ. Dragging graph nodes edits gain (+/-12 dB)
// vertically and nudges frequency horizontally within its slot.
inline bool  g_eq10Bypass = false;
inline std::array<float, 10> g_eq10Gain = { 0,0,0,0,0,0,0,0,0,0 };
inline std::array<float, 10> g_eq10Q = { 1,1,1,1,1,1,1,1,1,1 };
inline std::array<float, 10> g_eq10Freq = { 31,62,125,250,500,1000,2000,4000,8000,16000 };
inline std::array<int, 10>   g_eq10Type = { 0,0,0,0,0,0,0,0,0,0 }; // 0 Peak 1 LowShelf 2 HighShelf
inline std::array<bool, 10>  g_eq10BypassBand = { 0,0,0,0,0,0,0,0,0,0 };

// ------------------------------------------------------------ bit fx -------
inline bool  apply_saturation = false;
inline float saturation_drive = 2.0f;
inline bool  apply_bitcrusher = false;
inline int   bitcrusher_bits = 12;
inline float bitcrusher_rate = 0.5f;

// ------------------------------------------------------------ dynamics -----
inline bool  apply_gate = false;
inline float gate_threshold = 0.1f, gate_attack = 0.005f, gate_release = 0.1f;
inline bool  apply_compressor = false;
inline float comp_threshold = -18.0f, comp_ratio = 3.0f;
inline bool  apply_limiter = false;
inline float lim_ceiling = -1.0f;
inline bool  apply_auto_gain = false;
inline float auto_gain_target = 0.8f;

// ------------------------------------------------------------ modulation ---
inline bool  apply_chorus = false;
inline float chorus_rate = 1.0f, chorus_depth = 0.3f;
inline bool  apply_flanger = false;
inline float flanger_rate = 0.25f, flanger_depth = 0.4f;
inline bool  apply_tremolo = false;
inline float tremolo_rate = 5.0f, tremolo_depth = 0.5f;
inline bool  apply_pitch_shift = false;
inline float pitch_semitones = 0.0f;

// ------------------------------------------------------------ spatial ------
inline bool  apply_stereo_enhancer = false;
inline float stereoWidth = 1.0f, pan = 0.0f;
inline bool  apply_haas = false;
inline float haas_delay_ms = 12.0f;
inline bool  apply_delay = false; // echo
inline float delay_time = 0.3f, delay_feedback = 0.35f;
inline bool  invert_phase = false;
inline bool  apply_softclip = false;
inline float softclip_curve = 0.5f;

// ------------------------------------------------------------ output -------
inline float outputGain = 1.0f;
inline bool  muteOutput = false;
inline float dryWetMix = 1.0f;
inline bool  bypassAll = false;

// ------------------------------------------------------------ distortion ---
// Modes: 0 Soft Clip, 1 Hard Clip, 2 Tube, 3 Tape, 4 Bit Crush,
//        5 Foldback, 6 Wave Shaper.
inline bool  g_distEnabled = false;
inline int   g_distMode = 0;
inline float g_distDrive = 4.0f, g_distInGain = 1.0f, g_distOutGain = 0.8f;
inline float g_distMix = 1.0f, g_distTone = 0.6f, g_distClipThresh = 0.8f;
inline bool  g_distSoftClip = true, g_distHardClip = false;
inline int   g_distWaveshaper = 0, g_distOversample = 1; // x1,x2,x4,x8
inline float g_distPreEmph = 0.0f, g_distPostEmph = 0.0f;
inline bool  g_distStereoLink = true;

// ------------------------------------------------------------ mixer --------
struct LumChannel {
    char  name[32] = "CH";
    float gain = 1.0f, pan = 0.0f;
    bool  mute = false, solo = false;
    float levelL = 0.0f, levelR = 0.0f, peak = 0.0f;
};
inline std::array<LumChannel, 8> g_mixer = { {
    {"Input"}, {"Voice"}, {"Music"}, {"Game"},
    {"Aux 1"}, {"Aux 2"}, {"VST 1"}, {"VST 2"},
} };
inline float g_mixerMaster = 1.0f;
inline bool  g_mixerMasterMute = false;
inline bool  g_mixerLimiter = true;
inline float g_mixerLimiterCeil = -1.0f;

// ------------------------------------------------------------ visualizer ---
inline int   g_visMode = 0; // spectrum, waveform, bars, circular,
//                           constellation, oscilloscope, stereo, history
inline float g_visScale = 1.0f;
inline bool  g_visFreeze = false;

// ------------------------------------------------------------ vst ui -------
inline std::vector<std::string> g_vstFavorites;
inline std::vector<std::string> g_vstRecent;
inline std::vector<std::string> g_vstFolders; // extra scan folders
inline char  g_vstSearch[128] = "";
inline char  g_vstCustomPath[512] = "C:\\Program Files\\VSTPlugins";
inline bool  g_vstShowFavoritesOnly = false;

// Per-module mix for the 12-slot effects chain (persisted).
inline std::array<float, 12> g_fxMix = { 1,1,1,1,1,1,1,1,1,1,1,1 };

// ------------------------------------------------------------ settings -----
struct LumSettings {
    // performance
    int  renderQuality = 1;   // 0 eco, 1 balanced, 2 ultra
    int  visFPS = 60;
    bool bgEffects = true;
    int  workerThreads = 2;
    // audio
    int  sampleRateIdx = 2;   // 44100, 48000
    int  channelMode = 1;     // mono, stereo
    int  bufferSize = 512;
    int  processingMode = 0;  // realtime, low-latency, quality
    // behavior
    int  startupTab = 0;
    bool rememberPos = true;
    bool rememberTheme = true;
    bool autosave = true;
    // advanced
    bool debugLog = false;
    bool diagMode = false;
    bool internalStats = false;
};
inline LumSettings g_settings;

// ------------------------------------------------------------ logging ------
enum class LumLogLevel { Info = 0, Warning, Error, Debug };
struct LumLogEntry {
    LumLogLevel level = LumLogLevel::Info;
    std::string text;
    double      time = 0.0;
};
inline std::vector<LumLogEntry> g_logRing;
inline const size_t kLumLogMax = 400;
inline double g_appTime = 0.0;
inline void LumLog(LumLogLevel lv, const std::string& msg) {
    if (lv == LumLogLevel::Debug && !g_settings.debugLog) return;
    if (g_logRing.size() >= kLumLogMax) g_logRing.erase(g_logRing.begin());
    g_logRing.push_back({ lv, msg, g_appTime });
}

// ------------------------------------------------------------ notifications
struct LumToast {
    LumLogLevel level = LumLogLevel::Info;
    std::string title, message;
    float expiry = 0.0f; // app-time seconds
};
inline std::vector<LumToast> g_toasts;
inline void LumToastPush(LumLogLevel lv, const char* title, const std::string& msg,
                         float ttl = 4.0f) {
    if (g_toasts.size() > 5) g_toasts.erase(g_toasts.begin());
    g_toasts.push_back({ lv, title ? title : "", msg,
                         (float)g_appTime + ttl });
    LumLog(lv, std::string(title ? title : "") + ": " + msg);
}
