int silk_LPC_fit() {
	return 0;
}