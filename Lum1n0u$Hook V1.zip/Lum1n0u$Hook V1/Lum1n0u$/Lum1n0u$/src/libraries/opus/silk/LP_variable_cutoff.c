int silk_LP_variable_cutoff() {
	return 0;
}