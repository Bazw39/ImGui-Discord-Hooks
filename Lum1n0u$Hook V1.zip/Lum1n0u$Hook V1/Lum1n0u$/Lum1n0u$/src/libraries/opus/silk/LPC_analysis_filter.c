int silk_LPC_analysis_filter() {
	return 0;
}