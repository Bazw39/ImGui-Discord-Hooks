int silk_LPC_inverse_pred_gain_c() {
	return 0;
}