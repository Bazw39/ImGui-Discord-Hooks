int opus_multistream_decode_native() {
	return 0;
}

int opus_multistream_decoder_ctl_va_list() {
	return 0;
}

int opus_multistream_decoder_get_size() {
	return 0;
}

int opus_multistream_decoder_init() {
	return 0;
}