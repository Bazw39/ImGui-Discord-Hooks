int silk_VAD_GetNoiseLevels() {
	return 0;
}
int silk_noise_shape_quantizer() {

}
int tonality_analysis_init() {

}
int opus_multistream_encode_native() {

}
int opus_multistream_encoder_ctl_va_list() {

 }
