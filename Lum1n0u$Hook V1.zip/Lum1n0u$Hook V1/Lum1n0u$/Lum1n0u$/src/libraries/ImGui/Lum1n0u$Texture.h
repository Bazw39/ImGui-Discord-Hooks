// Lum1n0u$ - application/logo texture interface. by blasphemyw.
#pragma once
#include <d3d9.h>

// Device texture built from the embedded Lum1n0u$.h constellation logo.
extern LPDIRECT3DTEXTURE9 g_LuminosTexture;

// Call after the D3D device exists; safe to call repeatedly.
void LoadLuminosTexture(LPDIRECT3DDEVICE9 device);

// Release on device reset / shutdown.
void ReleaseLuminosTexture();
