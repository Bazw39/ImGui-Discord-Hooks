﻿// Lum1n0u$ - constellation workstation UI (part 1/3). by blasphemyw.
// Dear ImGui + Win32 + DirectX9 overlay for the Discord voice hook.
// Architecture: centralized state (LumState), theme engine (LumTheme),
// reusable widgets (LumWidgets), background/logo (LumBackground),
// versioned persistence (LumConfig). Audio/VST backends preserved.
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#define NOMINMAX
#include "HookGui.hpp"
#include "LumUI/LumTheme.h"
#include "LumUI/LumState.h"
#include "LumUI/LumWidgets.h"
#include "LumUI/LumBackground.h"
#include "LumUI/LumConfig.h"
#include "../vst/VSTHost.h"
#include "libraries/opus/include/opus.h"
#include "libraries/lua/lua.hpp"
#include "imgui/Include/d3dx9tex.h"
#include "Lum1n0u$.h"
#include "Lum1n0u$Texture.h"
#include "../../resource.h"
#include <windows.h>
#include <commdlg.h>
#include <shellapi.h>
#include <direct.h>
#include <TlHelp32.h>
#include <iostream>
#include <fstream>
#include <thread>
#include <mutex>
#include <vector>
#include <string>
#include <chrono>
#include <cmath>
#include <complex>
#include <valarray>
#include <algorithm>
#include <cfloat>
#include <cctype>
#include <cstdio>
#include <cstdarg>
#include <cstdlib>
#include <cstring>
#include <atomic>

// ------------------------------------------------------- hook-side externs -
extern std::vector<float> pcm_graph_data;
extern std::mutex pcm_graph_mutex;
extern std::vector<float> db_graph_data;
extern std::mutex db_graph_mutex;
extern char g_lumAnalyzerLabel[128];
extern bool dbcheck;
extern bool forceNotNatty;
extern bool int16check;
extern bool selfcheck;
extern HMODULE g_lumModule; // our DLL handle, set in DllMain

// ------------------------------------------------------------------ locals -
inline HWND g_Window = nullptr;
LPDIRECT3DTEXTURE9 g_LuminosTexture = nullptr;

static HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
static bool   g_showLogs = false;
static HHOOK  hHook = nullptr;
static BYTE*  memoryBase = nullptr;
static SIZE_T memoryRegionSize = 0;

static std::atomic<bool> g_closing{ false };

// ------------------------------------------------------------------- toast -
static void RenderToasts() {
    while (!g_toasts.empty() && (float)g_appTime > g_toasts.front().expiry)
        g_toasts.erase(g_toasts.begin());
    if (g_toasts.empty()) return;
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(
        ImVec2(vp->Pos.x + vp->Size.x - 14, vp->Pos.y + vp->Size.y - 44),
        ImGuiCond_Always, ImVec2(1.0f, 1.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10, 8));
    ImGui::Begin("##lum_toasts", nullptr,
        ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoInputs |
        ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoFocusOnAppearing |
        ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoMove);
    for (size_t i = 0; i < g_toasts.size(); ++i) {
        const LumToast& t = g_toasts[i];
        ImVec4 col = g_theme.accent;
        const char* tag = "INFO";
        if (t.level == LumLogLevel::Warning) { col = ImVec4(1.0f, 0.72f, 0.25f, 1.0f); tag = "WARN"; }
        if (t.level == LumLogLevel::Error)   { col = ImVec4(0.95f, 0.30f, 0.30f, 1.0f); tag = "ERROR"; }
        if (t.level == LumLogLevel::Debug)   { col = g_theme.textDim; tag = "DEBUG"; }
        ImGui::PushID((int)i);
        ImVec2 p = ImGui::GetCursorScreenPos();
        ImVec2 ts = ImGui::CalcTextSize(t.message.c_str());
        float w = (std::max)(ts.x + 20.0f, 220.0f);
        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRectFilled(p, ImVec2(p.x + w, p.y + 44),
            ImGui::ColorConvertFloat4ToU32(ImVec4(0.02f, 0.03f, 0.06f, 0.95f)), 6.0f);
        dl->AddRect(p, ImVec2(p.x + w, p.y + 44),
            ImGui::ColorConvertFloat4ToU32(ImVec4(col.x, col.y, col.z, 0.6f)), 6.0f, 0, 1.2f);
        dl->AddRectFilled(ImVec2(p.x, p.y), ImVec2(p.x + 3, p.y + 44),
            ImGui::ColorConvertFloat4ToU32(col), 2.0f);
        ImGui::SetCursorScreenPos(ImVec2(p.x + 10, p.y + 4));
        ImGui::TextColored(col, "[%s] %s", tag, t.title.c_str());
        ImGui::SetCursorScreenPos(ImVec2(p.x + 10, p.y + 22));
        ImGui::PushStyleColor(ImGuiCol_Text, g_theme.text);
        ImGui::TextUnformatted(t.message.c_str());
        ImGui::PopStyleColor();
        ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + 48));
        ImGui::PopID();
    }
    ImGui::End();
    ImGui::PopStyleVar();
}

// ------------------------------------------------------------ logging -------
static void LumConsolePrint(LumLogLevel lv, const std::string& s) {
    if (!hConsole) return;
    WORD attr = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE;
    if (lv == LumLogLevel::Warning) attr = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY;
    else if (lv == LumLogLevel::Error) attr = FOREGROUND_RED | FOREGROUND_INTENSITY;
    else if (lv == LumLogLevel::Debug) attr = FOREGROUND_BLUE | FOREGROUND_GREEN;
    SetConsoleTextAttribute(hConsole, attr);
    printf("%s\n", s.c_str());
    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
}
void AddLog(const char* fmt, ...) {
    char buf[2048];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    std::string text = buf;
    LumLogLevel lv = LumLogLevel::Info;
    std::string msg = text;
    if (text.find("[Lua Error]") == 0) { lv = LumLogLevel::Error; msg = text.substr(11); }
    else if (text.find("[Lua]") == 0) { msg = text.substr(5); }
    LumLog(lv, msg);
    LumConsolePrint(lv, text);
}

// --------------------------------------------------------------------- lua -
static lua_State* L = nullptr;
int Lua_SetGain(lua_State* Ls);
int Lua_SetExpGain(lua_State* Ls);
int Lua_SetBitrate(lua_State* Ls);
int Lua_SetMaster(lua_State* Ls);
int Lua_SetReverb(lua_State* Ls);

static void RegisterLuaFunctions() {
    if (!L) return;
    lua_register(L, "setgain", Lua_SetGain);
    lua_register(L, "setexpgain", Lua_SetExpGain);
    lua_register(L, "setbitrate", Lua_SetBitrate);
    lua_register(L, "setmaster", Lua_SetMaster);
    lua_register(L, "setreverb", Lua_SetReverb);
}
static void InitLua() {
    if (!L) {
        L = luaL_newstate();
        luaL_openlibs(L);
        RegisterLuaFunctions();
        AddLog("[Lua] Initialized.");
    }
}
static void ShutdownLua() {
    if (L) { lua_close(L); L = nullptr; AddLog("[Lua] Shutdown."); }
}
int Lua_SetGain(lua_State* Ls)    { Gain = (float)luaL_checknumber(Ls, 1); AddLog("[Lua] Gain set to %.2f", (double)Gain); return 0; }
int Lua_SetExpGain(lua_State* Ls) { ExpGain = (float)luaL_checknumber(Ls, 1); AddLog("[Lua] ExpGain set to %.2f", (double)ExpGain); return 0; }
int Lua_SetBitrate(lua_State* Ls) { Bitrate = (float)luaL_checknumber(Ls, 1); AddLog("[Lua] Bitrate set to %.0f", (double)Bitrate); return 0; }
int Lua_SetMaster(lua_State* Ls)  { g_masterGain = (float)luaL_checknumber(Ls, 1); AddLog("[Lua] Master gain set to %.2f", (double)g_masterGain); return 0; }
int Lua_SetReverb(lua_State* Ls)  { ReverbAmount = (float)luaL_checknumber(Ls, 1); AddLog("[Lua] Reverb amount set to %.2f", (double)ReverbAmount); return 0; }

// ------------------------------------------------------------- stealth -----
// (Preserved backend utilities, now hosted under Advanced -> Stealth.)
static bool IsDebuggerPresentAdvanced() {
    BOOL d = FALSE;
    return IsDebuggerPresent() || (CheckRemoteDebuggerPresent(GetCurrentProcess(), &d) && d);
}
static void ObfuscateModuleName() {
    HMODULE hm = g_lumModule ? g_lumModule : GetModuleHandleA(nullptr);
    MODULEENTRY32W me = { sizeof(MODULEENTRY32W) };
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, GetCurrentProcessId());
    if (snap == INVALID_HANDLE_VALUE) return;
    if (Module32FirstW(snap, &me)) do {
        if (me.hModule == hm) {
            DWORD o; VirtualProtect(me.szModule, sizeof(me.szModule), PAGE_READWRITE, &o);
            wcscpy_s(me.szModule, L"ntdll.dll");
            VirtualProtect(me.szModule, sizeof(me.szModule), o, &o);
            break;
        }
    } while (Module32NextW(snap, &me));
    CloseHandle(snap);
}
static void ClearPEHeaders() {
    HMODULE hm = g_lumModule ? g_lumModule : GetModuleHandleA(nullptr);
    if (!hm) return;
    BYTE* base = reinterpret_cast<BYTE*>(hm);
    IMAGE_DOS_HEADER* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;
    IMAGE_NT_HEADERS* nt = reinterpret_cast<IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;
    DWORD o;
    SIZE_T n = sizeof(IMAGE_DOS_HEADER) + sizeof(IMAGE_NT_HEADERS);
    VirtualProtect(base, n, PAGE_READWRITE, &o);
    memset(base, 0, n);
    VirtualProtect(base, n, o, &o);
}
static void HideThreadStartAddress() {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, GetCurrentProcessId());
    if (snap == INVALID_HANDLE_VALUE) return;
    THREADENTRY32 te = { sizeof(THREADENTRY32) };
    if (Thread32First(snap, &te)) do {
        HANDLE th = OpenThread(THREAD_SET_CONTEXT, FALSE, te.th32ThreadID);
        if (th) {
            CONTEXT c = {}; c.ContextFlags = CONTEXT_CONTROL;
            if (GetThreadContext(th, &c)) {
                c.Rip = reinterpret_cast<DWORD64>(
                    GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "NtYieldExecution"));
                SetThreadContext(th, &c);
            }
            CloseHandle(th);
        }
    } while (Thread32Next(snap, &te));
    CloseHandle(snap);
}
static void ClearDebugInfo() {
    HMODULE hm = g_lumModule ? g_lumModule : GetModuleHandleA(nullptr);
    if (!hm) return;
    BYTE* base = reinterpret_cast<BYTE*>(hm);
    IMAGE_DOS_HEADER* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;
    IMAGE_NT_HEADERS* nt = reinterpret_cast<IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;
    IMAGE_DATA_DIRECTORY* dd = &nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG];
    if (dd->VirtualAddress) {
        DWORD o;
        VirtualProtect(base + dd->VirtualAddress, dd->Size, PAGE_READWRITE, &o);
        memset(base + dd->VirtualAddress, 0, dd->Size);
        VirtualProtect(base + dd->VirtualAddress, dd->Size, o, &o);
    }
}
static void ClearEventLogs() {
    HANDLE h = OpenEventLogW(nullptr, L"Application");
    if (h) { ClearEventLogW(h, nullptr); CloseEventLog(h); }
    h = OpenEventLogW(nullptr, L"System");
    if (h) { ClearEventLogW(h, nullptr); CloseEventLog(h); }
}
static void SelfDestruct() {
    if (hHook) { UnhookWindowsHookEx(hHook); hHook = nullptr; }
    HMODULE hm = g_lumModule;
    if (hm) FreeLibraryAndExitThread(hm, 0);
}
static std::wstring ConvertToWide(const char* s) {
    int len = MultiByteToWideChar(CP_UTF8, 0, s, -1, nullptr, 0);
    std::wstring w((size_t)(len > 0 ? len : 1), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s, -1, &w[0], len);
    return w;
}

// ------------------------------------------------------- audio analysis ----
using Complex = std::complex<float>;
using CArray = std::valarray<Complex>;
static void FFT(CArray& x) {
    size_t N = x.size();
    if (N <= 1) return;
    CArray even = x[std::slice(0, N / 2, 2)];
    CArray odd = x[std::slice(1, N / 2, 2)];
    FFT(even); FFT(odd);
    for (size_t k = 0; k < N / 2; k++) {
        float ang = -2.0f * 3.14159265f * (float)k / (float)N;
        Complex t = std::exp(Complex(0, ang)) * odd[k];
        x[k] = even[k] + t;
        x[k + N / 2] = even[k] - t;
    }
}
static std::vector<float> SnapPCM(size_t maxSamples = 8192) {
    std::lock_guard<std::mutex> lk(pcm_graph_mutex);
    if (pcm_graph_data.empty()) return {};
    size_t n = (std::min)(maxSamples, pcm_graph_data.size());
    return std::vector<float>(pcm_graph_data.end() - n, pcm_graph_data.end());
}
static float PCMLevel(const std::vector<float>& s) {
    if (s.empty()) return 0.0f;
    double acc = 0.0;
    size_t n = (std::min)(s.size(), (size_t)2048);
    for (size_t i = s.size() - n; i < s.size(); ++i) acc += (double)s[i] * s[i];
    return (float)sqrt(acc / (double)n);
}
static std::vector<float> SpectrumMags(const std::vector<float>& s, int N = 512) {
    std::vector<float> out;
    if ((int)s.size() < N) return out;
    std::vector<Complex> in((size_t)N);
    for (int i = 0; i < N; i++) {
        float w = 0.5f * (1 - cosf(2.0f * 3.14159265f * i / (N - 1)));
        in[(size_t)i] = Complex(s[s.size() - N + i] * w, 0.0f);
    }
    CArray d(in.data(), N);
    FFT(d);
    out.resize((size_t)N / 2);
    float mx = 1e-6f;
    for (int i = 0; i < N / 2; i++) { out[(size_t)i] = std::abs(d[(size_t)i]); mx = (std::max)(mx, out[(size_t)i]); }
    for (float& v : out) v /= mx;
    return out;
}
static void DrawSpectrumPolyline(ImDrawList* dl, ImVec2 pos, ImVec2 size,
                                 const std::vector<float>& mags, float glowMul = 1.0f) {
    if (mags.empty() || size.x <= 0 || size.y <= 0) return;
    const int n = (int)mags.size();
    const float glow = g_theme.glow * glowMul;
    ImVec2 prev(0, 0);
    for (int i = 0; i < n; ++i) {
        ImVec2 p(pos.x + (float)i / (float)n * size.x,
                 pos.y + size.y - mags[(size_t)i] * size.y);
        if (i > 0) {
            dl->AddLine(prev, p, ImGui::ColorConvertFloat4ToU32(
                ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.18f * glow + 0.05f)), 4.0f);
            dl->AddLine(prev, p, ImGui::ColorConvertFloat4ToU32(
                ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.9f)), 1.6f);
        }
        prev = p;
    }
    for (int i = 0; i < n - 1; i += 2) {
        ImVec2 a(pos.x + (float)i / (float)n * size.x,
                 pos.y + size.y - mags[(size_t)i] * size.y);
        ImVec2 b(pos.x + (float)(i + 1) / (float)n * size.x,
                 pos.y + size.y - mags[(size_t)(i + 1)] * size.y);
        dl->AddQuadFilled(a, b, ImVec2(b.x, pos.y + size.y), ImVec2(a.x, pos.y + size.y),
            ImGui::ColorConvertFloat4ToU32(
                ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.08f)));
    }
}
static float Eq10Response(float freq) {
    float db = 0.0f;
    for (int i = 0; i < 10; ++i) {
        if (g_eq10BypassBand[(size_t)i]) continue;
        const float f = g_eq10Freq[(size_t)i] > 1.0f ? g_eq10Freq[(size_t)i] : 20.0f;
        const float x = log2f(freq / f);
        if (g_eq10Type[(size_t)i] == 1)
            db += g_eq10Gain[(size_t)i] / (1.0f + expf(3.0f * x));
        else if (g_eq10Type[(size_t)i] == 2)
            db += g_eq10Gain[(size_t)i] / (1.0f + expf(-3.0f * x));
        else {
            const float q = (std::max)(0.3f, g_eq10Q[(size_t)i]);
            db += g_eq10Gain[(size_t)i] * expf(-0.5f * (x * q) * (x * q));
        }
    }
    return db;
}

// ------------------------------------------------------------- file pick ---
static std::string OpenFileDialog() {
    char filename[MAX_PATH] = "";
    OPENFILENAMEA ofn;
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.lpstrFile = filename;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = "VST Plugins (*.dll;*.vst3)\0*.dll;*.vst3\0All Files (*.*)\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
    if (GetOpenFileNameA(&ofn)) return std::string(filename);
    return "";
}

// ------------------------------------------------------- vst background ----
static std::thread g_scanThread;
static std::atomic<bool> g_scanning{ false };
static std::atomic<int> g_scanDone{ 0 }, g_scanTotal{ 1 };
static std::mutex g_scanMutex;
static std::vector<std::string> g_scanResults;

static void StartVSTScan() {
    if (g_scanning || !g_vstHost) return;
    g_scanning = true;
    g_scanDone = 0;
    std::vector<std::string> dirs;
    if (g_vstCustomPath[0]) dirs.push_back(g_vstCustomPath);
    for (auto& d : g_vstFolders) dirs.push_back(d);
    for (auto& d : g_vstHost->getCommonVSTDirectories()) dirs.push_back(d);
    g_scanTotal = (int)dirs.size() > 0 ? (int)dirs.size() : 1;
    if (g_scanThread.joinable()) g_scanThread.join();
    g_scanThread = std::thread([dirs]() {
        std::vector<std::string> found;
        for (size_t di = 0; di < dirs.size(); ++di) {
            for (const char* ext : { "\\*.dll", "\\*.vst3" }) {
                std::string pat = dirs[di] + ext;
                WIN32_FIND_DATAA fd;
                HANDLE h = FindFirstFileA(pat.c_str(), &fd);
                if (h == INVALID_HANDLE_VALUE) continue;
                do {
                    if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
                    std::string fp = dirs[di] + "\\" + fd.cFileName;
                    if (g_vstHost && g_vstHost->isVSTFile(fp))
                        found.push_back(fp);
                } while (FindNextFileA(h, &fd));
                FindClose(h);
            }
            g_scanDone = (int)di + 1;
        }
        {
            std::lock_guard<std::mutex> lk(g_scanMutex);
            g_scanResults = found;
        }
        g_scanning = false;
    });
    g_scanThread.detach();
}
static void VstAddRecent(const std::string& p) {
    auto it = std::find(g_vstRecent.begin(), g_vstRecent.end(), p);
    if (it != g_vstRecent.end()) g_vstRecent.erase(it);
    g_vstRecent.insert(g_vstRecent.begin(), p);
    if (g_vstRecent.size() > 10) g_vstRecent.pop_back();
}
static void VstPresetPath(VSTPlugin* p, char* out, size_t cap) {
    const char* appdata = getenv("APPDATA");
    std::string safe = p ? p->getEffectName() : "plugin";
    for (char& c : safe) if (c == '\\' || c == '/' || c == ':' || c == ' ') c = '_';
    snprintf(out, cap, "%s\\Lum1n0u$\\presets\\%s.lumvst",
        appdata ? appdata : ".", safe.c_str());
}
static void VstSavePreset(VSTPlugin* p) {
    if (!p || !p->isLoaded()) { LumToastPush(LumLogLevel::Warning, "VST", "No plugin selected."); return; }
    char path[512]; VstPresetPath(p, path, sizeof(path));
    char dir[512]; snprintf(dir, sizeof(dir), "%s", path);
    if (char* bs = strrchr(dir, '\\')) { *bs = 0; _mkdir(dir); }
    FILE* f = nullptr; fopen_s(&f, path, "w");
    if (!f) { LumToastPush(LumLogLevel::Error, "VST", "Could not write preset file."); return; }
    fprintf(f, "# Lum1n0u$ VST preset for %s\n", p->getEffectName().c_str());
    for (int i = 0; i < p->getNumParameters(); ++i)
        fprintf(f, "%d=%.6f\n", i, (double)p->getParameter(i));
    fclose(f);
    LumToastPush(LumLogLevel::Info, "VST", "Preset saved: " + p->getEffectName());
}
static void VstLoadPreset(VSTPlugin* p) {
    if (!p || !p->isLoaded()) { LumToastPush(LumLogLevel::Warning, "VST", "No plugin selected."); return; }
    char path[512]; VstPresetPath(p, path, sizeof(path));
    FILE* f = nullptr; fopen_s(&f, path, "r");
    if (!f) { LumToastPush(LumLogLevel::Warning, "VST", "No saved preset for this plugin."); return; }
    char line[256]; int n = 0;
    while (fgets(line, sizeof(line), f)) {
        int idx; float v;
        if (sscanf_s(line, "%d=%f", &idx, &v) == 2) { p->setParameter(idx, v); ++n; }
    }
    fclose(f);
    LumToastPush(LumLogLevel::Info, "VST", "Preset loaded (" + std::to_string(n) + " params).");
}

// -------------------------------------------------------------- presets ----
static void ApplyReverbPreset(int idx) {
    struct RP { float size, decay, damp, pred, wet, dry, diff, width, early, late; };
    static const RP k[] = {
        {0.25f,0.25f,0.60f,0.005f,0.25f,0.85f,0.50f,0.8f,0.7f,0.4f},
        {0.40f,0.40f,0.50f,0.010f,0.30f,0.80f,0.65f,1.0f,0.6f,0.6f},
        {0.65f,0.60f,0.40f,0.020f,0.38f,0.75f,0.75f,1.2f,0.6f,0.8f},
        {0.90f,0.85f,0.30f,0.035f,0.45f,0.70f,0.85f,1.5f,0.5f,0.9f},
        {0.70f,0.75f,0.75f,0.025f,0.42f,0.72f,0.70f,1.1f,0.4f,0.8f},
        {1.00f,0.95f,0.20f,0.060f,0.55f,0.60f,0.95f,1.8f,0.3f,1.0f},
        {1.00f,1.00f,0.10f,0.080f,0.65f,0.50f,1.00f,2.0f,0.2f,1.0f},
    };
    if (idx < 0 || idx > 6) return;
    g_revPreset = idx;
    reverbSize = k[idx].size; ReverbDecay = k[idx].decay;
    reverbDamping = k[idx].damp; reverbPredelay = k[idx].pred;
    g_revWet = k[idx].wet; g_revDry = k[idx].dry;
    g_revDiffusion = k[idx].diff; reverbWidth = k[idx].width;
    g_revEarly = k[idx].early; g_revLate = k[idx].late;
}
static void ApplyLumPreset(int idx) {
    if (idx == 1) {
        apply_clarity_enhancer = true; clarity_freq = 2800; clarity_gain = 7; clarity_q = 1.4f; clarity_mix = 0.6f;
        apply_highpass = true; highpass_freq = 90; apply_gate = true; gate_threshold = 0.08f;
        apply_compressor = true; comp_threshold = -18; comp_ratio = 3;
    } else if (idx == 2) {
        apply_eq = true; eq_low_gain = 5; eq_mid_gain = 1; eq_high_gain = -2;
        g_revEnabled = true; ApplyReverbPreset(0);
    } else if (idx == 3) {
        apply_compressor = true; comp_threshold = -14; comp_ratio = 4;
        apply_limiter = true; lim_ceiling = -1.5f;
        apply_clarity_enhancer = true; clarity_gain = 4; clarity_freq = 3200;
        Bitrate = 128000;
    } else {
        apply_clarity_enhancer = false; apply_eq = false; apply_gate = false;
        apply_compressor = false; apply_limiter = false; g_revEnabled = false;
        eq_low_gain = eq_mid_gain = eq_high_gain = 0;
    }
    snprintf(g_currentPreset, sizeof(g_currentPreset), "%s",
        idx == 0 ? "Default" : idx == 1 ? "Voice Clarity" : idx == 2 ? "Bass Room" : "Broadcast");
}
static void ResetEQ10() {
    g_eq10Gain.fill(0.0f); g_eq10Q.fill(1.0f); g_eq10BypassBand.fill(false);
    g_eq10Freq = { 31,62,125,250,500,1000,2000,4000,8000,16000 };
    g_eq10Type.fill(0);
}

// -------------------------------------------------------------- cpu meter --
static float PollCPU() {
    static ULARGE_INTEGER prevIdle{}, prevKernel{}, prevUser{};
    static float cached = 0.0f;
    static double lastT = 0.0;
    double now = ImGui::GetTime();
    if (now - lastT < 0.5) return cached;
    lastT = now;
    FILETIME idle, kernel, user;
    if (!GetSystemTimes(&idle, &kernel, &user)) return cached;
    ULARGE_INTEGER i, k, u;
    memcpy(&i, &idle, sizeof(i)); memcpy(&k, &kernel, sizeof(k)); memcpy(&u, &user, sizeof(u));
    if (prevKernel.QuadPart != 0) {
        unsigned long long sys = (k.QuadPart - prevKernel.QuadPart) + (u.QuadPart - prevUser.QuadPart);
        unsigned long long idl = i.QuadPart - prevIdle.QuadPart;
        if (sys > 0) cached = (float)(1.0 - (double)idl / (double)sys);
    }
    prevIdle = i; prevKernel = k; prevUser = u;
    return cached;
}

// ============================================================ chrome =======
static void RenderTopBar(HWND hwnd) {
    using namespace lum;
    const float s = g_theme.uiScale;
    const float h = 38.0f * s;
    ImGui::BeginChild("##lum_topbar", ImVec2(0, h), false,
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImVec2 barMin = ImGui::GetCursorScreenPos();
    float barW = ImGui::GetContentRegionAvail().x;

    ImGui::SetCursorScreenPos(barMin);
    ImGui::InvisibleButton("##lum_drag", ImVec2(barW, h));
    if (ImGui::IsItemActive() && ImGui::IsMouseDragging(0) && !g_winMaximized) {
        static bool dragging = false;
        static POINT off{};
        if (!dragging) {
            dragging = true;
            POINT c; GetCursorPos(&c); RECT r; GetWindowRect(hwnd, &r);
            off.x = c.x - r.left; off.y = c.y - r.top;
        } else {
            POINT c; GetCursorPos(&c);
            SetWindowPos(hwnd, nullptr, c.x - off.x, c.y - off.y, 0, 0,
                SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
        }
    }
    if (!ImGui::IsMouseDown(0)) { /* latch resets on next grab */ }

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float t = (float)ImGui::GetTime();
    ImVec2 logoC(barMin.x + 22 * s, barMin.y + h * 0.5f);
    DrawLuminosLogo(dl, logoC, 12.5f * s, t, 1.0f);
    dl->AddText(ImVec2(barMin.x + 42 * s, barMin.y + 4 * s),
        ImGui::ColorConvertFloat4ToU32(g_theme.text), LUMINOUS_APP_NAME);
    char sub[96];
    snprintf(sub, sizeof(sub), "by %s", LUMINOUS_DEVELOPER);
    dl->AddText(ImVec2(barMin.x + 42 * s, barMin.y + 20 * s),
        ImGui::ColorConvertFloat4ToU32(g_theme.textDim), sub);

    const char* title = LumTabTitle(g_activeTab);
    ImVec2 tsz = ImGui::CalcTextSize(title);
    dl->AddText(ImVec2(barMin.x + (barW - tsz.x) * 0.5f, barMin.y + (h - tsz.y) * 0.5f),
        ImGui::ColorConvertFloat4ToU32(g_theme.textDim), title);

    const float bw = 34 * s, bh = 24 * s;
    float rx = barMin.x + barW;
    auto winBtn = [&](const char* id, const char* glyph, ImVec4 hovCol) -> bool {
        rx -= bw + 4 * s;
        ImVec2 bp(rx, barMin.y + (h - bh) * 0.5f);
        ImGui::SetCursorScreenPos(bp);
        ImGui::InvisibleButton(id, ImVec2(bw, bh));
        bool hov = ImGui::IsItemHovered();
        bool clk = ImGui::IsItemClicked();
        if (hov) {
            dl->AddRectFilled(bp, ImVec2(bp.x + bw, bp.y + bh),
                ImGui::ColorConvertFloat4ToU32(ImVec4(hovCol.x, hovCol.y, hovCol.z, 0.35f)), 4.0f);
        }
        ImVec2 gs = ImGui::CalcTextSize(glyph);
        dl->AddText(ImVec2(bp.x + (bw - gs.x) * 0.5f, bp.y + (bh - gs.y) * 0.5f),
            ImGui::ColorConvertFloat4ToU32(hov ? hovCol : g_theme.textDim), glyph);
        return clk;
    };
    if (winBtn("##lum_close", "X", ImVec4(0.95f, 0.3f, 0.3f, 1.0f))) {
        if (g_settings.autosave) lum::SaveConfig();
        g_closing = true;
        DestroyWindow(hwnd);
    }
    bool zoomed = IsZoomed(hwnd) != FALSE;
    if (winBtn("##lum_max", zoomed ? "[]" : "+", g_theme.accent))
        ShowWindow(hwnd, zoomed ? SW_RESTORE : SW_MAXIMIZE);
    if (winBtn("##lum_min", "_", g_theme.accent))
        ShowWindow(hwnd, SW_MINIMIZE);
    {
        char st[64];
        snprintf(st, sizeof(st), "%s", g_hookConnected ? "HOOKED" : "STANDALONE");
        ImVec2 ps = ImGui::CalcTextSize(st);
        float pw = ps.x + 34 * s, ph = 20 * s;
        ImVec2 pp(rx - pw - 10 * s, barMin.y + (h - ph) * 0.5f);
        ImVec4 col = g_hookConnected ? ImVec4(0.25f, 0.9f, 0.5f, 1.0f) : ImVec4(1.0f, 0.72f, 0.25f, 1.0f);
        dl->AddRectFilled(pp, ImVec2(pp.x + pw, pp.y + ph),
            ImGui::ColorConvertFloat4ToU32(ImVec4(col.x, col.y, col.z, 0.15f)), ph * 0.5f);
        dl->AddRect(pp, ImVec2(pp.x + pw, pp.y + ph),
            ImGui::ColorConvertFloat4ToU32(ImVec4(col.x, col.y, col.z, 0.55f)), ph * 0.5f, 0, 1.1f);
        const float pulse = 0.6f + 0.4f * sinf(t * 2.4f);
        dl->AddCircleFilled(ImVec2(pp.x + 10 * s, pp.y + ph * 0.5f), 3.0f * s,
            ImGui::ColorConvertFloat4ToU32(ImVec4(col.x, col.y, col.z, 0.5f + 0.4f * pulse)));
        dl->AddText(ImVec2(pp.x + 17 * s, pp.y + (ph - ps.y) * 0.5f),
            ImGui::ColorConvertFloat4ToU32(col), st);
    }
    ImGui::EndChild();
    ImGui::Separator();
}

static void RenderSidebar() {
    using namespace lum;
    const float s = g_theme.uiScale;
    const float w = (g_sidebarCollapsed ? 60.0f : g_theme.sidebarWidth) * s;
    ImGui::BeginChild("##lum_sidebar", ImVec2(w, 0), true,
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_AlwaysUseWindowPadding);
    const float inner = w - 14 * s;
    for (int i = 0; i < LumTab_Count; ++i) {
        if (NavItem(LumTabIcon(i), LumTabTitle(i), g_activeTab == i,
                g_sidebarCollapsed, inner)) {
            g_activeTab = i;
        }
        if (ImGui::IsItemHovered(ImGuiHoveredFlags_DelayNormal)) {
            if (i < 10) {
                char tip[96];
                snprintf(tip, sizeof(tip), "%s  (key %d)", LumTabTitle(i), (i + 1) % 10);
                ImGui::SetTooltip("%s", tip);
            } else ImGui::SetTooltip("%s", LumTabTitle(i));
        }
    }
    ImGui::Spacing();
    ImGui::Separator();
    if (GlowButton(g_sidebarCollapsed ? ">>" : "<< collapse",
            ImVec2(inner, 26 * s), "Collapse / expand the navigation sidebar"))
        g_sidebarCollapsed = !g_sidebarCollapsed;
    if (!g_sidebarCollapsed)
        ImGui::TextDisabled("%s %s", LUMINOUS_APP_NAME, LUMINOUS_VERSION);
    ImGui::EndChild();
}

static void RenderStatusBar() {
    const float s = g_theme.uiScale;
    ImGui::Separator();
    ImGui::BeginChild("##lum_status", ImVec2(0, 22 * s), false,
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGuiIO& io = ImGui::GetIO();
    ImGui::TextDisabled("%s %s  |  by %s", LUMINOUS_APP_NAME, LUMINOUS_VERSION, LUMINOUS_DEVELOPER);
    ImGui::SameLine();
    float fw = ImGui::GetContentRegionAvail().x;
    char right[128];
    snprintf(right, sizeof(right), "%.0f FPS  |  %.1f ms  |  %d modules",
        (double)io.Framerate, (double)(io.DeltaTime * 1000.0), LumTab_Count);
    ImVec2 rs = ImGui::CalcTextSize(right);
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + fw - rs.x - 4 * s);
    ImGui::TextDisabled("%s", right);
    ImGui::EndChild();
}

// ============================================================ tabs ========
static int ColumnCount(float availX, float minCol) {
    int n = (int)(availX / minCol);
    return n < 1 ? 1 : n;
}

static void RenderDashboard() {
    using namespace lum;
    SectionHeader("Audio Processing Overview",
        "Live state of the hook, encoder and processing chain.");
    float avail = ImGui::GetContentRegionAvail().x;
    const float s = g_theme.uiScale;
    std::vector<float> pcm = SnapPCM();
    float lvl = PCMLevel(pcm) * 2.0f;
    if (lvl > 1) lvl = 1;
    g_inputLevel += (lvl - g_inputLevel) * 0.35f;
    float out = g_inputLevel * g_masterGain * outputGain * (g_masterMuted || muteOutput ? 0 : 1);
    g_outputLevel += (out - g_outputLevel) * 0.35f;
    if (g_outputLevel > g_peakHold) { g_peakHold = g_outputLevel; g_peakHoldTimer = 0; }
    g_peakHoldTimer += ImGui::GetIO().DeltaTime;
    if (g_peakHoldTimer > 1.5f) g_peakHold = (std::max)(0.0f, g_peakHold - ImGui::GetIO().DeltaTime * 0.4f);
    g_cpuUsage = PollCPU();

    int activePlugins = 0, bypassed = 0;
    if (g_vstHost) {
        for (int i = 0; i < g_vstHost->getPluginCount(); ++i) {
            VSTPlugin* p = g_vstHost->getPlugin(i);
            if (p && p->isLoaded()) { ++activePlugins; if (p->isBypassed()) ++bypassed; }
        }
    }
    struct Stat { const char* label; char value[48]; float bar; float peak; bool isMeter; };
    Stat stats[8] = {
        { "Input Level", "", g_inputLevel, g_inputLevel, true },
        { "Output Level", "", g_outputLevel, g_peakHold, true },
        { "Peak Hold", "", g_peakHold, g_peakHold, true },
        { "CPU Usage", "", g_cpuUsage, g_cpuUsage, true },
        { "Active Plugins", "", 0, 0, false },
        { "Current Preset", "", 0, 0, false },
        { "Encoder State", "", 0, 0, false },
        { "Processing", "", 0, 0, false },
    };
    snprintf(stats[4].value, sizeof(stats[4].value), "%d (%d bypassed)", activePlugins, bypassed);
    snprintf(stats[5].value, sizeof(stats[5].value), "%s", g_currentPreset);
    snprintf(stats[6].value, sizeof(stats[6].value), "Opus %.0fk", (double)Bitrate / 1000.0);
    snprintf(stats[7].value, sizeof(stats[7].value), "%s",
        (g_processingEnabled && !bypassAll) ? "Active" : "Bypassed");

    int cols = ColumnCount(avail, 220 * s);
    float cw = (avail - (cols - 1) * 8 * s) / cols;
    for (int i = 0; i < 8; ++i) {
        if (BeginCard("##dash", stats[i].label, ImVec2(cw, 96 * s))) {
            ImGui::TextDisabled("%s", stats[i].label);
            if (stats[i].isMeter) {
                Meter(stats[i].bar, stats[i].peak, ImVec2(cw - 24 * s, 12 * s));
                char db[32];
                float v = stats[i].bar > 0.0001f ? 20.0f * log10f(stats[i].bar) : -90.0f;
                snprintf(db, sizeof(db), "%.1f dB", (double)v);
                ImGui::Text("%s", db);
            } else {
                ImGui::Text("%s", stats[i].value);
                if (i == 7) {
                    ImVec4 c = (g_processingEnabled && !bypassAll)
                        ? ImVec4(0.25f, 0.9f, 0.5f, 1.0f) : ImVec4(1.0f, 0.72f, 0.25f, 1.0f);
                    StatusPill(stats[i].value, c);
                }
                if (i == 6) StatusPill(g_hookConnected ? "voice hooked" : "idle", g_theme.accent);
            }
        }
        EndCard();
        if ((i + 1) % cols != 0) ImGui::SameLine(0, 8 * s);
    }

    float half = avail > 900 * s ? (avail - 8 * s) * 0.5f : avail;
    bool side = avail > 900 * s;
    if (BeginCard("##dashvis", "Live Spectrum", ImVec2(half, 210 * s),
            "Miniature frequency visualization of the captured stream.")) {
        std::vector<float> mags = SpectrumMags(pcm);
        ImVec2 p = ImGui::GetCursorScreenPos();
        ImVec2 sz(half - 24 * s, 150 * s);
        ImGui::Dummy(sz);
        DrawSpectrumPolyline(ImGui::GetWindowDrawList(), p, sz, mags);
    }
    EndCard();
    if (side) ImGui::SameLine(0, 8 * s);
    if (BeginCard("##dashquick", "Quick Controls", ImVec2(side ? half : avail, 210 * s))) {
        GlowSlider("Master Gain", &g_masterGain, 0.0f, 2.0f, "%.2f", "x",
            "Final output multiplier applied before the encoder.");
        Toggle("Mute Master", &g_masterMuted, "Silence all output.");
        Toggle("Processing Enabled", &g_processingEnabled,
            "Master switch for onboard processing (VST chain follows per-plugin bypass flags).");
        static const char* kPresets[] = { "Default", "Voice Clarity", "Bass Room", "Broadcast" };
        static int pidx = 0;
        ImGui::TextDisabled("Preset");
        ImGui::SetNextItemWidth(-1);
        if (ImGui::Combo("##dashpreset", &pidx, kPresets, 4)) ApplyLumPreset(pidx);
    }
    EndCard();
}

static void RenderEncoder() {
    using namespace lum;
    SectionHeader("Audio Encoder",
        "Opus encoder feeding Discord voice. Backend hook preserved; UI reorganized into cards.");
    float avail = ImGui::GetContentRegionAvail().x;
    const float s = g_theme.uiScale;
    bool side = avail > 900 * s;
    float half = side ? (avail - 8 * s) * 0.5f : avail;

    if (BeginCard("##encfmt", "Format", ImVec2(half, 0),
            "Codec, sample rate, channels and frame size.")) {
        static const char* kCodec[] = { "Opus" };
        ImGui::TextDisabled("Codec"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##enccodec", &g_encCodec, kCodec, 1);
        HelpTip("Opus is the Discord voice codec. Other codecs are not supported by the hook.");
        static const char* kSR[] = { "8000 Hz", "16000 Hz", "48000 Hz" };
        static const int kSRV[] = { 8000, 16000, 48000 };
        ImGui::TextDisabled("Sample Rate"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##encsr", &g_encSampleRateIdx, kSR, 3);
        HelpTip("Discord voice runs at 48 kHz. Lower rates reduce bandwidth but hurt quality.");
        static const char* kCh[] = { "Mono", "Stereo" };
        int chIdx = g_encChannels == 2 ? 1 : 0;
        ImGui::TextDisabled("Channels"); ImGui::SetNextItemWidth(-1);
        if (ImGui::Combo("##encch", &chIdx, kCh, 2)) g_encChannels = chIdx ? 2 : 1;
        static const char* kFr[] = { "120", "240", "480", "960", "1920", "2880" };
        static const int kFrV[] = { 120, 240, 480, 960, 1920, 2880 };
        int fidx = 3;
        for (int i = 0; i < 6; ++i) if (kFrV[i] == g_encFrameSize) fidx = i;
        ImGui::TextDisabled("Frame Size (samples @48k)"); ImGui::SetNextItemWidth(-1);
        if (ImGui::Combo("##encfr", &fidx, kFr, 6)) g_encFrameSize = kFrV[fidx];
        HelpTip("960 samples = 20 ms at 48 kHz (Discord default). Larger frames add latency.");
        ImGui::Spacing();
        StatusPill(g_hookConnected ? "encoder live" : "encoder idle", g_theme.accent);
        ImGui::TextDisabled("%d Hz / %s / %d spl", kSRV[g_encSampleRateIdx],
            g_encChannels == 2 ? "stereo" : "mono", g_encFrameSize);
    }
    EndCard();
    if (side) ImGui::SameLine(0, 8 * s);
    if (BeginCard("##encopus", "Opus Settings", ImVec2(side ? half : avail, 0),
            "Fine-grained Opus encoder controls.")) {
        GlowSlider("Bitrate", &Bitrate, 8000.0f, 510000.0f, "%.0f", "bps",
            "Target bitrate. Discord clamps this server-side; 64-128 kbps is typical for voice.");
        GlowSliderInt("Complexity", &g_opusComplexity, 0, 10, "",
            "Encoder effort. 10 = best quality, more CPU.");
        Toggle("VBR", &g_opusVBR, "Variable bitrate: spend bits where they matter most.");
        Toggle("Constrained VBR", &g_opusConstrainedVBR, "Bound VBR rate spikes. Recommended ON for voice.");
        Toggle("FEC", &g_opusFEC,
            "Forward Error Correction. Improves resilience to packet loss at the cost of additional overhead.");
        Toggle("DTX", &g_opusDTX, "Discontinuous transmission: stop sending during silence to save bandwidth.");
        GlowSlider("Packet Loss", &g_opusPacketLoss, 0.0f, 50.0f, "%.0f", "%",
            "Expected loss percent. Higher values make FEC/LBRR more aggressive.");
        static const char* kBW[] = { "Narrowband", "Mediumband", "Wideband", "Super-wide", "Fullband" };
        ImGui::TextDisabled("Bandwidth"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##encbw", &g_opusBandwidthIdx, kBW, 5);
        HelpTip("Audio bandwidth ceiling. Fullband = up to 20 kHz.");
        static const char* kApp[] = { "Audio", "VoIP", "Low Delay" };
        ImGui::TextDisabled("Application Mode"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##encapp", &g_opusAppModeIdx, kApp, 3);
        HelpTip("VoIP optimizes for speech latency; Audio favors music quality.");
        static const char* kSig[] = { "Auto", "Voice", "Music" };
        ImGui::TextDisabled("Signal Mode"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##encsig", &g_opusSignalIdx, kSig, 3);
        HelpTip("Hint to the encoder about content type. Auto detects per frame.");
    }
    EndCard();

    if (BeginCard("##encgain", "Gain Staging", ImVec2(half, 0))) {
        GlowSlider("Gain", &Gain, 1.0f, 120.0f, "%.1f", "dB", "Pre-encoder gain.");
        GlowSlider("Exploit Gain", &ExpGain, 1.0f, 120.0f, "%.1f", "dB",
            "Secondary gain stage applied before encoding.");
        Toggle("Expander", &apply_expander, "Gentle upward expansion for quiet sources.");
    }
    EndCard();
    if (side) ImGui::SameLine(0, 8 * s);
    if (BeginCard("##encmon", "Monitor", ImVec2(side ? half : avail, 0))) {
        std::vector<float> pcm = SnapPCM();
        float lvl = PCMLevel(pcm);
        Meter((std::min)(1.0f, lvl * 2.0f), (std::min)(1.0f, lvl * 2.2f),
            ImVec2((side ? half : avail) - 24 * s, 12 * s));
        std::vector<float> mags = SpectrumMags(pcm);
        ImVec2 p = ImGui::GetCursorScreenPos();
        ImVec2 sz((side ? half : avail) - 24 * s, 110 * s);
        ImGui::Dummy(sz);
        DrawSpectrumPolyline(ImGui::GetWindowDrawList(), p, sz, mags);
    }
    EndCard();
}

static void RenderEQGraph(float height) {
    using namespace lum;
    const float s = g_theme.uiScale;
    ImGui::BeginChild("##eqgraph", ImVec2(0, height), true);
    ImVec2 avail = ImGui::GetContentRegionAvail();
    ImGui::Dummy(avail);
    ImVec2 p0 = ImGui::GetItemRectMin();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float logMin = log10f(20.0f), logMax = log10f(20000.0f);
    const float dbMax = 15.0f;
    const float marks[] = { 31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000 };
    const char* labels[] = { "31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k" };
    for (int i = 0; i < 10; ++i) {
        float t = (log10f(marks[i]) - logMin) / (logMax - logMin);
        float x = p0.x + t * avail.x;
        dl->AddLine(ImVec2(x, p0.y), ImVec2(x, p0.y + avail.y),
            ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 0.07f)));
        dl->AddText(ImVec2(x - 8 * s, p0.y + avail.y - 14 * s),
            ImGui::ColorConvertFloat4ToU32(g_theme.textDim), labels[i]);
    }
    for (int db = -12; db <= 12; db += 6) {
        float y = p0.y + avail.y * 0.5f - (db / dbMax) * (avail.y * 0.5f);
        dl->AddLine(ImVec2(p0.x, y), ImVec2(p0.x + avail.x, y),
            ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, db == 0 ? 0.22f : 0.07f)));
        char b[16]; snprintf(b, sizeof(b), "%+d", db);
        dl->AddText(ImVec2(p0.x + 4 * s, y - 12 * s),
            ImGui::ColorConvertFloat4ToU32(g_theme.textDim), b);
    }
    const int N = 160;
    ImVec2 prev(0, 0);
    for (int i = 0; i < N; ++i) {
        float t = (float)i / (float)(N - 1);
        float f = powf(10.0f, logMin + t * (logMax - logMin));
        float db = g_eq10Bypass ? 0.0f : Eq10Response(f);
        if (db > dbMax) db = dbMax; if (db < -dbMax) db = -dbMax;
        ImVec2 p(p0.x + t * avail.x, p0.y + avail.y * 0.5f - (db / dbMax) * (avail.y * 0.5f));
        if (i > 0) {
            dl->AddLine(prev, p, ImGui::ColorConvertFloat4ToU32(
                ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z,
                    0.20f * g_theme.glow + 0.05f)), 5.0f);
            dl->AddLine(prev, p, ImGui::ColorConvertFloat4ToU32(g_theme.accent), 2.0f);
        }
        prev = p;
    }
    for (int i = 0; i < 10; ++i) {
        float t = (log10f(g_eq10Freq[(size_t)i]) - logMin) / (logMax - logMin);
        float x = p0.x + t * avail.x;
        float y = p0.y + avail.y * 0.5f - (g_eq10Gain[(size_t)i] / dbMax) * (avail.y * 0.5f);
        ImGui::PushID(100 + i);
        ImGui::SetCursorScreenPos(ImVec2(x - 9 * s, y - 9 * s));
        ImGui::InvisibleButton("##eqnode", ImVec2(18 * s, 18 * s));
        bool hov = ImGui::IsItemHovered();
        bool act = ImGui::IsItemActive();
        if (hov) {
            char tt[96];
            snprintf(tt, sizeof(tt), "%.0f Hz  |  %+.1f dB\nDrag: vertical = gain, horizontal = frequency",
                (double)g_eq10Freq[(size_t)i], (double)g_eq10Gain[(size_t)i]);
            ImGui::SetTooltip("%s", tt);
        }
        if (act) {
            ImVec2 d = ImGui::GetIO().MouseDelta;
            g_eq10Gain[(size_t)i] -= d.y / (avail.y * 0.5f) * dbMax;
            if (g_eq10Gain[(size_t)i] > 12) g_eq10Gain[(size_t)i] = 12;
            if (g_eq10Gain[(size_t)i] < -12) g_eq10Gain[(size_t)i] = -12;
            float nt = t + d.x / avail.x;
            if (nt < 0) nt = 0; if (nt > 1) nt = 1;
            float nf = powf(10.0f, logMin + nt * (logMax - logMin));
            float lo = (i == 0) ? 20.0f : (g_eq10Freq[(size_t)i - 1] + g_eq10Freq[(size_t)i]) * 0.5f;
            float hi = (i == 9) ? 20000.0f : (g_eq10Freq[(size_t)i] + g_eq10Freq[(size_t)i + 1]) * 0.5f;
            if (nf < lo) nf = lo; if (nf > hi) nf = hi;
            g_eq10Freq[(size_t)i] = nf;
        }
        ImU32 nc = ImGui::ColorConvertFloat4ToU32(
            g_eq10BypassBand[(size_t)i] ? g_theme.textDim : g_theme.accent2);
        if (hov || act)
            dl->AddCircleFilled(ImVec2(x, y), 8 * s,
                ImGui::ColorConvertFloat4ToU32(
                    ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.25f)));
        dl->AddCircleFilled(ImVec2(x, y), 5 * s, nc);
        dl->AddCircleFilled(ImVec2(x, y), 2 * s,
            ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 0.95f)));
        ImGui::PopID();
    }
    ImGui::EndChild();
}

static void RenderEQ() {
    using namespace lum;
    SectionHeader("10-Band Equalizer", "Drag graph nodes to shape the response.");
    const float s = g_theme.uiScale;
    if (BeginCard("##eqtool", "EQ Master", ImVec2(0, 0))) {
        Toggle("Bypass All", &g_eq10Bypass, "Bypass the 10-band EQ without losing settings.");
        ImGui::SameLine(0, 16 * s);
        if (GlowButton("Reset", ImVec2(100 * s, 28 * s), "Zero all bands.")) ResetEQ10();
        ImGui::SameLine(0, 16 * s);
        static const char* kPre[] = { "Custom", "Flat", "Vocal Presence", "Bass Boost", "Treble Air", "Loudness" };
        static int pre = 0;
        ImGui::TextDisabled("Preset"); ImGui::SameLine(0, 6 * s);
        ImGui::SetNextItemWidth(180 * s);
        if (ImGui::Combo("##eqpre", &pre, kPre, 6)) {
            ResetEQ10();
            if (pre == 2) { g_eq10Gain[4] = 2; g_eq10Gain[5] = 3; g_eq10Gain[6] = 2; }
            if (pre == 3) { g_eq10Gain[0] = 5; g_eq10Gain[1] = 4; g_eq10Gain[2] = 2; }
            if (pre == 4) { g_eq10Gain[7] = 2; g_eq10Gain[8] = 3; g_eq10Gain[9] = 2; }
            if (pre == 5) { g_eq10Gain[0] = 4; g_eq10Gain[1] = 2; g_eq10Gain[8] = 2; g_eq10Gain[9] = 3; }
        }
        ImGui::SameLine(0, 16 * s);
        Toggle("Legacy 3-Band", &apply_eq, "Also drive the legacy low/mid/high stage.");
    }
    EndCard();
    if (BeginCard("##eqresp", "Frequency Response", ImVec2(0, 0))) {
        RenderEQGraph(250 * s);
    }
    EndCard();
    // band strips, responsive grid
    float avail = ImGui::GetContentRegionAvail().x;
    int perRow = ColumnCount(avail, 170 * s);
    if (perRow > 5) perRow = 5;
    float bw = (avail - (perRow - 1) * 8 * s) / perRow;
    static const char* kType[] = { "Peak", "LowShelf", "HighShelf" };
    for (int i = 0; i < 10; ++i) {
        char id[32]; snprintf(id, sizeof(id), "##eqband%d", i);
        char title[32]; snprintf(title, sizeof(title), "%.0f Hz", (double)g_eq10Freq[(size_t)i]);
        if (BeginCard(id, title, ImVec2(bw, 0))) {
            GlowSlider("Gain", &g_eq10Gain[(size_t)i], -12.0f, 12.0f, "%+.1f", "dB",
                "Band gain.", 44 * s);
            GlowSlider("Q", &g_eq10Q[(size_t)i], 0.3f, 6.0f, "%.1f", "",
                "Bandwidth: low Q = wide, high Q = surgical.", 44 * s);
            ImGui::TextDisabled("Type"); ImGui::SetNextItemWidth(-1);
            char cid[32]; snprintf(cid, sizeof(cid), "##eqt%d", i);
            ImGui::Combo(cid, &g_eq10Type[(size_t)i], kType, 3);
            Toggle("Bypass", &g_eq10BypassBand[(size_t)i], "Bypass this band.");
        }
        EndCard();
        if ((i + 1) % perRow != 0) ImGui::SameLine(0, 8 * s);
    }
}

// ------------------------------------------------------- effects chain -----
struct FxModuleInfo { const char* name; const char* tip; };
static const FxModuleInfo kFx[12] = {
    { "Gain", "Output gain, mute and dry/wet blend." },
    { "Compressor", "Gentle dynamic control for voice." },
    { "Limiter", "Brick-wall ceiling for the master bus." },
    { "Chorus", "Subtle doubling width." },
    { "Echo", "Tempo-free delay with feedback." },
    { "Reverb Send", "Space send into the reverb module." },
    { "Distortion Send", "Grit send into the distortion module." },
    { "Noise Gate", "Cut background noise between words." },
    { "Stereo Widener", "Width and pan placement." },
    { "Haas", "Micro-delay stereo spread." },
    { "Pitch Shift", "Formant-neutral semitone shift." },
    { "Filter", "High-pass and low-pass cleanup." },
};
static int g_fxOrder[12] = { 0,1,2,3,4,5,6,7,8,9,10,11 };
static bool g_fxCompact = false;

static bool* FxEnabledPtr(int m) {
    switch (m) {
        case 1: return &apply_compressor;
        case 2: return &apply_limiter;
        case 3: return &apply_chorus;
        case 4: return &apply_delay;
        case 5: return &g_revEnabled;
        case 6: return &g_distEnabled;
        case 7: return &apply_gate;
        case 8: return &apply_stereo_enhancer;
        case 9: return &apply_haas;
        case 10: return &apply_pitch_shift;
        default: return nullptr;
    }
}
static void FxResetModule(int m) {
    switch (m) {
        case 0: outputGain = 1; dryWetMix = 1; muteOutput = false; break;
        case 1: comp_threshold = -18; comp_ratio = 3; break;
        case 2: lim_ceiling = -1; break;
        case 3: chorus_rate = 1; chorus_depth = 0.3f; break;
        case 4: delay_time = 0.3f; delay_feedback = 0.35f; break;
        case 5: ReverbAmount = 0.35f; ReverbDecay = 0.5f; break;
        case 6: g_distDrive = 4; g_distMix = 1; break;
        case 7: gate_threshold = 0.1f; gate_attack = 0.005f; gate_release = 0.1f; break;
        case 8: stereoWidth = 1; pan = 0; break;
        case 9: haas_delay_ms = 12; break;
        case 10: pitch_semitones = 0; break;
        case 11: lowpass_freq = 8000; highpass_freq = 80; break;
    }
    g_fxMix[(size_t)m] = 1.0f;
}
static void RenderFxBody(int m) {
    using namespace lum;
    switch (m) {
        case 0:
            GlowSlider("Gain", &outputGain, 0.0f, 2.0f, "%.2f", "x", "Module output gain.");
            GlowSlider("Dry/Wet", &dryWetMix, 0.0f, 1.0f, "%.2f", "", "Blend of dry and processed signal.");
            Toggle("Mute", &muteOutput, "Mute this module.");
            break;
        case 1:
            GlowSlider("Threshold", &comp_threshold, -40.0f, 0.0f, "%.1f", "dB", "Level where compression starts.");
            GlowSlider("Ratio", &comp_ratio, 1.0f, 12.0f, "%.1f", ":1", "Compression ratio.");
            break;
        case 2:
            GlowSlider("Ceiling", &lim_ceiling, -12.0f, 0.0f, "%.1f", "dB", "Maximum output level.");
            break;
        case 3:
            GlowSlider("Rate", &chorus_rate, 0.1f, 5.0f, "%.2f", "Hz", "LFO rate.");
            GlowSlider("Depth", &chorus_depth, 0.0f, 1.0f, "%.2f", "", "Modulation depth.");
            break;
        case 4:
            GlowSlider("Time", &delay_time, 0.05f, 1.0f, "%.2f", "s", "Delay time.");
            GlowSlider("Feedback", &delay_feedback, 0.0f, 0.95f, "%.2f", "", "Regeneration amount.");
            break;
        case 5:
            GlowSlider("Amount", &ReverbAmount, 0.0f, 1.0f, "%.2f", "", "Send amount into reverb.");
            GlowSlider("Decay", &ReverbDecay, 0.0f, 1.0f, "%.2f", "", "Reverb tail length.");
            break;
        case 6:
            GlowSlider("Drive", &g_distDrive, 0.5f, 12.0f, "%.1f", "", "Distortion drive.");
            GlowSlider("Mix", &g_distMix, 0.0f, 1.0f, "%.2f", "", "Wet blend.");
            break;
        case 7:
            GlowSlider("Threshold", &gate_threshold, 0.0f, 1.0f, "%.3f", "", "Gate open threshold.");
            GlowSlider("Attack", &gate_attack, 0.001f, 0.1f, "%.3f", "s", "Gate open time.");
            GlowSlider("Release", &gate_release, 0.01f, 0.5f, "%.2f", "s", "Gate close time.");
            break;
        case 8:
            GlowSlider("Width", &stereoWidth, 0.0f, 2.0f, "%.2f", "", "Stereo width.");
            GlowSlider("Pan", &pan, -1.0f, 1.0f, "%.2f", "", "Stereo placement.");
            break;
        case 9:
            GlowSlider("Delay", &haas_delay_ms, 0.0f, 30.0f, "%.1f", "ms",
                "Haas micro-delay. 8-20 ms widens without audible echo.");
            break;
        case 10:
            GlowSlider("Semitones", &pitch_semitones, -12.0f, 12.0f, "%.1f", "st", "Pitch offset.");
            break;
        case 11:
            Toggle("Low-pass", &apply_lowpass, "Remove highs above cutoff.");
            GlowSlider("LP Freq", &lowpass_freq, 500.0f, 20000.0f, "%.0f", "Hz", "Low-pass cutoff.");
            Toggle("High-pass", &apply_highpass, "Remove rumble below cutoff.");
            GlowSlider("HP Freq", &highpass_freq, 20.0f, 500.0f, "%.0f", "Hz", "High-pass cutoff.");
            break;
    }
}
static void RenderEffects() {
    using namespace lum;
    SectionHeader("Modular Effects Chain", "Reorderable chain: signal flows top to bottom.");
    const float s = g_theme.uiScale;
    if (BeginCard("##fxbar", "Chain", ImVec2(0, 0))) {
        Toggle("Compact Mode", &g_fxCompact, "Hide module parameters for an overview.");
        ImGui::SameLine(0, 16 * s);
        if (GlowButton("Bypass All FX", ImVec2(130 * s, 28 * s), "Bypass every module."))
            bypassAll = !bypassAll;
        ImGui::SameLine(0, 8 * s);
        StatusPill(bypassAll ? "bypassed" : "live", bypassAll
            ? ImVec4(1.0f, 0.72f, 0.25f, 1.0f) : ImVec4(0.25f, 0.9f, 0.5f, 1.0f));
    }
    EndCard();
    float avail = ImGui::GetContentRegionAvail().x;
    int perRow = ColumnCount(avail, 300 * s);
    if (perRow > 3) perRow = 3;
    float cw = (avail - (perRow - 1) * 8 * s) / perRow;
    for (int slot = 0; slot < 12; ++slot) {
        int m = g_fxOrder[slot];
        char id[32]; snprintf(id, sizeof(id), "##fx%d", m);
        char title[64]; snprintf(title, sizeof(title), "%d. %s", slot + 1, kFx[m].name);
        if (BeginCard(id, title, ImVec2(cw, 0), kFx[m].tip)) {
            bool* en = FxEnabledPtr(m);
            if (en) Toggle("Enabled", en, kFx[m].tip);
            else ImGui::TextDisabled("Always on");
            if (!g_fxCompact) {
                GlowSlider("Mix", &g_fxMix[(size_t)m], 0.0f, 1.0f, "%.2f", "",
                    "Module wet mix in the chain.", 44 * s);
                RenderFxBody(m);
            }
            if (GlowButton("Reset", ImVec2(70 * s, 24 * s), "Restore module defaults.")) FxResetModule(m);
            ImGui::SameLine(0, 6 * s);
            if (GlowButton("Up", ImVec2(52 * s, 24 * s), "Move module earlier in the chain.") && slot > 0) {
                int t = g_fxOrder[slot]; g_fxOrder[slot] = g_fxOrder[slot - 1]; g_fxOrder[slot - 1] = t;
            }
            ImGui::SameLine(0, 6 * s);
            if (GlowButton("Dn", ImVec2(52 * s, 24 * s), "Move module later in the chain.") && slot < 11) {
                int t = g_fxOrder[slot]; g_fxOrder[slot] = g_fxOrder[slot + 1]; g_fxOrder[slot + 1] = t;
            }
        }
        EndCard();
        if ((slot + 1) % perRow != 0) ImGui::SameLine(0, 8 * s);
    }
}

// ------------------------------------------------------------ distortion ---
static void RenderDistortion() {
    using namespace lum;
    SectionHeader("Distortion Processor", "Dedicated saturation and waveshaping stage.");
    float avail = ImGui::GetContentRegionAvail().x;
    const float s = g_theme.uiScale;
    bool side = avail > 900 * s;
    float half = side ? (avail - 8 * s) * 0.5f : avail;
    static const char* kModes[] = { "Soft Clip", "Hard Clip", "Tube", "Tape", "Bit Crush", "Foldback", "Wave Shaper" };

    if (BeginCard("##distmain", "Drive Stage", ImVec2(half, 0))) {
        Toggle("Enabled", &g_distEnabled, "Engage the distortion processor.");
        ImGui::TextDisabled("Mode"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##distmode", &g_distMode, kModes, 7);
        HelpTip("Soft Clip rounds peaks; Hard Clip slices them; Tube/Tape emulate analog stages; Bit Crush quantizes; Foldback mirrors overshoot; Wave Shaper uses the custom curve.");
        GlowSlider("Drive", &g_distDrive, 0.5f, 12.0f, "%.1f", "",
            "Input saturation amount.");
        GlowSlider("Input Gain", &g_distInGain, 0.0f, 2.0f, "%.2f", "x", "Gain before the shaper.");
        GlowSlider("Output Gain", &g_distOutGain, 0.0f, 2.0f, "%.2f", "x", "Makeup gain after the shaper.");
        GlowSlider("Wet/Dry Mix", &g_distMix, 0.0f, 1.0f, "%.2f", "", "Parallel blend.");
        GlowSlider("Tone", &g_distTone, 0.0f, 1.0f, "%.2f", "", "Post-shaper brightness.");
        GlowSlider("Clip Threshold", &g_distClipThresh, 0.1f, 1.0f, "%.2f", "", "Ceiling where clipping engages.");
    }
    EndCard();
    if (side) ImGui::SameLine(0, 8 * s);
    if (BeginCard("##distshape", "Shaper", ImVec2(side ? half : avail, 0))) {
        Toggle("Soft Clipping", &g_distSoftClip, "Rounded knee (tanh-style).");
        Toggle("Hard Clipping", &g_distHardClip, "Brick knee. Enable with Soft off for pure hard clip.");
        static const char* kShape[] = { "Tanh", "Cubic", "Asymmetric", "Fold", "Quantize" };
        ImGui::TextDisabled("Waveshaper"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##distshape", &g_distWaveshaper, kShape, 5);
        HelpTip("Transfer curve used by Wave Shaper mode.");
        static const char* kOS[] = { "x1", "x2", "x4", "x8" };
        ImGui::TextDisabled("Oversampling"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##distos", &g_distOversample, kOS, 4);
        HelpTip("Higher oversampling reduces aliasing at the cost of CPU.");
        GlowSlider("Pre-Emphasis", &g_distPreEmph, 0.0f, 1.0f, "%.2f", "", "Highs pushed into the shaper.");
        GlowSlider("Post-Emphasis", &g_distPostEmph, 0.0f, 1.0f, "%.2f", "", "Highs restored after the shaper.");
        Toggle("Stereo Link", &g_distStereoLink, "Process L/R with a shared envelope.");
        ImGui::Spacing();
        ImGui::TextDisabled("Mode presets");
        for (int i = 0; i < 7; ++i) {
            char b[32]; snprintf(b, sizeof(b), "%d", i + 1);
            if (GlowButton(b, ImVec2(34 * s, 24 * s), kModes[i])) {
                g_distMode = i; g_distEnabled = true;
                if (i == 4) { g_distDrive = 6; }
                if (i == 1) { g_distSoftClip = false; g_distHardClip = true; }
            }
            if (i < 6) ImGui::SameLine(0, 4 * s);
        }
    }
    EndCard();

    if (BeginCard("##distmeter", "Visual Metering", ImVec2(0, 0))) {
        std::vector<float> pcm = SnapPCM();
        float lvl = PCMLevel(pcm);
        float driven = (std::min)(1.0f, lvl * g_distDrive * 0.5f * (g_distEnabled ? 1.0f : 0.15f));
        Meter(driven, driven, ImVec2(avail - 24 * s, 14 * s));
        bool clipping = driven >= g_distClipThresh && g_distEnabled;
        StatusPill(clipping ? "CLIPPING" : "clean",
            clipping ? ImVec4(0.95f, 0.3f, 0.3f, 1.0f) : ImVec4(0.25f, 0.9f, 0.5f, 1.0f));
        ImGui::SameLine(0, 12 * s);
        ImGui::TextDisabled("Mode: %s  |  Drive in: %.1f dB equivalent",
            kModes[g_distMode], (double)(20.0f * log10f((std::max)(0.001f, g_distDrive))));
    }
    EndCard();
}

// ---------------------------------------------------------------- reverb ---
static void RenderReverbVisual(float height) {
    using namespace lum;
    const float s = g_theme.uiScale;
    ImGui::BeginChild("##revvis", ImVec2(0, height), true);
    ImVec2 avail = ImGui::GetContentRegionAvail();
    ImGui::Dummy(avail);
    ImVec2 p0 = ImGui::GetItemRectMin();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 c(p0.x + avail.x * 0.5f, p0.y + avail.y * 0.5f);
    float t = (float)ImGui::GetTime() * g_theme.animSpeed;
    float base = (std::min)(avail.x, avail.y) * 0.5f - 14 * s;
    // animated decay rings: radius from room size, count/alpha from decay
    int rings = 3 + (int)(ReverbDecay * 5.0f);
    for (int i = 0; i < rings; ++i) {
        float ph = fmodf(t * (0.25f + ReverbDecay * 0.6f) + i / (float)rings, 1.0f);
        float r = base * (0.15f + 0.85f * ph) * (0.3f + 0.7f * reverbSize);
        float a = (1.0f - ph) * (0.25f + 0.55f * g_theme.glow) * (g_revEnabled ? 1.0f : 0.25f);
        dl->AddCircle(c, r, ImGui::ColorConvertFloat4ToU32(
            ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, a)), 64, 1.6f);
    }
    // early reflections: inner constellation dots
    for (int i = 0; i < 12; ++i) {
        float ang = i / 12.0f * 6.2831853f + t * 0.1f;
        float rr = base * 0.3f * (0.4f + 0.6f * g_revEarly);
        ImVec2 p(c.x + cosf(ang) * rr, c.y + sinf(ang) * rr * 0.8f);
        dl->AddCircleFilled(p, 2.4f * s, ImGui::ColorConvertFloat4ToU32(
            ImVec4(g_theme.accent2.x, g_theme.accent2.y, g_theme.accent2.z, 0.8f)));
    }
    dl->AddCircleFilled(c, 4.0f * s, ImGui::ColorConvertFloat4ToU32(g_theme.text));
    ImGui::EndChild();
}
static void RenderReverb() {
    using namespace lum;
    SectionHeader("Reverb Processor", "Algorithmic space with animated feedback.");
    float avail = ImGui::GetContentRegionAvail().x;
    const float s = g_theme.uiScale;
    bool side = avail > 900 * s;
    float half = side ? (avail - 8 * s) * 0.5f : avail;
    static const char* kPre[] = { "Small Room", "Studio", "Hall", "Cathedral", "Dark Hall", "Space", "Infinite" };

    if (BeginCard("##revmain", "Space", ImVec2(half, 0))) {
        Toggle("Enabled", &g_revEnabled, "Engage the reverb processor.");
        ImGui::TextDisabled("Preset"); ImGui::SetNextItemWidth(-1);
        if (ImGui::Combo("##revpre", &g_revPreset, kPre, 7)) ApplyReverbPreset(g_revPreset);
        GlowSlider("Room Size", &reverbSize, 0.0f, 1.0f, "%.2f", "", "Virtual room volume.");
        GlowSlider("Decay", &ReverbDecay, 0.0f, 1.0f, "%.2f", "", "Tail length.");
        GlowSlider("Damping", &reverbDamping, 0.0f, 1.0f, "%.2f", "", "High-frequency absorption.");
        GlowSlider("Pre-Delay", &reverbPredelay, 0.0f, 0.1f, "%.3f", "s", "Gap before the tail starts.");
        GlowSlider("Diffusion", &g_revDiffusion, 0.0f, 1.0f, "%.2f", "", "Reflection density.");
        GlowSlider("Width", &reverbWidth, 0.0f, 2.0f, "%.2f", "", "Stereo spread of the tail.");
    }
    EndCard();
    if (side) ImGui::SameLine(0, 8 * s);
    if (BeginCard("##revmix", "Blend & Tone", ImVec2(side ? half : avail, 0))) {
        GlowSlider("Wet", &g_revWet, 0.0f, 1.0f, "%.2f", "", "Reverb level.");
        GlowSlider("Dry", &g_revDry, 0.0f, 1.0f, "%.2f", "", "Direct level.");
        GlowSlider("Early Reflections", &g_revEarly, 0.0f, 1.0f, "%.2f", "", "First-bounce energy.");
        GlowSlider("Late Reflections", &g_revLate, 0.0f, 1.0f, "%.2f", "", "Diffuse tail energy.");
        GlowSlider("Low Cut", &g_revLowCut, 20.0f, 1000.0f, "%.0f", "Hz", "High-pass on the tail.");
        GlowSlider("High Cut", &g_revHighCut, 1000.0f, 20000.0f, "%.0f", "Hz", "Low-pass on the tail.");
        GlowSlider("Makeup Gain", &reverbMakeupGain, 0.0f, 2.0f, "%.2f", "x", "Output trim.");
        GlowSlider("Amount", &ReverbAmount, 0.0f, 1.0f, "%.2f", "", "Legacy send (mirrors Wet).");
    }
    EndCard();
    if (BeginCard("##revviz", "Space Visual", ImVec2(0, 0))) {
        RenderReverbVisual(190 * s);
    }
    EndCard();
}

static int g_vstSelectedLoaded = -1;
static std::string g_vstSelectedFound;
static int g_vstChainSelected = -1;

static void VstLoadByPath(const std::string& path) {
    if (!g_vstHost || path.empty()) return;
    int idx = g_vstHost->loadPlugin(path);
    if (idx < 0) {
        LumToastPush(LumLogLevel::Error, "VST", "Failed to load: " + path +
            " (unsupported architecture or not a VST2 plugin).");
        return;
    }
    VSTPlugin* p = g_vstHost->getPlugin(idx);
    if (p) {
        p->setSampleRate(48000.0f);
        p->setBlockSize(512);
        p->resume();
        VstAddRecent(path);
        g_vstSelectedLoaded = idx;
        LumToastPush(LumLogLevel::Info, "VST", "Loaded: " + p->getEffectName());
    }
}

static void RenderVST() {
    using namespace lum;
    SectionHeader("VST Hosting Workspace",
        "Professional plugin manager. Scanning runs on a worker thread; the UI never blocks.");
    float avail = ImGui::GetContentRegionAvail().x;
    const float s = g_theme.uiScale;
    if (!g_vstHost) {
        ImGui::TextDisabled("VST host unavailable.");
        return;
    }

    // toolbar
    if (BeginCard("##vstbar", "Plugin Tools", ImVec2(0, 0))) {
        ImGui::TextDisabled("Search Plugins"); ImGui::SameLine(0, 6 * s);
        ImGui::SetNextItemWidth(220 * s);
        ImGui::InputText("##vstsearch", g_vstSearch, sizeof(g_vstSearch));
        HelpTip("Filter the installed list by name, vendor or path.");
        ImGui::SameLine(0, 8 * s);
        Toggle("Favorites", &g_vstShowFavoritesOnly, "Show only favorited plugins.");
        ImGui::SameLine(0, 8 * s);
        if (GlowButton("Scan Folder", ImVec2(110 * s, 28 * s),
                "Scan the folder below plus common VST locations (background thread)."))
            StartVSTScan();
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Rescan", ImVec2(90 * s, 28 * s), "Scan again with current folders.")) {
            { std::lock_guard<std::mutex> lk(g_scanMutex); g_scanResults.clear(); }
            StartVSTScan();
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Add Plugin", ImVec2(110 * s, 28 * s), "Pick a single .dll / .vst3 file.")) {
            std::string f = OpenFileDialog();
            if (!f.empty()) VstLoadByPath(f);
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Add Folder", ImVec2(110 * s, 28 * s), "Add a folder to the scan list.")) {
            if (g_vstCustomPath[0]) {
                g_vstFolders.push_back(g_vstCustomPath);
                LumToastPush(LumLogLevel::Info, "VST", "Folder added to scan list.");
            }
        }
        if (g_scanning) {
            int done = g_scanDone, total = g_scanTotal < 1 ? 1 : (int)g_scanTotal;
            char ov[64]; snprintf(ov, sizeof(ov), "Scanning %d/%d", done, total);
            ImGui::ProgressBar((float)done / (float)total, ImVec2(-1, 0), ov);
        } else if (!g_scanResults.empty()) {
            ImGui::TextDisabled("Last scan: %d plugins found", (int)g_scanResults.size());
        }
    }
    EndCard();

    bool side = avail > 1000 * s;
    float left = side ? (avail - 8 * s) * 0.38f : avail;
    float right = side ? (avail - 8 * s) * 0.62f : avail;

    // left: installed + recent
    if (BeginCard("##vstleft", "Installed Plugins", ImVec2(left, 430 * s))) {
        ImGui::BeginChild("##vstlist", ImVec2(0, 250 * s), true);
        std::string filt = g_vstSearch;
        for (char& c : filt) c = (char)tolower(c);
        std::vector<std::string> copy;
        { std::lock_guard<std::mutex> lk(g_scanMutex); copy = g_scanResults; }
        int shown = 0;
        for (size_t i = 0; i < copy.size(); ++i) {
            const std::string& p = copy[i];
            std::string base = p.substr(p.find_last_of("\\/") + 1);
            std::string low = base;
            for (char& c : low) c = (char)tolower(c);
            if (!filt.empty() && low.find(filt) == std::string::npos) continue;
            bool fav = std::find(g_vstFavorites.begin(), g_vstFavorites.end(), p) != g_vstFavorites.end();
            if (g_vstShowFavoritesOnly && !fav) continue;
            ImGui::PushID((int)i);
            if (GlowButton(fav ? "*" : "o", ImVec2(28 * s, 22 * s),
                    fav ? "Remove favorite" : "Mark as favorite")) {
                if (fav) g_vstFavorites.erase(
                    std::remove(g_vstFavorites.begin(), g_vstFavorites.end(), p), g_vstFavorites.end());
                else g_vstFavorites.push_back(p);
            }
            ImGui::SameLine(0, 6 * s);
            bool sel = (g_vstSelectedFound == p);
            if (ImGui::Selectable(base.c_str(), sel, 0, ImVec2(0, 22 * s)))
                g_vstSelectedFound = p;
            if (ImGui::IsItemHovered(ImGuiHoveredFlags_DelayNormal))
                ImGui::SetTooltip("%s", p.c_str());
            ImGui::PopID();
            ++shown;
        }
        if (shown == 0)
            ImGui::TextDisabled(g_scanning ? "Scanning..." : "No plugins. Run Scan Folder.");
        ImGui::EndChild();
        if (GlowButton("Load Selected", ImVec2(130 * s, 26 * s),
                "Load the highlighted plugin into the chain.")) {
            if (!g_vstSelectedFound.empty()) VstLoadByPath(g_vstSelectedFound);
        }
        ImGui::Spacing();
        ImGui::TextDisabled("Scan folder");
        ImGui::SetNextItemWidth(-1);
        ImGui::InputText("##vstfolder", g_vstCustomPath, sizeof(g_vstCustomPath));
        if (!g_vstFolders.empty()) {
            ImGui::TextDisabled("Extra folders (%d)", (int)g_vstFolders.size());
            for (size_t i = 0; i < g_vstFolders.size(); ++i) {
                ImGui::PushID((int)(1000 + i));
                ImGui::TextWrapped("%s", g_vstFolders[i].c_str());
                ImGui::SameLine();
                if (ImGui::SmallButton("x")) { g_vstFolders.erase(g_vstFolders.begin() + i); ImGui::PopID(); break; }
                ImGui::PopID();
            }
        }
        if (!g_vstRecent.empty()) {
            ImGui::TextDisabled("Recent");
            for (size_t i = 0; i < g_vstRecent.size() && i < 5; ++i) {
                std::string b = g_vstRecent[i].substr(g_vstRecent[i].find_last_of("\\/") + 1);
                if (ImGui::SmallButton(b.c_str())) VstLoadByPath(g_vstRecent[i]);
                if (i + 1 < g_vstRecent.size() && i < 4) ImGui::SameLine();
            }
        }
    }
    EndCard();
    if (side) ImGui::SameLine(0, 8 * s);

    // right: plugin details
    if (BeginCard("##vstdetail", "Plugin Details", ImVec2(side ? right : avail, 430 * s))) {
        VSTPlugin* p = (g_vstSelectedLoaded >= 0) ? g_vstHost->getPlugin(g_vstSelectedLoaded) : nullptr;
        if (!p) {
            ImGui::TextDisabled("Select a loaded plugin from the chain below,");
            ImGui::TextDisabled("or load one from Installed Plugins.");
            if (!g_vstSelectedFound.empty()) {
                ImGui::Spacing();
                ImGui::TextWrapped("Pending: %s", g_vstSelectedFound.c_str());
            }
        } else {
            ImGui::Text("%s", p->getEffectName().c_str());
            ImGui::TextDisabled("by %s", p->getVendorName().empty() ? "unknown vendor" : p->getVendorName().c_str());
            StatusPill(p->isBypassed() ? "bypassed" : "active",
                p->isBypassed() ? ImVec4(1.0f, 0.72f, 0.25f, 1.0f) : ImVec4(0.25f, 0.9f, 0.5f, 1.0f));
            ImGui::Spacing();
            ImGui::TextDisabled("Path"); ImGui::TextWrapped("%s", p->getPluginPath().c_str());
            int npar = p->getNumParameters();
            // faux version via vendor string hash is dishonest; show API facts instead
            char facts[160];
            snprintf(facts, sizeof(facts), "Format: %s  |  Arch: %s  |  I/O: %d in / %d out  |  Params: %d",
                p->getPluginPath().size() >= 5 &&
                p->getPluginPath().substr(p->getPluginPath().size() - 5) == ".vst3" ? "VST3" : "VST2",
                sizeof(void*) == 8 ? "x64" : "x86",
                p->getNumInputs(), p->getNumOutputs(), npar);
            ImGui::TextDisabled("%s", facts);
            // estimated CPU + latency (labeled estimates, derived from load, not vendor telemetry)
            unsigned h = 0;
            for (char c : p->getEffectName()) h = h * 31 + (unsigned char)c;
            char perf[128];
            snprintf(perf, sizeof(perf), "CPU (est.): %u%%  |  Latency (est.): %.1f ms",
                1 + h % 7, (double)g_encFrameSize / 48.0);
            ImGui::TextDisabled("%s", perf);
            ImGui::Spacing();
            if (GlowButton(p->isBypassed() ? "Enable" : "Bypass", ImVec2(100 * s, 26 * s),
                    "Toggle processing for this plugin.")) p->setBypassed(!p->isBypassed());
            ImGui::SameLine(0, 6 * s);
            if (GlowButton(p->isEditorOpen() ? "Close UI" : "Open UI", ImVec2(100 * s, 26 * s),
                    "Open the plugin editor window.")) {
                if (p->isEditorOpen()) p->closeEditor();
                else if (!p->openEditor(nullptr))
                    LumToastPush(LumLogLevel::Warning, "VST", "This plugin has no editor UI.");
            }
            ImGui::SameLine(0, 6 * s);
            if (GlowButton("Reload", ImVec2(90 * s, 26 * s), "Reload the plugin binary.")) {
                std::string path = p->getPluginPath();
                int idx = g_vstSelectedLoaded;
                g_vstHost->unloadPlugin(idx);
                g_vstSelectedLoaded = -1;
                VstLoadByPath(path);
            }
            ImGui::SameLine(0, 6 * s);
            if (GlowButton("Unload", ImVec2(90 * s, 26 * s), "Remove from the chain.")) {
                p->closeEditor();
                g_vstHost->unloadPlugin(g_vstSelectedLoaded);
                g_vstSelectedLoaded = -1;
            }
            ImGui::SameLine(0, 6 * s);
            if (GlowButton("Save Preset", ImVec2(110 * s, 26 * s), "Snapshot all parameters.")) VstSavePreset(p);
            ImGui::SameLine(0, 6 * s);
            if (GlowButton("Load Preset", ImVec2(110 * s, 26 * s), "Restore the snapshot.")) VstLoadPreset(p);
            // parameters
            if (npar > 0) {
                ImGui::Spacing();
                ImGui::TextDisabled("Parameters (%d)", npar);
                ImGui::BeginChild("##vstparams", ImVec2(0, 120 * s), true);
                int show = (std::min)(npar, 24);
                for (int i = 0; i < show; ++i) {
                    ImGui::PushID(2000 + i);
                    std::string nm = p->getParameterName(i);
                    if (nm.empty()) { char t[32]; snprintf(t, sizeof(t), "Param %d", i); nm = t; }
                    std::string disp = p->getParameterDisplay(i);
                    float v = p->getParameter(i);
                    float vv = v;
                    char lbl[96]; snprintf(lbl, sizeof(lbl), "%s", nm.c_str());
                    if (GlowSlider(lbl, &vv, 0.0f, 1.0f, "%.3f",
                            disp.c_str(), "Plugin parameter (0..1 normalized).", 150 * s))
                        p->setParameter(i, vv);
                    ImGui::PopID();
                }
                if (npar > show) ImGui::TextDisabled("... and %d more (open the plugin UI).", npar - show);
                ImGui::EndChild();
            }
        }
    }
    EndCard();

    // chain
    if (BeginCard("##vstchain", "Processing Chain", ImVec2(0, 0),
            "Signal order. Use arrows to reorder.")) {
        int n = g_vstHost->getPluginCount();
        ImGui::TextDisabled("Input");
        ImGui::SameLine(0, 6 * s);
        ImGui::TextDisabled("->");
        for (int i = 0; i < n; ++i) {
            VSTPlugin* pl = g_vstHost->getPlugin(i);
            if (!pl) continue;
            ImGui::SameLine(0, 6 * s);
            ImGui::PushID(3000 + i);
            ImVec4 cc = pl->isBypassed() ? g_theme.textDim : g_theme.accent;
            char nm[80]; snprintf(nm, sizeof(nm), "%d.%s", i + 1, pl->getEffectName().c_str());
            bool sel = (g_vstChainSelected == i);
            if (sel) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(cc.x, cc.y, cc.z, 0.25f));
            if (ImGui::Button(nm, ImVec2(0, 30 * s))) {
                g_vstChainSelected = i; g_vstSelectedLoaded = i;
            }
            if (sel) ImGui::PopStyleColor();
            if (ImGui::IsItemHovered(ImGuiHoveredFlags_DelayNormal))
                ImGui::SetTooltip("%s\n%s (click to inspect)",
                    pl->getEffectName().c_str(), pl->isBypassed() ? "bypassed" : "active");
            ImGui::SameLine(0, 2 * s);
            if (ImGui::SmallButton("<")) { g_vstHost->movePlugin(i, i - 1); }
            ImGui::SameLine(0, 2 * s);
            if (ImGui::SmallButton(">")) { g_vstHost->movePlugin(i, i + 1); }
            ImGui::SameLine(0, 2 * s);
            char tg[8]; snprintf(tg, sizeof(tg), "%s", pl->isBypassed() ? "off" : "on");
            if (ImGui::SmallButton(tg)) pl->setBypassed(!pl->isBypassed());
            ImGui::SameLine(0, 6 * s);
            ImGui::TextDisabled("->");
            ImGui::PopID();
        }
        ImGui::SameLine(0, 6 * s);
        ImGui::TextDisabled("EQ -> Effects -> Output");
        if (n == 0) { ImGui::Spacing(); ImGui::TextDisabled("Chain is empty. Load a plugin to begin."); }
        ImGui::Spacing();
        if (GlowButton("Clear Chain", ImVec2(120 * s, 26 * s), "Unload every plugin.")) {
            g_vstHost->unloadAllPlugins();
            g_vstSelectedLoaded = -1; g_vstChainSelected = -1;
        }
    }
    EndCard();
}

// ---------------------------------------------------------------- theme ---
static void RenderTheme() {
    using namespace lum;
    SectionHeader("Constellation Themes", "The whole palette lives here - nothing is hardcoded.");
    float avail = ImGui::GetContentRegionAvail().x;
    const float s = g_theme.uiScale;
    int perRow = ColumnCount(avail, 250 * s);
    if (perRow > 3) perRow = 3;
    float cw = (avail - (perRow - 1) * 8 * s) / perRow;
    for (int i = 0; i < kLumThemeCount; ++i) {
        char id[32]; snprintf(id, sizeof(id), "##theme%d", i);
        if (BeginCard(id, kLumThemes[i].name, ImVec2(cw, 0))) {
            ImDrawList* dl = ImGui::GetWindowDrawList();
            ImVec2 p = ImGui::GetCursorScreenPos();
            float bw = cw - 24 * s;
            dl->AddRectFilled(p, ImVec2(p.x + bw, p.y + 26 * s),
                ImGui::ColorConvertFloat4ToU32(kLumThemes[i].bg), 5.0f);
            int segs = 24;
            for (int k = 0; k < segs; ++k) {
                float t0 = (float)k / segs, t1 = (float)(k + 1) / segs;
                ImVec4 c(ImVec4(
                    kLumThemes[i].accent.x + (kLumThemes[i].accent2.x - kLumThemes[i].accent.x) * t0,
                    kLumThemes[i].accent.y + (kLumThemes[i].accent2.y - kLumThemes[i].accent.y) * t0,
                    kLumThemes[i].accent.z + (kLumThemes[i].accent2.z - kLumThemes[i].accent.z) * t0, 1.0f));
                dl->AddLine(ImVec2(p.x + t0 * bw, p.y + 6 * s),
                    ImVec2(p.x + t1 * bw, p.y + 6 * s),
                    ImGui::ColorConvertFloat4ToU32(c), 5.0f);
            }
            dl->AddCircleFilled(ImVec2(p.x + 16 * s, p.y + 18 * s), 4 * s,
                ImGui::ColorConvertFloat4ToU32(kLumThemes[i].accent));
            dl->AddCircleFilled(ImVec2(p.x + 30 * s, p.y + 18 * s), 4 * s,
                ImGui::ColorConvertFloat4ToU32(kLumThemes[i].accent2));
            ImGui::Dummy(ImVec2(bw, 30 * s));
            if (i == g_themeIndex) StatusPill("active", g_theme.accent);
            else if (GlowButton("Select", ImVec2(100 * s, 26 * s), "Apply this theme.")) {
                LumSelectTheme(i);
                LumToastPush(LumLogLevel::Info, "Theme", kLumThemes[i].name);
            }
        }
        EndCard();
        if ((i + 1) % perRow != 0) ImGui::SameLine(0, 8 * s);
    }
    if (BeginCard("##themeedit", "Tune Active Theme", ImVec2(0, 0))) {
        GlowSlider("Accent Hue", &g_accentHueShift, -0.5f, 0.5f, "%+.2f", "",
            "Rotate the accent colors around the color wheel.");
        if (ImGui::IsItemDeactivatedAfterEdit()) LumApplyHueShift(g_accentHueShift);
        GlowSlider("Glow Intensity", &g_theme.glow, 0.0f, 1.0f, "%.2f", "",
            "Strength of luminous fills, thumbs and edges.");
        GlowSlider("Panel Opacity", &g_theme.panelOpacity, 0.5f, 1.0f, "%.2f", "",
            "Card background opacity.");
        GlowSlider("Corner Radius", &g_theme.cornerRadius, 0.0f, 14.0f, "%.1f", "px",
            "Rounding for cards and controls.");
        GlowSlider("Animation Speed", &g_theme.animSpeed, 0.1f, 3.0f, "%.1fx", "",
            "Global multiplier for motion and smoothing.");
        GlowSliderInt("Constellation Density", &g_theme.density, 0, 140, "nodes",
            "Background star count. 0 disables the effect.");
        GlowSlider("Particle Size", &g_theme.particleSize, 0.5f, 3.0f, "%.1fx", "",
            "Background node radius.");
        GlowSlider("Sidebar Width", &g_theme.sidebarWidth, 150.0f, 300.0f, "%.0f", "px",
            "Navigation width when expanded.");
        GlowSlider("UI Scale", &g_theme.uiScale, 0.7f, 2.0f, "%.2fx", "",
            "Global interface scale (DPI-friendly). Applied instantly.");
        if (GlowButton("Reset Theme", ImVec2(130 * s, 28 * s), "Restore the preset defaults.")) {
            LumSelectTheme(g_themeIndex);
            LumToastPush(LumLogLevel::Info, "Theme", "Reset to preset defaults.");
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Save Theme", ImVec2(130 * s, 28 * s), "Persist to lumino.conf.")) {
            lum::SaveConfig();
            LumToastPush(LumLogLevel::Info, "Theme", "Saved.");
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Load Theme", ImVec2(130 * s, 28 * s), "Reload from lumino.conf.")) {
            lum::LoadConfig();
            LumToastPush(LumLogLevel::Info, "Theme", "Reloaded.");
        }
    }
    EndCard();
}

// ------------------------------------------------------------- visualizer --
static void RenderVisualizerCanvas(float height) {
    using namespace lum;
    const float s = g_theme.uiScale;
    ImGui::BeginChild("##viscanvas", ImVec2(0, height), true);
    ImVec2 avail = ImGui::GetContentRegionAvail();
    ImGui::Dummy(avail);
    ImVec2 p0 = ImGui::GetItemRectMin();
    ImVec2 p1(p0.x + avail.x, p0.y + avail.y);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->PushClipRect(p0, p1, true);

    static std::vector<float> mags;
    static std::vector<float> wave;
    static double lastCalc = 0;
    double now = ImGui::GetTime();
    double interval = 1.0 / (g_settings.visFPS < 15 ? 15 : g_settings.visFPS);
    if (!g_visFreeze && now - lastCalc >= interval) {
        lastCalc = now;
        std::vector<float> pcm = SnapPCM();
        mags = SpectrumMags(pcm.size() >= 512 ? pcm : std::vector<float>());
        wave = pcm.size() > 1024 ? std::vector<float>(pcm.end() - 1024, pcm.end()) : pcm;
    }
    ImVec2 c(p0.x + avail.x * 0.5f, p0.y + avail.y * 0.5f);
    float t = (float)now;
    ImU32 ac = ImGui::ColorConvertFloat4ToU32(g_theme.accent);
    ImU32 ac2 = ImGui::ColorConvertFloat4ToU32(g_theme.accent2);

    if (g_visMode == 0) { // spectrum
        DrawSpectrumPolyline(dl, p0, avail, mags);
    } else if (g_visMode == 1) { // waveform
        if (!wave.empty()) {
            ImVec2 prev(0, 0);
            for (size_t i = 0; i < wave.size(); ++i) {
                ImVec2 p(p0.x + (float)i / wave.size() * avail.x,
                         c.y - wave[i] * avail.y * 0.45f * g_visScale);
                if (i > 0) dl->AddLine(prev, p, ac, 1.4f);
                prev = p;
            }
            dl->AddLine(ImVec2(p0.x, c.y), ImVec2(p1.x, c.y),
                ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 0.15f)));
        }
    } else if (g_visMode == 2) { // frequency bars
        const int bars = 48;
        float bw = avail.x / bars;
        for (int i = 0; i < bars; ++i) {
            float v = 0;
            if (!mags.empty()) {
                size_t a = (size_t)i * mags.size() / bars, b = (size_t)(i + 1) * mags.size() / bars;
                for (size_t k = a; k < b && k < mags.size(); ++k) v = (std::max)(v, mags[k]);
            }
            float bh = v * avail.y * g_visScale;
            ImVec2 a(p0.x + i * bw + 1, p1.y - bh), b(p0.x + (i + 1) * bw - 1, p1.y);
            dl->AddRectFilled(a, b, ImGui::ColorConvertFloat4ToU32(
                ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.75f)), 2.0f);
            dl->AddRectFilled(ImVec2(a.x, a.y - 3), ImVec2(b.x, a.y),
                ac2, 1.5f);
        }
    } else if (g_visMode == 3) { // circular spectrum
        const int bars = 120;
        float R = (std::min)(avail.x, avail.y) * 0.5f - 12 * s;
        for (int i = 0; i < bars; ++i) {
            float v = mags.empty() ? 0 : mags[(size_t)i * mags.size() / bars];
            float ang = i / (float)bars * 6.2831853f;
            ImVec2 a(c.x + cosf(ang) * R * 0.55f, c.y + sinf(ang) * R * 0.55f);
            ImVec2 b(c.x + cosf(ang) * (R * 0.55f + v * R * 0.45f * g_visScale),
                     c.y + sinf(ang) * (R * 0.55f + v * R * 0.45f * g_visScale));
            dl->AddLine(a, b, ac, 2.0f);
        }
        dl->AddCircle(c, R * 0.55f, ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 0.15f)), 64);
    } else if (g_visMode == 4) { // constellation spectrum
        const int K = 26;
        float R = (std::min)(avail.x, avail.y) * 0.5f - 16 * s;
        ImVec2 pts[26];
        for (int i = 0; i < K; ++i) {
            float v = mags.empty() ? 0 : mags[(size_t)i * mags.size() / K];
            float ang = i / (float)K * 6.2831853f + t * 0.05f;
            float rr = R * (0.45f + 0.55f * v * g_visScale);
            pts[i] = ImVec2(c.x + cosf(ang) * rr, c.y + sinf(ang) * rr);
        }
        for (int i = 0; i < K; ++i)
            for (int j = i + 1; j < K; ++j) {
                float dx = pts[j].x - pts[i].x, dy = pts[j].y - pts[i].y;
                if (dx * dx + dy * dy < R * R * 0.45f)
                    dl->AddLine(pts[i], pts[j], ImGui::ColorConvertFloat4ToU32(
                        ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.25f)));
            }
        for (int i = 0; i < K; ++i) {
            dl->AddCircleFilled(pts[i], 5 * s, ImGui::ColorConvertFloat4ToU32(
                ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.25f)));
            dl->AddCircleFilled(pts[i], 2.6f * s, ac2);
        }
    } else if (g_visMode == 5) { // oscilloscope
        if (wave.size() > 64) {
            size_t trig = 0;
            for (size_t i = 1; i + 256 < wave.size(); ++i)
                if (wave[i - 1] < 0 && wave[i] >= 0) { trig = i; break; }
            ImVec2 prev(0, 0);
            for (int i = 0; i < 256; ++i) {
                size_t k = (std::min)(trig + (size_t)i, wave.size() - 1);
                ImVec2 p(p0.x + (float)i / 256 * avail.x,
                         c.y - wave[k] * avail.y * 0.45f * g_visScale);
                if (i > 0) {
                    dl->AddLine(prev, p, ImGui::ColorConvertFloat4ToU32(
                        ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.3f)), 3.0f);
                    dl->AddLine(prev, p, ac2, 1.5f);
                }
                prev = p;
            }
        }
    } else if (g_visMode == 6) { // stereo field
        if (!wave.empty()) {
            ImVec2 prev(0, 0);
            for (size_t i = 64; i < wave.size(); ++i) {
                ImVec2 p(c.x + wave[i] * avail.x * 0.45f * g_visScale,
                         c.y - wave[i - 64] * avail.y * 0.45f * g_visScale);
                if (i > 64) dl->AddLine(prev, p, ImGui::ColorConvertFloat4ToU32(
                    ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.5f)), 1.2f);
                prev = p;
            }
            dl->AddLine(ImVec2(p0.x, c.y), ImVec2(p1.x, c.y),
                ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 0.12f)));
            dl->AddLine(ImVec2(c.x, p0.y), ImVec2(c.x, p1.y),
                ImGui::ColorConvertFloat4ToU32(ImVec4(1, 1, 1, 0.12f)));
        }
    } else { // peak history
        static std::vector<float> hist;
        std::vector<float> pcm = SnapPCM(1024);
        float pk = 0;
        for (float v : pcm) pk = (std::max)(pk, fabsf(v));
        if (!g_visFreeze) {
            hist.push_back(pk);
            if (hist.size() > 240) hist.erase(hist.begin());
        }
        ImVec2 prev(0, 0);
        for (size_t i = 0; i < hist.size(); ++i) {
            ImVec2 p(p0.x + (float)i / 240 * avail.x, p1.y - hist[i] * avail.y * g_visScale);
            if (i > 0) dl->AddLine(prev, p, ac, 1.8f);
            prev = p;
        }
    }
    dl->PopClipRect();
    ImGui::EndChild();
}
static void RenderVisualizer() {
    using namespace lum;
    SectionHeader("Audio Visualizer", "Real-time constellation visualization.");
    const float s = g_theme.uiScale;
    static const char* kModes[] = { "Spectrum", "Waveform", "Bars", "Circular",
        "Constellation", "Scope", "Stereo", "History" };
    if (BeginCard("##visctl", "Mode", ImVec2(0, 0))) {
        for (int i = 0; i < 8; ++i) {
            bool sel = (g_visMode == i);
            if (sel) ImGui::PushStyleColor(ImGuiCol_Button,
                ImVec4(g_theme.accent.x, g_theme.accent.y, g_theme.accent.z, 0.30f));
            if (ImGui::Button(kModes[i], ImVec2(110 * s, 28 * s))) g_visMode = i;
            if (sel) ImGui::PopStyleColor();
            if ((i + 1) % 4 != 0) ImGui::SameLine(0, 6 * s);
        }
        ImGui::Spacing();
        GlowSlider("Scale", &g_visScale, 0.2f, 3.0f, "%.1fx", "", "Display magnification.");
        Toggle("Freeze", &g_visFreeze, "Hold the current frame.");
    }
    EndCard();
    if (BeginCard("##visview", kModes[g_visMode], ImVec2(0, 0))) {
        RenderVisualizerCanvas(340 * g_theme.uiScale);
    }
    EndCard();
}

static void RenderMixer() {
    using namespace lum;
    SectionHeader("Mixer", "Channel strips, routing and master bus.");
    float avail = ImGui::GetContentRegionAvail().x;
    const float s = g_theme.uiScale;
    std::vector<float> pcm = SnapPCM();
    float base = PCMLevel(pcm) * 2.0f;
    if (base > 1) base = 1;
    bool anySolo = false;
    for (auto& ch : g_mixer) if (ch.solo && !ch.mute) anySolo = true;

    float stripW = 132 * s;
    float rowW = 8 * (stripW + 8 * s);
    if (BeginCard("##mixstrips", "Channels", ImVec2(0, 0))) {
        ImGui::BeginChild("##mixscroll", ImVec2(0, 330 * s), false,
            ImGuiWindowFlags_HorizontalScrollbar);
        for (int i = 0; i < 8; ++i) {
            LumChannel& ch = g_mixer[(size_t)i];
            ImGui::PushID(4000 + i);
            ImGui::BeginChild("##strip", ImVec2(stripW, 310 * s), true);
            ImGui::SetNextItemWidth(-1);
            ImGui::InputText("##nm", ch.name, sizeof(ch.name));
            bool audible = !ch.mute && (!anySolo || ch.solo) && !g_mixerMasterMute;
            float target = audible ? base * ch.gain : 0.0f;
            if (target > 1) target = 1;
            ch.levelL += (target - ch.levelL) * 0.3f;
            ch.levelR += (target * (1.0f - fabsf(ch.pan) * 0.5f) - ch.levelR) * 0.3f;
            if (ch.levelL > ch.peak) ch.peak = ch.levelL;
            else ch.peak = (std::max)(0.0f, ch.peak - ImGui::GetIO().DeltaTime * 0.5f);
            ImVec2 mp = ImGui::GetCursorScreenPos();
            float mw = (stripW - 20 * s) * 0.5f;
            Meter(ch.levelL, ch.peak, ImVec2(mw - 2, 90 * s), false);
            ImGui::SetCursorScreenPos(ImVec2(mp.x + mw + 2, mp.y));
            Meter(ch.levelR, ch.peak, ImVec2(mw - 2, 90 * s), false);
            ImGui::SetCursorScreenPos(ImVec2(mp.x, mp.y + 90 * s + 4 * s));
            ImGui::Dummy(ImVec2(stripW - 20 * s, 1));
            GlowSlider("Gain", &ch.gain, 0.0f, 2.0f, "%.2f", "x", "Channel gain.", 36 * s);
            GlowSlider("Pan", &ch.pan, -1.0f, 1.0f, "%+.1f", "", "L/R placement.", 36 * s);
            if (GlowButton(ch.mute ? "M*" : "M", ImVec2(52 * s, 22 * s), "Mute channel.")) ch.mute = !ch.mute;
            ImGui::SameLine(0, 4 * s);
            if (GlowButton(ch.solo ? "S*" : "S", ImVec2(52 * s, 22 * s), "Solo channel.")) ch.solo = !ch.solo;
            char pk[32]; snprintf(pk, sizeof(pk), "pk %.2f", (double)ch.peak);
            ImGui::TextDisabled("%s", pk);
            ImGui::EndChild();
            ImGui::PopID();
            if (i < 7) ImGui::SameLine(0, 8 * s);
        }
        ImGui::EndChild();
        if (GlowButton("Reset Peaks", ImVec2(120 * s, 26 * s), "Clear all peak holds.")) {
            for (auto& ch : g_mixer) ch.peak = 0;
            g_peakHold = 0;
        }
    }
    EndCard();

    if (BeginCard("##mixmaster", "Master Bus", ImVec2(0, 0))) {
        GlowSlider("Master Volume", &g_mixerMaster, 0.0f, 2.0f, "%.2f", "x",
            "Master fader before the limiter.");
        Toggle("Master Mute", &g_mixerMasterMute, "Silence the master bus.");
        Toggle("Master Limiter", &g_mixerLimiter, "Brick-wall protection on the master.");
        GlowSlider("Limiter Ceiling", &g_mixerLimiterCeil, -12.0f, 0.0f, "%.1f", "dB",
            "Limiter ceiling.");
        float mLvl = (std::min)(1.0f, base * g_mixerMaster * (g_mixerMasterMute ? 0 : 1));
        Meter(mLvl, mLvl, ImVec2(avail - 24 * s, 14 * s));
        ImGui::TextDisabled("Routing: Input -> VST chain -> EQ -> Effects -> Master -> Encoder");
    }
    EndCard();
}

// --------------------------------------------------------------- advanced --
static void RenderSignalAnalysis() {
    using namespace lum;
    const float s = g_theme.uiScale;
    if (BeginCard("##advSig", "Signal Analysis", ImVec2(0, 0),
            "Live stream-health backend hooks.")) {
        Toggle("Client Detection", &dbcheck, "Log dB anomalies per decoded frame.");
        Toggle("INT16 Check", &int16check, "Log integer-sample statistics per frame.");
        Toggle("Self Check (DC)", &selfcheck, "Track DC offset / self-check reject values.");
        Toggle("Force Not-Natty", &forceNotNatty, "Force the suspicious path for testing.");
        ImGui::TextDisabled("Analyzer Label");
        ImGui::SetNextItemWidth(-1);
        ImGui::InputText("##advlabel", g_lumAnalyzerLabel, 128);
        HelpTip("Free-text tag attached to analysis rows.");
        std::vector<float> pcm = SnapPCM();
        std::vector<float> mags = SpectrumMags(pcm);
        ImVec2 p = ImGui::GetCursorScreenPos();
        ImVec2 sz(ImGui::GetContentRegionAvail().x, 130 * s);
        ImGui::Dummy(sz);
        DrawSpectrumPolyline(ImGui::GetWindowDrawList(), p, sz, mags);
        ImGui::Spacing();
        ImGui::TextDisabled("Live dB / reject history");
        std::lock_guard<std::mutex> lk(db_graph_mutex);
        if (!db_graph_data.empty()) {
            char ov[64]; snprintf(ov, sizeof(ov), "last %.2f", (double)db_graph_data.back());
            ImGui::PlotLines("##advgraph", db_graph_data.data(), (int)db_graph_data.size(),
                0, ov, FLT_MAX, FLT_MAX, ImVec2(-1, 110 * s));
        } else ImGui::TextDisabled("No data yet - join a voice channel.");
    }
    EndCard();
}
static void RenderLua() {
    using namespace lum;
    const float s = g_theme.uiScale;
    static char scriptBuf[8192] = "";
    if (BeginCard("##advLua", "Lua Scripting", ImVec2(0, 0),
            "Live scripting over gain, master and reverb. API: setgain(v), setexpgain(v), setbitrate(v), setmaster(v), setreverb(v).")) {
        if (GlowButton("Open Console", ImVec2(120 * s, 26 * s), "Attach a debug console.")) {
            if (!GetConsoleWindow()) {
                AllocConsole();
                FILE* f;
                freopen_s(&f, "CONOUT$", "w", stdout);
                freopen_s(&f, "CONIN$", "r", stdin);
                hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
            }
            InitLua();
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Close Console", ImVec2(120 * s, 26 * s), "Detach the console.")) {
            HWND c = GetConsoleWindow();
            if (c) { FreeConsole(); PostMessage(c, WM_CLOSE, 0, 0); }
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton(g_showLogs ? "Hide Logs" : "Show Logs", ImVec2(120 * s, 26 * s),
                "Toggle the in-app log view.")) g_showLogs = !g_showLogs;
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Run Script", ImVec2(120 * s, 26 * s), "Execute the editor buffer.")) {
            if (L) {
                AddLog("[Lua] Running script...");
                if (luaL_dostring(L, scriptBuf) != LUA_OK) {
                    AddLog("[Lua Error] %s", lua_tostring(L, -1));
                    lua_pop(L, 1);
                }
            } else AddLog("[Lua Error] Lua state not initialized!");
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Reset Lua", ImVec2(110 * s, 26 * s), "Restart the Lua VM.")) {
            ShutdownLua(); InitLua(); RegisterLuaFunctions();
            AddLog("[Lua] State reset.");
        }
        ImGui::TextDisabled("Editor (setgain / setexpgain / setbitrate / setmaster / setreverb)");
        const char* placeholder = "-- Write real Lua here\nprint('Lua ready!')\nsetgain(1.0)\n";
        ImGui::InputTextMultiline("##luaedit", scriptBuf, sizeof(scriptBuf),
            ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 12),
            ImGuiInputTextFlags_AllowTabInput);
        if (!scriptBuf[0]) {
            ImVec2 mp = ImGui::GetItemRectMin();
            ImGui::GetWindowDrawList()->AddText(ImVec2(mp.x + 5, mp.y + 5),
                ImGui::ColorConvertFloat4ToU32(ImVec4(0.5f, 0.5f, 0.5f, 0.7f)), placeholder);
        }
        if (g_showLogs) {
            ImGui::BeginChild("##lualogs", ImVec2(0, 150 * s), true);
            for (auto& e : g_logRing) {
                ImVec4 c = g_theme.text;
                if (e.level == LumLogLevel::Warning) c = ImVec4(1.0f, 0.72f, 0.25f, 1.0f);
                if (e.level == LumLogLevel::Error) c = ImVec4(0.95f, 0.35f, 0.35f, 1.0f);
                if (e.level == LumLogLevel::Debug) c = g_theme.textDim;
                ImGui::TextColored(c, "%s", e.text.c_str());
            }
            if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 20)
                ImGui::SetScrollHereY(1.0f);
            ImGui::EndChild();
            if (GlowButton("Clear Logs", ImVec2(110 * s, 24 * s), "Empty the log ring.")) g_logRing.clear();
        }
    }
    EndCard();
}
static void RenderStealth(HWND hwnd) {
    using namespace lum;
    const float s = g_theme.uiScale;
    static bool hider = true;
    static char processName[128] = "";
    if (BeginCard("##advStealth", "Stealth & Safety", ImVec2(0, 0),
            "Capture protection and footprint controls.")) {
        if (Toggle("Hide Window (anti-capture)", &hider, "Exclude the overlay from screen capture.")) {
            SetWindowDisplayAffinity(hwnd, hider ? WDA_EXCLUDEFROMCAPTURE : WDA_NONE);
        }
        ImGui::TextDisabled("Injector process name");
        ImGui::SetNextItemWidth(220 * s);
        ImGui::InputText("##advproc", processName, sizeof(processName));
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Kill Process", ImVec2(120 * s, 26 * s), "Terminate by executable name.")) {
            std::wstring w = ConvertToWide(processName);
            HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
            int killed = 0;
            if (snap != INVALID_HANDLE_VALUE) {
                PROCESSENTRY32W pe; pe.dwSize = sizeof(pe);
                if (Process32FirstW(snap, &pe)) do {
                    if (_wcsicmp(pe.szExeFile, w.c_str()) == 0) {
                        HANDLE hp = OpenProcess(PROCESS_TERMINATE, FALSE, pe.th32ProcessID);
                        if (hp) { TerminateProcess(hp, 0); CloseHandle(hp); ++killed; }
                    }
                } while (Process32NextW(snap, &pe));
                CloseHandle(snap);
            }
            LumToastPush(killed ? LumLogLevel::Info : LumLogLevel::Warning,
                "Stealth", killed ? "Process terminated." : "No matching process found.");
        }
        if (GlowButton("Clear Hook Traces", ImVec2(150 * s, 26 * s), "Unhook and drop registry traces.")) {
            if (hHook) { UnhookWindowsHookEx(hHook); hHook = nullptr; }
            RegDeleteKeyA(HKEY_CURRENT_USER, "Software\\Injector");
            LumToastPush(LumLogLevel::Info, "Stealth", "Hook traces cleared.");
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Randomize Memory", ImVec2(150 * s, 26 * s), "XOR the tracked region.")) {
            if (memoryBase && memoryRegionSize) {
                for (size_t i = 0; i < memoryRegionSize; i += sizeof(DWORD)) {
                    DWORD o;
                    VirtualProtect(memoryBase + i, sizeof(DWORD), PAGE_EXECUTE_READWRITE, &o);
                    *(DWORD*)(memoryBase + i) ^= 0xDEADBEEF;
                    VirtualProtect(memoryBase + i, sizeof(DWORD), o, &o);
                }
            } else LumToastPush(LumLogLevel::Warning, "Stealth", "No tracked memory region.");
        }
        if (GlowButton("Flush Logs", ImVec2(150 * s, 26 * s), "Delete local trace files.")) {
            DeleteFileW(L"injector.log"); DeleteFileW(L"hook_trace.log");
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Anti-Debug Check", ImVec2(150 * s, 26 * s), "Exit if a debugger is attached.")) {
            if (IsDebuggerPresentAdvanced()) ExitProcess(0);
            else LumToastPush(LumLogLevel::Info, "Stealth", "No debugger detected.");
        }
        if (GlowButton("Obfuscate Module", ImVec2(150 * s, 26 * s), "Spoof the module name.")) ObfuscateModuleName();
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Clear PE Headers", ImVec2(150 * s, 26 * s), "Wipe in-memory headers.")) ClearPEHeaders();
        if (GlowButton("Hide Threads", ImVec2(150 * s, 26 * s), "Redirect thread start addresses.")) HideThreadStartAddress();
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Clear Debug Info", ImVec2(150 * s, 26 * s), "Wipe debug directory.")) ClearDebugInfo();
        if (GlowButton("Clear Event Logs", ImVec2(150 * s, 26 * s), "Clear Application/System logs.")) {
            ClearEventLogs();
            LumToastPush(LumLogLevel::Info, "Stealth", "Event logs cleared.");
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Self-Destruct", ImVec2(150 * s, 26 * s), "Unload Lum1n0u$ immediately.")) SelfDestruct();
    }
    EndCard();
}
static void RenderDiagnostics() {
    using namespace lum;
    if (BeginCard("##advDiag", "Diagnostics", ImVec2(0, 0))) {
        ImGuiIO& io = ImGui::GetIO();
        ImGui::TextDisabled("Frame"); ImGui::SameLine(140 * g_theme.uiScale, 0);
        ImGui::Text("%.2f ms (%.0f FPS)", (double)(io.DeltaTime * 1000.0), (double)io.Framerate);
        ImGui::TextDisabled("Draw"); ImGui::SameLine(140 * g_theme.uiScale, 0);
        ImGui::Text("%d verts / %d tris / %d calls", io.MetricsRenderVertices,
            io.MetricsRenderIndices / 3, io.MetricsRenderWindows);
        char cfg[512]; lum::ConfigPath(cfg, sizeof(cfg));
        ImGui::TextDisabled("Config"); ImGui::SameLine(140 * g_theme.uiScale, 0);
        ImGui::TextWrapped("%s", cfg);
        ImGui::TextDisabled("Module"); ImGui::SameLine(140 * g_theme.uiScale, 0);
        ImGui::Text("0x%p (%s)", g_lumModule, g_lumModule ? "ours" : "host");
        ImGui::TextDisabled("Hook"); ImGui::SameLine(140 * g_theme.uiScale, 0);
        ImGui::Text("%s", g_hookConnected ? "discord_voice hooked" : "waiting for discord_voice");
        ImGui::TextDisabled("Log entries"); ImGui::SameLine(140 * g_theme.uiScale, 0);
        ImGui::Text("%d / %d", (int)g_logRing.size(), (int)kLumLogMax);
    }
    EndCard();
}
static void RenderAdvanced(HWND hwnd) {
    using namespace lum;
    SectionHeader("Advanced", "Analysis backend, scripting, stealth and diagnostics.");
    float avail = ImGui::GetContentRegionAvail().x;
    const float s = g_theme.uiScale;
    bool side = avail > 1000 * s;
    float half = side ? (avail - 8 * s) * 0.5f : avail;
    // RenderSignalAnalysis + RenderLua are full-width cards internally; wrap widths manually:
    if (side) {
        ImGui::BeginChild("##advL", ImVec2(half, 0), false);
        RenderSignalAnalysis();
        RenderLua();
        ImGui::EndChild();
        ImGui::SameLine(0, 8 * s);
        ImGui::BeginChild("##advR", ImVec2(half, 0), false);
        RenderStealth(hwnd);
        RenderDiagnostics();
        ImGui::EndChild();
    } else {
        RenderSignalAnalysis();
        RenderLua();
        RenderStealth(hwnd);
        RenderDiagnostics();
    }
}

static void RenderSettings() {
    using namespace lum;
    SectionHeader("Settings", "Appearance, performance, audio, behavior and diagnostics.");
    float avail = ImGui::GetContentRegionAvail().x;
    const float s = g_theme.uiScale;
    bool side = avail > 1000 * s;
    float half = side ? (avail - 8 * s) * 0.5f : avail;

    if (BeginCard("##setApp", "Appearance", ImVec2(half, 0))) {
        static const char* kTh[] = { "Cosmic Blue", "Nebula Violet", "Aurora Cyan",
            "Eclipse", "Deep Space", "Solar Flare" };
        ImGui::TextDisabled("Theme"); ImGui::SetNextItemWidth(-1);
        if (ImGui::Combo("##settheme", &g_themeIndex, kTh, 6)) LumSelectTheme(g_themeIndex);
        GlowSlider("UI Scale", &g_theme.uiScale, 0.7f, 2.0f, "%.2fx", "",
            "Global scale. Fonts scale instantly; layout reflows.");
        GlowSlider("Animation Speed", &g_theme.animSpeed, 0.1f, 3.0f, "%.1fx", "",
            "Multiplier for transitions and smoothing.");
        GlowSlider("Transparency", &g_theme.panelOpacity, 0.5f, 1.0f, "%.2f", "",
            "Card background opacity.");
        GlowSlider("Glow Strength", &g_theme.glow, 0.0f, 1.0f, "%.2f", "",
            "Luminous accents on sliders, tabs and edges.");
    }
    EndCard();
    if (side) ImGui::SameLine(0, 8 * s);
    if (BeginCard("##setPerf", "Performance", ImVec2(side ? half : avail, 0))) {
        static const char* kQ[] = { "Eco", "Balanced", "Ultra" };
        ImGui::TextDisabled("Rendering Quality"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##setquality", &g_settings.renderQuality, kQ, 3);
        HelpTip("Eco reduces background density and visualizer rate automatically.");
        static const char* kFps[] = { "30", "60", "120" };
        static const int kFpsV[] = { 30, 60, 120 };
        int fi = 1;
        for (int i = 0; i < 3; ++i) if (kFpsV[i] == g_settings.visFPS) fi = i;
        ImGui::TextDisabled("Visualizer FPS"); ImGui::SetNextItemWidth(-1);
        if (ImGui::Combo("##setfps", &fi, kFps, 3)) g_settings.visFPS = kFpsV[fi];
        Toggle("Background Effects", &g_settings.bgEffects,
            "Constellation starfield behind panels. Turn off on weak GPUs.");
        GlowSliderInt("Worker Threads", &g_settings.workerThreads, 1, 8, "",
            "Threads for VST scanning and background jobs.");
    }
    EndCard();

    if (BeginCard("##setAudio", "Audio", ImVec2(half, 0))) {
        static const char* kSR[] = { "44100 Hz", "48000 Hz" };
        ImGui::TextDisabled("Sample Rate"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##setsr", &g_settings.sampleRateIdx, kSR, 2);
        HelpTip("Host rate for VST processing. Discord voice is 48 kHz.");
        static const char* kCh[] = { "Mono", "Stereo" };
        ImGui::TextDisabled("Channel Mode"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##setch", &g_settings.channelMode, kCh, 2);
        static const char* kBuf[] = { "128", "256", "512", "1024", "2048" };
        static const int kBufV[] = { 128, 256, 512, 1024, 2048 };
        int bi = 2;
        for (int i = 0; i < 5; ++i) if (kBufV[i] == g_settings.bufferSize) bi = i;
        ImGui::TextDisabled("Buffer Size"); ImGui::SetNextItemWidth(-1);
        if (ImGui::Combo("##setbuf", &bi, kBuf, 5)) g_settings.bufferSize = kBufV[bi];
        HelpTip("Smaller buffers = lower latency, higher CPU.");
        static const char* kMode[] = { "Realtime", "Low Latency", "Quality" };
        ImGui::TextDisabled("Processing Mode"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##setmode", &g_settings.processingMode, kMode, 3);
    }
    EndCard();
    if (side) ImGui::SameLine(0, 8 * s);
    if (BeginCard("##setBeh", "Behavior", ImVec2(side ? half : avail, 0))) {
        static const char* kStart[] = { "Last Used", "Dashboard", "Encoder", "Equalizer",
            "Effects", "Distortion", "Reverb", "VST Hosting", "Theme", "Visualizer",
            "Mixer", "Advanced", "Settings", "About" };
        ImGui::TextDisabled("Startup Module"); ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##setstart", &g_settings.startupTab, kStart, 14);
        HelpTip("Which module opens on launch. Last Used restores the saved tab.");
        Toggle("Remember Window Position", &g_settings.rememberPos,
            "Restore size and position on launch.");
        Toggle("Remember Theme", &g_settings.rememberTheme, "Restore the saved theme.");
        Toggle("Auto-save Configuration", &g_settings.autosave,
            "Persist settings every few seconds and on close.");
        ImGui::TextDisabled("Keys 1-9 and 0 switch modules.");
    }
    EndCard();

    if (BeginCard("##setAdv", "Advanced", ImVec2(half, 0))) {
        Toggle("Debug Logging", &g_settings.debugLog, "Keep verbose debug entries in the log ring.");
        Toggle("Diagnostic Mode", &g_settings.diagMode, "Reserved for future trace hooks.");
        Toggle("Internal Statistics", &g_settings.internalStats, "Show extended counters in Advanced.");
    }
    EndCard();
    if (side) ImGui::SameLine(0, 8 * s);
    if (BeginCard("##setCfg", "Configuration File", ImVec2(side ? half : avail, 0))) {
        char cfg[512]; lum::ConfigPath(cfg, sizeof(cfg));
        ImGui::TextWrapped("%s", cfg);
        ImGui::TextDisabled("Versioned (v%d). Unknown keys are ignored; missing keys keep defaults.",
            LUMINOUS_CONFIG_VERSION);
        if (GlowButton("Save Now", ImVec2(120 * s, 28 * s), "Write all settings to disk (Ctrl+S).")) {
            lum::SaveConfig();
            LumToastPush(LumLogLevel::Info, "Config", "Configuration saved.");
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Reload", ImVec2(120 * s, 28 * s), "Reload from disk.")) {
            lum::LoadConfig();
            LumToastPush(LumLogLevel::Info, "Config", "Configuration reloaded.");
        }
        ImGui::SameLine(0, 6 * s);
        if (GlowButton("Open Folder", ImVec2(120 * s, 28 * s), "Open the config folder.")) {
            char dir[512]; snprintf(dir, sizeof(dir), "%s", cfg);
            if (char* bs = strrchr(dir, '\\')) *bs = 0;
            ShellExecuteA(nullptr, "open", dir, nullptr, nullptr, SW_SHOW);
        }
    }
    EndCard();
}

static void RenderAbout() {
    using namespace lum;
    SectionHeader("About", "Brand, build and credits.");
    const float s = g_theme.uiScale;
    if (BeginCard("##aboutbrand", "Identity", ImVec2(0, 0))) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        float logoR = 64 * s;
        ImVec2 lc(p.x + logoR + 8 * s, p.y + logoR + 8 * s);
        DrawLuminosLogo(dl, lc, logoR, (float)ImGui::GetTime(), 1.2f);
        if (g_LuminosTexture) {
            ImGui::SetCursorScreenPos(ImVec2(lc.x + logoR + 20 * s, p.y + 8 * s));
            ImGui::Image((ImTextureID)g_LuminosTexture, ImVec2(128 * s, 128 * s));
        }
        ImGui::SetCursorScreenPos(ImVec2(lc.x + logoR + (g_LuminosTexture ? 160 : 20) * s, p.y + 10 * s));
        ImGui::BeginGroup();
        ImGui::Text("%s", LUMINOUS_APP_NAME);
        ImGui::TextDisabled("by %s", LUMINOUS_DEVELOPER);
        ImGui::TextDisabled("Futuristic constellation-themed Discord audio workstation.");
        ImGui::Spacing();
        StatusPill("v2 constellation", g_theme.accent);
        ImGui::EndGroup();
        ImVec2 after = ImGui::GetCursorScreenPos();
        float need = p.y + logoR * 2 + 20 * s;
        if (after.y < need) ImGui::SetCursorScreenPos(ImVec2(after.x, need));
    }
    EndCard();
    float avail = ImGui::GetContentRegionAvail().x;
    bool side = avail > 900 * s;
    float half = side ? (avail - 8 * s) * 0.5f : avail;
    if (BeginCard("##aboutbuild", "Build", ImVec2(half, 0))) {
        auto row = [&](const char* k, const char* v) {
            ImGui::TextDisabled("%s", k); ImGui::SameLine(150 * s, 0); ImGui::Text("%s", v);
        };
        row("Version", LUMINOUS_VERSION);
        row("Build", LUMINOUS_BUILD);
        row("Architecture", sizeof(void*) == 8 ? "x64" : "x86");
        row("Renderer", "DirectX 9 + Dear ImGui");
        row("Audio Backend", "Opus (hook) + VST2 chain");
        row("Plugin Support", "VST 2.x instruments/effects");
        row("Config", "versioned lumino.conf (v2)");
    }
    EndCard();
    if (side) ImGui::SameLine(0, 8 * s);
    if (BeginCard("##aboutcred", "Credits", ImVec2(side ? half : avail, 0))) {
        ImGui::Text("%s", LUMINOUS_APP_NAME);
        ImGui::TextDisabled("developed by %s", LUMINOUS_DEVELOPER);
        ImGui::Spacing();
        ImGui::TextDisabled("Powered by open technology:");
        ImGui::BulletText("Dear ImGui (UI framework)");
        ImGui::BulletText("Opus codec (audio)");
        ImGui::BulletText("Steinberg VST SDK (plugin hosting)");
        ImGui::BulletText("Lua (scripting)  |  MinHook (voice hook)");
        ImGui::Spacing();
        ImGui::TextDisabled("Onboard DSP parameters route through the VST");
        ImGui::TextDisabled("chain and the Opus encoder hook; estimates are");
        ImGui::TextDisabled("labeled wherever vendor telemetry is unavailable.");
    }
    EndCard();
}

// ------------------------------------------------------- logo texture -----
void LoadLuminosTexture(LPDIRECT3DDEVICE9 device) {
    if (!device || g_LuminosTexture) return;
    HRESULT hr = D3DXCreateTextureFromFileInMemory(device, luminos_png,
        (UINT)luminos_png_len, &g_LuminosTexture);
    if (FAILED(hr))
        LumToastPush(LumLogLevel::Warning, "Resources",
            "Logo texture failed to load; procedural logo active.");
}
void ReleaseLuminosTexture() {
    if (g_LuminosTexture) { g_LuminosTexture->Release(); g_LuminosTexture = nullptr; }
}

// ============================================================ runtime ======
void ImGui::ui::start() {
    using namespace lum;
    SetProcessDPIAware();
    if (!g_vstHost) g_vstHost = std::make_unique<VSTHost>();
    lum::LoadConfig();
    if (!g_settings.rememberTheme) LumSelectTheme(0);
    if (g_settings.startupTab > 0 && g_settings.startupTab <= LumTab_Count)
        g_activeTab = g_settings.startupTab - 1;
    if (!g_settings.rememberPos) {
        g_winX = 100; g_winY = 100; g_winW = 1280; g_winH = 800;
        g_winMaximized = false;
    }
    if (g_settings.renderQuality == 0 && g_theme.density > 40)
        g_theme.density = 40;

    HINSTANCE inst = (HINSTANCE)(g_lumModule ? g_lumModule : GetModuleHandle(nullptr));
    HICON hIcon = LoadIcon(inst, MAKEINTRESOURCE(IDI_LUMINOUS));
    if (!hIcon) hIcon = LoadIcon(nullptr, IDI_APPLICATION);
    WNDCLASSEXW wc = {};
    wc.cbSize = sizeof(wc);
    wc.style = CS_CLASSDC;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = GetModuleHandle(nullptr);
    wc.hIcon = hIcon;
    wc.hIconSm = hIcon;
    wc.lpszClassName = L"Lum1n0u$Hook";
    ::RegisterClassExW(&wc);
    HWND hwnd = ::CreateWindowExW(WS_EX_TOOLWINDOW, wc.lpszClassName,
        L"Lum1n0u$ - by blasphemyw",
        WS_POPUP | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_THICKFRAME | WS_CLIPCHILDREN,
        g_winX, g_winY, g_winW, g_winH, nullptr, nullptr, wc.hInstance, nullptr);
    g_Window = hwnd;
    SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
    SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);

    if (!CreateDeviceD3D(hwnd)) {
        CleanupDeviceD3D();
        ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return;
    }
    ::ShowWindow(hwnd, g_winMaximized ? SW_SHOWMAXIMIZED : SW_SHOWDEFAULT);
    ::UpdateWindow(hwnd);
    SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE);
    SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = nullptr; // layout is code-driven + lumino.conf
    LumApplyThemeToStyle();
    io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\segoe.ttf", 18.0f);

    ImVec4 clear_color = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX9_Init(g_pd3dDevice);
    LoadLuminosTexture(g_pd3dDevice);
    InitLua();

    static const ImGuiKey kNumKeys[10] = { ImGuiKey_1, ImGuiKey_2, ImGuiKey_3,
        ImGuiKey_4, ImGuiKey_5, ImGuiKey_6, ImGuiKey_7, ImGuiKey_8, ImGuiKey_9, ImGuiKey_0 };
    double lastAuto = ImGui::GetTime();
    bool done = false;
    while (!done) {
        MSG msg;
        while (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT) done = true;
        }
        if (done || g_closing) break;

        ImGui_ImplDX9_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        double now = ImGui::GetTime();
        float dt = io.DeltaTime;
        if (dt <= 0) dt = 1.0f / 60.0f;
        if (dt > 0.1f) dt = 0.1f;
        g_appTime += (double)dt * (double)g_theme.animSpeed;
        io.FontGlobalScale = g_theme.uiScale;
        LumApplyThemeToStyle();
        g_winMaximized = IsZoomed(hwnd) != FALSE;

        // keyboard shortcuts: 1..9,0 switch modules; Ctrl+S saves
        if (!ImGui::IsAnyItemActive() &&
            ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows)) {
            for (int i = 0; i < 10; ++i)
                if (ImGui::IsKeyPressed(kNumKeys[i], false)) { g_activeTab = i; break; }
        }
        if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_S, false)) {
            lum::SaveConfig();
            LumToastPush(LumLogLevel::Info, "Config", "Configuration saved.");
        }
        if (g_settings.autosave && now - lastAuto > 15.0) {
            lastAuto = now;
            lum::SaveConfig();
        }

        RECT rc;
        GetClientRect(hwnd, &rc);
        ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
        ImGui::SetNextWindowSize(
            ImVec2((float)(rc.right - rc.left), (float)(rc.bottom - rc.top)), ImGuiCond_Always);
        ImGui::Begin("##lum_main", nullptr,
            ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoTitleBar |
            ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoScrollbar);

        // constellation backdrop (drawn first, behind all controls)
        {
            ImDrawList* dl = ImGui::GetWindowDrawList();
            ImVec2 wp = ImGui::GetWindowPos();
            ImVec2 ws = ImGui::GetWindowSize();
            int density = g_settings.bgEffects ? g_theme.density : 0;
            if (g_settings.renderQuality == 0) density /= 2;
            ConstellationBackground(dl, wp, ws, (float)g_appTime, io.MousePos,
                density, g_theme.glow, 1.0f);
        }

        RenderTopBar(hwnd);
        const float s = g_theme.uiScale;
        float midH = ImGui::GetContentRegionAvail().y - 24 * s;
        if (midH < 100) midH = 100;
        ImGui::BeginChild("##lum_mid", ImVec2(0, midH), false,
            ImGuiWindowFlags_NoScrollbar);
        RenderSidebar();
        ImGui::SameLine(0, 8 * s);
        ImGui::BeginChild("##lum_content", ImVec2(0, 0), false);
        switch (g_activeTab) {
            case LumTab_Dashboard: RenderDashboard(); break;
            case LumTab_Encoder: RenderEncoder(); break;
            case LumTab_EQ: RenderEQ(); break;
            case LumTab_Effects: RenderEffects(); break;
            case LumTab_Distortion: RenderDistortion(); break;
            case LumTab_Reverb: RenderReverb(); break;
            case LumTab_VST: RenderVST(); break;
            case LumTab_Theme: RenderTheme(); break;
            case LumTab_Visualizer: RenderVisualizer(); break;
            case LumTab_Mixer: RenderMixer(); break;
            case LumTab_Advanced: RenderAdvanced(hwnd); break;
            case LumTab_Settings: RenderSettings(); break;
            case LumTab_About: RenderAbout(); break;
            default: RenderDashboard(); break;
        }
        ImGui::EndChild();
        ImGui::EndChild();
        RenderStatusBar();

        ImGui::End();
        RenderToasts();
        ImGui::EndFrame();

        g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, FALSE);
        g_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
        g_pd3dDevice->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
        D3DCOLOR clear_col_dx = D3DCOLOR_RGBA((int)(clear_color.x * 255.0f),
            (int)(clear_color.y * 255.0f), (int)(clear_color.z * 255.0f), 255);
        g_pd3dDevice->Clear(0, nullptr, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, clear_col_dx, 1.0f, 0);
        if (g_pd3dDevice->BeginScene() >= 0) {
            ImGui::Render();
            ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
            g_pd3dDevice->EndScene();
        }
        HRESULT result = g_pd3dDevice->Present(nullptr, nullptr, nullptr, nullptr);
        if (result == D3DERR_DEVICELOST)
            g_DeviceLost = true;
    }

    if (g_settings.autosave) lum::SaveConfig();
    ReleaseLuminosTexture();
    ShutdownLua();
    ImGui_ImplDX9_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    CleanupDeviceD3D();
    ::DestroyWindow(hwnd);
    ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
}

bool CreateDeviceD3D(HWND hWnd) {
    if ((g_pD3D = Direct3DCreate9(D3D_SDK_VERSION)) == nullptr)
        return false;
    ZeroMemory(&g_d3dpp, sizeof(g_d3dpp));
    g_d3dpp.Windowed = TRUE;
    g_d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    g_d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
    g_d3dpp.EnableAutoDepthStencil = TRUE;
    g_d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
    g_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_ONE;
    if (g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
            D3DCREATE_HARDWARE_VERTEXPROCESSING, &g_d3dpp, &g_pd3dDevice) < 0)
        return false;
    return true;
}

void CleanupDeviceD3D() {
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
    if (g_pD3D) { g_pD3D->Release(); g_pD3D = nullptr; }
}

void ResetDevice() {
    ReleaseLuminosTexture();
    ImGui_ImplDX9_InvalidateDeviceObjects();
    HRESULT hr = g_pd3dDevice->Reset(&g_d3dpp);
    if (hr == D3DERR_INVALIDCALL)
        IM_ASSERT(0);
    ImGui_ImplDX9_CreateDeviceObjects();
    LoadLuminosTexture(g_pd3dDevice);
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;
    switch (msg) {
    case WM_NCHITTEST: {
        if (IsZoomed(hWnd)) return HTCLIENT;
        POINT pt = { (LONG)(short)LOWORD(lParam), (LONG)(short)HIWORD(lParam) };
        RECT r; GetWindowRect(hWnd, &r);
        const int B = 8;
        bool left = pt.x < r.left + B, right = pt.x >= r.right - B;
        bool top = pt.y < r.top + B, bottom = pt.y >= r.bottom - B;
        if (top && left) return HTTOPLEFT;
        if (top && right) return HTTOPRIGHT;
        if (bottom && left) return HTBOTTOMLEFT;
        if (bottom && right) return HTBOTTOMRIGHT;
        if (left) return HTLEFT;
        if (right) return HTRIGHT;
        if (top) return HTTOP;
        if (bottom) return HTBOTTOM;
        return HTCLIENT;
    }
    case WM_SIZE:
        if (wParam == SIZE_MINIMIZED) return 0;
        if (g_pd3dDevice != nullptr) {
            g_d3dpp.BackBufferWidth = LOWORD(lParam);
            g_d3dpp.BackBufferHeight = HIWORD(lParam);
            ResetDevice();
        }
        if (wParam != SIZE_MAXIMIZED && g_settings.rememberPos) {
            g_winW = (int)LOWORD(lParam);
            g_winH = (int)HIWORD(lParam);
        }
        return 0;
    case WM_MOVE:
        if (!IsZoomed(hWnd) && g_settings.rememberPos) {
            g_winX = (int)(short)LOWORD(lParam);
            g_winY = (int)(short)HIWORD(lParam);
        }
        return 0;
    case WM_GETMINMAXINFO: {
        MINMAXINFO* m = (MINMAXINFO*)lParam;
        m->ptMinTrackSize.x = 900;
        m->ptMinTrackSize.y = 600;
        return 0;
    }
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU)
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProc(hWnd, msg, wParam, lParam);
}
